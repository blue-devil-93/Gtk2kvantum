# gtk2kvantum

Version 2.16. Export the **running GTK3 theme** to a **Kvantum SVG theme**, using vector
screenshots of real widgets. Inspired by
[nomeata/gtk-vector-screenshot](https://github.com/nomeata/gtk-vector-screenshot),
which renders a GTK3 window into PDF/SVG by pointing cairo at a vector surface
instead of at the screen.

```
GTK3 widget ──gtk_widget_draw()──▶ cairo SVG surface
     │                                   │
     └── style context ──▶ borders, radii, colours
                                         │
                                         ▼
                        nine pieces per state, exact sizes
                        topleft │ top │ topright
                        left  │interior│ right
                        bottomleft │ bottom │ bottomright
                                         │
                                         ▼
                        Name.svg + Name.kvconfig + Name.colors
                                         │
                        verified with Qt's own QSvgRenderer
```

## Why this works

GTK3 paints entirely through cairo, so "screenshotting" a widget is just
`Gtk.Widget.draw(cr)` with a `cairo.SVGSurface` as target. Every CSS fill,
gradient, border, rounded corner and clip path comes out as SVG.

Kvantum names its SVG objects in a fixed scheme, so the export is a naming and
bookkeeping problem rather than a drawing problem:

| Kvantum object | Content |
| --- | --- |
| `<element>-<state>` | interior of a widget (`button-normal`, `tab-toggled`) |
| `<element>-<state>-<position>` | the eight frame pieces (`button-normal-topleft`, …) |

States are `normal`, `focused` (mouse-over), `pressed`, `toggled`, `disabled`,
and GTK has matching state flags, so every state is rendered by setting
`Gtk.StateFlags` programmatically — no mouse, no compositor, no interaction.

## Nine slices, three ways

Kvantum draws an element as nine objects: a frame of eight pieces around a
stretched interior, with the frame widths declared in the `.kvconfig`:

```ini
[PanelButtonCommand]
frame=true
frame.element=button
frame.top=3
frame.bottom=3
frame.left=3
frame.right=3
interior=true
interior.element=button
```

Getting those nine pieces out of a live GTK render took three attempts, and the
current exporter picks between them per element:

**1. Cutting one render with clip paths does not work.** Kvantum sizes every
object with `QSvgRenderer::boundsOnElement()`, and Qt reports *unclipped* content
bounds: a group clipped to a 136×7 band still measures 150×36, so each piece
would be treated as a whole widget. Nested `<svg>` is rejected by Qt's Tiny 1.2
parser for the same job.

**2. Drawing the pieces from the theme's own pixels works** (`g2k/geom.py`,
default for plain frames). Each of the eight frame pieces takes the pixels GTK
painted in that band and run-length encodes them into plain `<rect>` elements -
one rect per flat run, grown downwards, so a 1px border line is a single rect
and a corner arrives as exactly the antialiased pixels the theme drew. Every
box is precisely the slice size, nothing is clipped, and no shape is guessed
back: an inset highlight, a shade and a corner radius come out where they were
painted. The interior, the one piece Kvantum stretches, is a vertical gradient
sampled row by row - or, when the field shades in both directions, a coarse grid
of sampled pixels with identical neighbours merged back into one rect.

**3. Rendering each piece into its own surface works too** (`--mode slice`). The
earlier failure was never about clipping as such: it was that a *painted* object
gets its bounds measured, and art that does not fill its box is then stretched
to fit. One invisible full-size rect per object pins the bounds, and from there
nine separate cairo surfaces slice perfectly — verbose, but exact, and the only
way to keep intricate art (check rings, bevels, soft rims) intact.

Whole-widget objects (`--mode render`) are the fourth option and still the best
one for small, fixed-size art such as the check and radio indicators: slicing
them cuts the ring into pieces that Qt re-antialiases where they meet, which
costs more than the stretch it saves.

### How the hand-drawn themes lay out the nine slices

Three hand-made themes were measured with Qt's own `boundsOnElement()` - the
same call Kvantum uses to place a piece - to see how a person actually draws a
nine-slice: Kvantum's `KvAmbiance`, Gabe Poel's `KvLibadwaita` and Klapeto's
`Luna` (the hand-drawn counterpart of the GTK Luna theme exported further
down).

| | KvAmbiance | KvLibadwaita | hand-drawn Luna |
| --- | --- | --- | --- |
| SVG elements | 1410 | 1218 | 3082 |
| of which slice pieces | 479 | 348 | 394 |
| parts with slice pieces | 67 | 47 | 51 |
| ...with all eight | 53 | 38 | 49 |
| piece thicknesses seen | 1-12 px | 1-24 px | 1-8 px |
| base sample (median) | `<use>` art | 26×26 | 32×32 |

Five conventions run through all three, and they are what the exporter
implements:

1. **A part is one base element plus up to eight**
   `<part>-<state>-<position>` elements, `position` being `top`, `bottom`,
   `left`, `right`, `topleft`, `topright`, `bottomleft`, `bottomright`. The
   base element is what Kvantum stretches into the *interior*; the eight pieces
   are painted around it. Nothing else is needed for a frame.
2. **The piece thickness is the frame margin.** 89% of hand-drawn Luna's
   `frame.*` values equal the measured thickness of the matching piece (mean
   error 0.2px); KvLibadwaita agrees 65% of the time (1.4px) and KvAmbiance 23%
   (3.4px), the latter because its pieces carry a painted shadow that is
   deliberately compressed into the margin. Kvantum scales each piece into its
   slot (`QSvgRenderer::render`), so a piece drawn 6px thick inside a 4px
   margin is squashed by a third: the hand themes that look crisp are the ones
   whose numbers agree.
3. **Corners are square, edges are strips.** A corner piece is thickness ×
   thickness. `top`/`bottom` are full-length strips (Luna draws them 28-32px
   long, the sample width of the part) that Kvantum stretches horizontally
   only; `left`/`right` stretch vertically only. That is why Luna's
   `btn-normal-top` is a 28×4.5 path while its `topleft` is a 4.5×4.5 path.
4. **The base element is a whole frame sample, not an empty middle.** In Luna
   `btn-normal` is the complete 28×28 rounded XP button, `mnu-normal` a flat
   32×32 white plate, `common-normal` a 32×32 box. Drawn into the interior
   rectangle its border falls outside the clip, so only the fill and the inner
   shading survive. The exporter ships the interior alone (a gradient or pixel
   grid at the widget's own width), which is the same thing with less dead art.
5. **Stacking is: edges, then corners, then the interior.** Kvantum's
   `renderFrame()` paints `top`, `bottom`, `left` and `right`, each followed by
   its two corners, so a corner always lands on top of the two edges it joins;
   `renderInterior()` then paints the base element inside the inset rectangle.
   Only when `frame.expansion > 0` is a full-size layer drawn first - the base,
   or a `border-`/`expand-` variant, stretched over the whole widget - and the
   pieces are painted on top of it, which keeps corners round on very large
   widgets.

Attached tabs add pieces instead of changing the scheme: `-top-leftjunct`,
`-left-rightjunct` and friends fill the gaps beside a tab
(`tbf-normal-top-leftjunct` in Luna, `dock-normal-*-junct` in KvAmbiance),
`-separator` is a tab separator, `-pattern` a tileable fill, and
`expand-<part>` the large-widget variant KvLibadwaita uses for combos,
entries, progress bars and tool buttons. None of them changes how the nine
pieces are cut, which is why the exporter can stay with the eight placements
plus the base element.

## Usage

```sh
sudo apt install python3-gi python3-gi-cairo python3-cairo gir1.2-gtk-3.0
./export.sh ~/themes/MyOffice --theme Office2007 --keep-debug
./export.sh ~/themes/MyPluto  --theme Pluto --keep-debug
```

`--theme` accepts any installed GTK3 theme name (or omit it to use the current
one). `--mode render` switches to whole-widget objects. `--sheet hand` lays the
each state's nine pieces touching, exactly as the hand-drawn Kvantum themes are
arranged (the default, `--sheet exploded`, leaves a gap between them so each
piece can be seen and grabbed); neither changes a single pixel of the
rendering. The result is a folder
you copy to `~/.config/Kvantum/<Name>/` and select in Kvantum Manager:

```
MyOffice/
├── MyOffice.svg        # 412 vector objects in 84 state groups
├── MyOffice.kvconfig   # element names, frame widths, sizes, colours
└── MyOffice.colors     # matching KDE colour scheme for Qt apps
```

`--keep-debug` also saves GTK's own render of every widget plus
`preview.png`: **exactly what Kvantum will draw**, produced with Qt's own
`QSvgRenderer`.

## What gets exported

26 elements, 84 states, 412 SVG objects, grouped by state: buttons, line
edits, combo boxes, check boxes, radio buttons (each with checked and
inconsistent/tristate art), scrollbar slider and groove, scale handle,
progressbar and its content bar, menus, menu items, menu bar titles, menu bar,
tooltips, title bars and header sections, windows, generic frames, group
boxes, spin buttons, item views, tabs and tab bodies. Toolbar buttons, dock
titles and toolbox tabs inherit the button/tab definitions, exactly as in
Kvantum's own default theme.

Elements that a window loses focus on also ship `-normal-inactive` art, the
backdrop state Kvantum asks for and GTK paints through `:backdrop`.

### Known gaps

Scroll bars need three attempts, because GTK paints them in three different
ways. The container is captured as applications see it first; GNOME's overlay
scroll bars are painted only while they are hovered, and headless nothing is
hovered, so that comes back empty for Adwaita. The same container is then
shown with overlay scrolling switched off, which paints the bar the theme
declares - that is where Adwaita's flat `#CECECE` trough and its real pill
thumb now come from. Only a theme that paints neither is rebuilt from its own
scroll-bar rules: CSS node names are rewritten to classes on a plain box tree
nested the way the rules expect (`scrollbar > trough > slider`), so gradients,
borders, radii and hover colours arrive as vector art with no picture in them.
The thumb is cut at the bar's full width, transparent margins included, because
Kvantum scales it to the bar's thickness: a thumb trimmed to its painted pill
(5px inside a 12px bar) was drawn 2.4 times too fat. `scroll_width` and
`slider_width` are the measured thicknesses of the two pieces.

The stepper arrows and the thumb's decoration are drawn by *Kvantum*, not by
the theme file: `[Scrollbar]` holds the arrows and `[ScrollbarSlider]` an
optional "grip" indicator. Left out, both came from Kvantum's default theme,
which drew pale undersized arrows and three dark dots in the middle of the
thumb that GTK never paints. The exporter now writes `[Scrollbar]` with the
theme's own text colour (dark arrows, as GTK draws them) and a 10px indicator,
and sets `indicator.size=0` on the slider so no grip is drawn, and the arrows are drawn
on the theme's own button plate (`[Scrollbar] inherits=PanelButtonCommand`),
which is what GTK puts them on. The scroll bar's trough is exported under its
own element name, `groove`, and a scale's trough under `slider`: one capture
used to feed both sections, so they could only ever share art, and Adwaita's
scale trough is a 4px band inside a 15px scroll bar.

What a hand-tuned theme can still do better: an Inkscape nine-slice thumb.
Kvantum stretches whatever single object it is given, so a 2px corner and a
1px border get smeared along an 800px bar. Cutting the thumb into corner and
edge pieces (7px insets, `interior=false`) keeps them crisp. The exporter
cannot invent that geometry from a theme that does not declare it.

The scale's trough (`slider`) is captured from a real scale too, and
`slider_width` is its measured thickness, not the scroll bar thumb's width - a
scale trough is usually much thinner. Adwaita: 4px against 15. The band is
found by shape and rebuilt from the theme's own `scale trough` rules; themes
whose CSS cannot be read back (Adwaita keeps its rules compiled into GTK, the
GTK 3.18 themes name nodes the aliasing does not reach) are cut out of the
scale's own pixels instead: the empty part right of the handle, mirrored to
give it the other rounded end.

The filled part of the groove is the theme's `scale highlight` node and ships
as `slider-toggled`; Kvantum draws the low side of a groove from that state and
the high side from `slider-normal`, so a theme without it lost its fill
entirely. Both states, and their `-inactive` pair, are sliced with the normal
art's frame widths, because Kvantum uses one set of frame widths for every
state.

Both the trough and the handle are shipped **transposed**, i.e. as vertical
art (width across the slider, height along it). Kvantum draws a slider in
vertical space and transposes the painter for a horizontal one, so the
horizontal art of a GTK scale was squeezed along the wrong axis: the trough's
rounded ends were smeared into the middle and the handle's caps landed on its
sides. Vertical sliders looked almost right because a squashed flat band is
still a flat band; horizontal ones did not (finding 59).

The scale handle (`slidercursor`) *is* captured, from a real scale: the widget
is rendered and the handle is found by shape, since it is the only thing that
reaches above and below the trough, which spans the widget. It used to be drawn
from a stand-in *button*, which is where its thick border came from. It scores
100% at 1x, and `slider_handle_width`/`slider_handle_length` are the measured
handle size (across and along) instead of a fixed 16.

Menu items are exported but never scored: in every theme tested their normal
state is transparent by design, and GTK's render of a hovered row includes the
menu panel behind it while the exported object is only the row's own paint. An
empty object here is the theme's own choice of art, not a failed capture; a
hovered row carries the theme's real highlight (finding 31).


- Overlay scroll bars that a theme hides behind hover can still only be
  captured with overlay scrolling switched off (see finding 17). That is the
  bar's non-overlay look, which is what Kvantum draws anyway: it has no
  hover animation.

### A third-party theme: Aztec

`examples/Aztec/` comes from the
[Aztec](https://gitlab.com/bluedxca93/aztec) theme, which is not a tidy
`gtk.css` but a compiled GTK3 theme: one 140 KB `gtk-contained.css`, 129 image
assets and a SCSS source tree. It needs no changes to be imported, only
installing it as a normal theme:

```sh
mkdir -p ~/.themes/Aztec && cp -a aztec/gtk-3.0 aztec/index.theme ~/.themes/Aztec/
./export.sh ~/themes/Aztec --theme Aztec --keep-debug
```

It scores 99.4% mean / 95.9% worst, with buttons, entries and combo boxes at
100%. Two things it exposed, both fixed in the
exporter: a theme can style the *tooltip CSS node* rather than the `.tooltip`
class (a plain box then paints nothing at all, and tooltips were missing from
every export), and theme art is sometimes genuinely transparent — Aztec menu
items have no normal background and appear only on hover. A blank capture is
therefore not automatically a bug.

### Another one: Candy

`examples/Candy/` comes from [candy-gtk3](https://gitlab.com/bluedxca93/candy-gtk3),
a single-directory theme with no `index.theme` at all — so the exporter is
pointed at a directory name of your choosing (Candy here). It scores 99.3% mean
/ 97.3% worst, with buttons, entries and combo boxes at 100%, the menu panel at
99.9% and a 3px frame. Its stylesheet contains one declaration
GTK rejects (`gtk-contained.css:32`, negative values), which GTK drops and the
exporter therefore never sees: the output matches what GTK draws, not what the
author intended.


### Ultimate Mate

`examples/UltimateMate/` is the gnome-look entry
[UltimateMate 20.04](https://www.gnome-look.org/p/1209130/) (its icon pack is the
one Aztec's `index.theme` names). The site itself sits behind a bot check, so it
came from the author's own repository,
[ultimate-mate-2004](https://gitlab.com/bluedxca93/ultimate-mate-2004), which is
the same source. It installs as `UltimateMate` and scores 99.4% mean / 94.9%
worst with buttons, entries and combo boxes at 100% and the menu panel exactly
100%.

Two of its elements are transparent by design: the menu bar and the menu items
have no background until hovered. Both are exported as transparent objects and
left unscored, which is now the general rule for a blank normal state (see
finding 12).

### Pluto

`examples/DevilPluto/` comes from [devil-pluto](https://gitlab.com/bluedxca93/devil-pluto),
the same author as Aztec, Candy and Ultimate Mate. Like Candy it has no
`index.theme`, so it is installed and exported under the name Pluto. It scores
**99.6% mean / 96.6% worst**, with radio buttons and windows at 100%, buttons
and entries at 100%, tooltips 97.7% and the menu panel 99.4%.

Its one low object is the hovered spin button at 96.8%, in line with the same
object in the other themes (95-98%). That theme paints its two arrow buttons in
strongly different hover colours from the field, so a synthesised frame - which
cannot contain child-widget art - differs more than elsewhere. It is also the
element where the comparison is harshest: Kvantum draws the arrows itself.

### Luna

`examples/Luna/` comes from [luna-gtk3](https://gitlab.com/bluedxca93/luna-gtk3),
the Windows XP look: `#ECE9D8` beige surfaces, white fields, `#3399FF`
selection. Like Candy and Pluto it has no `index.theme`, so it is installed and
exported under the name Luna. It scores **99.2% mean / 96.6% worst**, with
buttons, entries, check and radio buttons, menu bars, menu panels, tabs, item
views and the scale handle at 100%, combo boxes at 99.9%, tooltips at 99.7%
and the spin button at 97.3%.

Its lowest object is the generic frame at 96.6% - a plain 1px box whose whole
score is that one line, so any antialiasing difference is the entire number.
Stretched to 160% the mean is 98.9% and the worst 94.7%, the best stretch
result of the six, because its surfaces are the flattest.

### Luna (Cinnamon 22), compared with the hand-drawn Kvantum Luna

The [luna-cinnamon-22](https://gitlab.com/bluedxca93/luna-cinnamon-22) port of
the same XP look exports to the same **84 states / 412 objects / 38 sections**
and scores **99.4% mean / 94.4% worst** at 1x and 99.0% / 89.8% at 1.6x over 68
objects. Its hand-drawn counterpart is
[Kvantum Luna](https://github.com/klapeto/KDE-plasma-luna) (Klapeto, derived
from Phob1an's Expose): 40 sections, 3082 SVG elements, 51 nine-slice parts.
The numbers differ, and it is worth knowing which differences are style and
which are measurements:

| | hand-drawn Kvantum Luna | export of the GTK theme |
| --- | --- | --- |
| sections | 40 | 38 - missing `WindowTranslucent`, `DockTitle`, `TreeExpander`, `SizeGrip`, `Splitter`, `Focus`; extra `Window`, `ToolbarLineEdit`, `ToolbarButton`, `StatusBar` |
| button frame | 5px XP bevel | 3px - GTK draws a 1px border plus an inset highlight |
| entry / menu / tooltip frame | 4 / 2 / 4 | 3 / 3 / 5 |
| generic frame, group box | 4 | 1 |
| scroll bar | 17px wide, 4px frame, 17×35 thumb, `scroll_min_extent=32` | 14px wide, flat trough, 14×40 thumb, `scroll_min_extent=40` |
| scale | 4px trough, 17×35 handle | 6px trough, 27×15 handle |
| check box | 14 | 16 |
| accent / text | `#326AC4`, black text without dimming | `#3399FF`, `#101010` text, `#7E7D74` disabled |

The frame widths and the two scroll-bar sizes are style: the artist redrew
GTK's 1px borders as chunkier XP bevels, and picked a darker blue. Everything
in the right-hand column is measured from GTK's own render, so it is what the
theme looks like in a GTK3 application, not what it looks like in the
designer's Inkscape file. What the hand theme has that the export has not is
still the decoration layer (window buttons, spin and scroll arrows, menu
check marks, focus ring, splitter and size-grip art).

This theme is also where two scroll-bar defects surfaced, both fixed:

- **GTK's stepper buttons were being baked into the bar art.** This theme sets
  `-GtkScrollbar-has-backward-stepper: true`, so GTK paints an arrow button at
  each end of the bar. The capture diffed two scroll positions to find the
  thumb, but the buttons' sensitivity changes between those positions, so the
  "thumb" came out 14×158 - the whole bar, arrows included - and Kvantum drew
  that as the thumb. The capture stylesheet now turns both steppers off (Kvantum
  draws its own arrows), and the thumb is 14×40 as GTK paints it.
- **The minimum thumb length moved from a style property to CSS.** Kvantum's
  `scroll_min_extent` was read from `-GtkScrollbar-min-slider-length`, which
  newer GTK3 themes no longer set; this one says
  `scrollbar.vertical slider { min-height: 40px }` instead, and the export
  wrote no minimum at all. It now reads the orientation-specific CSS length and
  writes `scroll_min_extent=40`.

### Ambiance, compared with Kvantum's own KvAmbiance

Kvantum ships `KvAmbiance` (a hand-made clone of Ubuntu's Ambiance) in
`themes/kvthemes`, so the exporter can be held against the reference it is
trying to reproduce. Exporting Ubuntu's newest `light-themes` package
(`Ambiance`, version 24.04-0ubuntu1, GTK 3.24) gave 84 states / 412 objects
against the hand theme's 1411 shape ids and 42 kvconfig sections (ours: 38).
Four differences were worth fixing, and one group was not:

| | hand-made KvAmbiance | before | after |
| --- | --- | --- | --- |
| button frame (kvconfig) | 3 (its own 3px art) | 8 (radius + slack) | **10/12, the theme's own `border-image-width`** |
| button text margin | 2 | 8 (frame reused as margin) | **0 (padding 5/6 minus frame; GTK content offset is 6/7)** |
| `base.color` / `tooltip` | white / black+white | `#FAFAFA` (entry gradient) / light grey | **`#FFFFFF` / black + white** |
| `light.color` / `dark.color` | white / `#BEBEBE` | `#AAAAAA` / **black** | `#FDFDFD` / `#EEEEEC` |
| scrollbar | `scroll_arrows=false`, `slider_width=4` | arrows drawn, **no thumb at all** | **arrows off, `scroll_min_extent=31`, thumb exported from the theme's own slider rule (as thick as its bar; GTK's 7px margin has no Kvantum equivalent)** |
| check size | 16 | – | **14, measured from the captured indicator** |
| `-normal-inactive` states | button, lineedit, combo, common | none | **all four** |
| title bar / header | `[TitleBar]` + `[HeaderSection]` | absent | **both, from a real header bar** |
| tristate check box | `checkbox-tristate-*` | absent | **`checkbox-tristate-*`, `radio-tristate-*`** |
| scrollbar groove | declared, `interior=false` | crashed, section missing | **declared, interior-less** |

Two of these were outright bugs, not gaps: a theme that paints no trough made
`groove` raise `TypeError` (so the section was missing from every export, and
Ambiance's thumb was never built), and reading the border-image geometry had
never been attempted at all - the frame widths were the corner radius plus two
pixels of slack, which on a border-image theme is not the frame the theme
slices.

The same export, scored with Qt's own `QSvgRenderer` (57 comparable
objects), improved from **98.9% mean / 79.6% worst** to **99.1% / 79.6%** at
1x and from 97.6% / 85.3% to **98.1% / 85.3%** at 1.6x, with twelve more
objects scored. The visible wins are at stretch: combo boxes went from 91.1%
to 96.3% at 1.6x (their frame is now the theme's own 10/12 border-image
slice), and item views from 98.0% to 100%. The tooltip is still the worst
object at 79.6%: it is the one element whose soft shadow rim is kept inside
the nine-slice, and Qt re-antialiases that rim at every edge.

What the hand theme has that the exporter still does not: indicator and
decoration art (arrows, window-button glyphs, spin arrows and separators, menu
check/radio marks, the focus ring, menu shadows, tab close and separator art,
toolbar and splitter grips, resize grip) and the expanded-frame variants
(`ebutton`, `elineedit`, `ecombo`, used with `frame.expansion` for very wide
buttons). Those are drawn by Kvantum from its default theme, which is the one
place an exported theme visibly differs from a hand-tuned one.

### Adwaita, compared with KvLibadwaita

`KvLibadwaita` (Gabe Poel) is the hand-made Kvantum theme closest to the
subject of the default export, so it is the second reference worth checking
against. It declares 44 kvconfig sections and 1219 shape ids; the Adwaita
export has 38 sections and 412 objects. Two things have to be kept apart:
KvLibadwaita is a *redesign* inspired by Materia rather than a measurement of
Adwaita (its text is `#444444`, its highlight `#3c84f7`, its buttons 6px thick,
its check boxes 24px), so its colours and sizes are a style, not a target. The
export tracks the installed GTK Adwaita instead and scores **99.3% mean /
96.5% worst** against GTK's own render (69 objects), 99.1% / 93.4% at 1.6x.
What the comparison did expose were three real defects and one coverage gap:

| | KvLibadwaita | before | after |
| --- | --- | --- | --- |
| scale trough (`[Slider]`) | own `slider` element, `slider_width=2` | the **scroll bar's** trough, `slider_width=15` | **its own capture, `slider_width=4`** |
| scroll bar trough | its own 9px art | invented rounded, bordered 15px bar (GTK paints none inside a scrolled window headless) | **GTK's real flat `#CECECE` trough** |
| scroll bar thumb | pill inside a 9px bar | rebuilt from CSS rules | **cut from GTK's real bar, at the bar's full width** |
| `[ToolbarLineEdit]` | points at `lineedit` | absent (Kvantum's default entry appeared in every toolbar search field) | **present, pointing at this theme's `lineedit`** |
| `[DropDownButton]` | inherits `PanelButtonCommand` | absent | **inherits the button plate** |

`slider_width` was the visible one: it was taken from the scroll bar thumb, so
every `GtkScale` in a Qt application was drawn 15px thick with scroll bar art,
where Adwaita's scale trough is a 4px band. The scroll bar had a second, older
bug behind it: GNOME's overlay scroll bars are painted only while hovered, so
the headless capture of a scrolled window is empty, and the exporter invented a
trough instead. Showing the same container with `set_overlay_scrolling(False)`
paints the bar the theme declares, and both pieces are now cut from it.

What KvLibadwaita has that the exporter still does not: `[Focus]`,
`[Splitter]`, `[SizeGrip]`, `[TreeExpander]`, `[IndicatorArrow]` and
`[DockTitle]`, all of which need indicator or decoration art that GTK will not
paint headless (the focus ring is baked into the focused frame instead). It
also relies on Kvantum's overlay behaviour (`scrollbar_in_view`,
`transient_scrollbar`, `scroll_width=9`), which the exporter does not write:
44 sections against 38.

Two differences are deliberate on our side. `menu_shadow_depth`/`
`tooltip_shadow_depth` are 0 because GTK's shadow is captured *inside* the
frame art, so asking Kvantum for another one would double it. Text colours are
written once in `[GeneralColors]` rather than in every section, because the
export knows the theme's real text, selection and disabled colours and Kvantum
falls back to them.

## Example themes

Every theme in this list was exported from source by the version in this
tarball and verified with Qt's renderer. One folder per theme, and each folder
is a complete Kvantum theme that can be copied straight into
`~/.config/Kvantum/`:

```
examples/Aztec/
├── Aztec.svg            # 519 objects in 99 element states, nine slices drawn exploded
├── Aztec.kvconfig       # element names, frame widths, sizes, colours
├── Aztec.colors         # matching KDE colour scheme
├── preview.png          # what Kvantum draws, composed from the SVG
├── sheet.png            # the whole SVG canvas, as Qt renders it
└── verify-report.txt    # per-object fidelity against GTK's own render
```

The scores are this run's mean and worst per-object fidelity. Adwaita (99.5%
/ 96.5%) and Ambiance (99.2% / 79.6%) are shipped too, exported from the
themes installed on the system rather than from a repository.

| Theme | Source | mean | worst |
| --- | --- | --- | --- |
| Adaero320 | [Adaero-3-20](https://gitlab.com/bluedxca93/Adaero-3-20) | 99.6% | 92.3% |
| AdaeroExperimental | [adaero-experimental](https://gitlab.com/bluedxca93/adaero-experimental) | 99.8% | 97.7% |
| AdaeroV2 | [adaero-v2](https://gitlab.com/bluedxca93/adaero-v2) | 99.6% | 92.3% |
| Aero45 | [aero45-for-gtk3-and-gtk4](https://gitlab.com/bluedxca93/aero45-for-gtk3-and-gtk4) | 99.6% | 92.3% |
| Aero45Brisk | [Aero45-Brisk](https://gitlab.com/bluedxca93/Aero45-Brisk) | 99.6% | 92.3% |
| Aztec | [aztec](https://gitlab.com/bluedxca93/aztec) | 99.6% | 95.2% |
| Candy | [candy-gtk3](https://gitlab.com/bluedxca93/candy-gtk3) | 99.6% | 97.3% |
| Colorless | [colorless](https://gitlab.com/bluedxca93/colorless) | 99.5% | 91.5% |
| Cupertino | [cupertino](https://gitlab.com/bluedxca93/cupertino) | 100.0% | 99.8% |
| DevilClearlooks | [Devil-Clearlooks](https://gitlab.com/bluedxca93/Devil-Clearlooks) | 99.7% | 95.8% |
| DevilEight | [devil-eight-gtk-theme](https://gitlab.com/bluedxca93/devil-eight-gtk-theme) | 99.5% | 97.2% |
| DevilHuman | [devil-human](https://gitlab.com/bluedxca93/devil-human) | 99.6% | 95.6% |
| DevilJaguar | [devil-jaguar](https://gitlab.com/bluedxca93/devil-jaguar) | 98.5% | 57.1% |
| DevilLeopard | [devil-leopard](https://gitlab.com/bluedxca93/devil-leopard) | 99.7% | 96.1% |
| DevilPluto | [devil-pluto](https://gitlab.com/bluedxca93/devil-pluto) | 99.8% | 96.2% |
| Ice | [ice](https://gitlab.com/bluedxca93/ice) | 99.4% | 92.5% |
| IceWater | [ice-water-20-04-gtk3-theme](https://gitlab.com/bluedxca93/ice-water-20-04-gtk3-theme) | 99.8% | 96.9% |
| Luna | [luna-gtk3](https://gitlab.com/bluedxca93/luna-gtk3) | 99.6% | 94.4% |
| Luna40Brisk | [Luna40-Brisk](https://gitlab.com/bluedxca93/Luna40-Brisk) | 99.5% | 94.4% |
| LunaCinnamon | [luna-cinnamon-22](https://gitlab.com/bluedxca93/luna-cinnamon-22) | 99.5% | 94.4% |
| LunaSilver | [luna-silver-gtk3](https://gitlab.com/bluedxca93/luna-silver-gtk3) | 99.6% | 94.1% |
| MillenniumBrisk | [Millennium-Brisk](https://gitlab.com/bluedxca93/Millennium-Brisk) | 99.5% | 89.2% |
| Office2007 | [office-style-back-to-2007-gtk3](https://gitlab.com/bluedxca93/office-style-back-to-2007-gtk3) | 99.6% | 95.3% |
| OxygenBreeze | [gtk3-oxygen-breeze](https://gitlab.com/bluedxca93/gtk3-oxygen-breeze) | 99.6% | 96.7% |
| OxygenSCSS | [oxygen-scss](https://gitlab.com/bluedxca93/oxygen-scss) | 99.5% | 94.2% |
| STK | [stk-simple-theming-toolkit](https://gitlab.com/bluedxca93/stk-simple-theming-toolkit) | 99.6% | 95.5% |
| SurBlx | [sur-blx-gtk3-theme](https://gitlab.com/bluedxca93/sur-blx-gtk3-theme) | 99.4% | 95.4% |
| TX1 | [t.x.1](https://gitlab.com/bluedxca93/t.x.1) | 99.6% | 95.9% |
| UltimateMate | [ultimate-mate-2004](https://gitlab.com/bluedxca93/ultimate-mate-2004) | 99.6% | 94.9% |
| XPCandy | [xpcandy-gtk3](https://gitlab.com/bluedxca93/xpcandy-gtk3) | 99.6% | 95.9% |
| YaruCoffe | [yaru-coffe](https://gitlab.com/bluedxca93/yaru-coffe) | 99.7% | 95.4% |
| YaruNature | [yaru-nature](https://gitlab.com/bluedxca93/yaru-nature) | 99.6% | 95.5% |
| YaruOK | [yaru-ok](https://gitlab.com/bluedxca93/yaru-ok) | 99.6% | 95.9% |
| YaruOKClassic | [yaru-ok-classicstyle](https://gitlab.com/bluedxca93/yaru-ok-classicstyle) | 99.6% | 95.9% |
| YaruSprite | [yaru-sprite](https://gitlab.com/bluedxca93/yaru-sprite) | 99.5% | 94.8% |

DevilJaguar is the one theme where a single object fails rather than trails:
its `titlebar-normal` is a 57% match, because the theme paints that bar with
something the capture does not reproduce. Everything else in it is at 96% or
better. See `examples/DevilJaguar/preview.png`.

## Measured fidelity

Every exported object is rebuilt through Qt and compared against GTK's own
render of the same widget, per-pixel, frame pieces assembled exactly as Kvantum
assembles them (see each `examples/<Theme>/verify-report.txt`). The 1.6x
columns render the
object at 160% and compare against GTK's render scaled by the same amount, which
shows what a stretch does to corners.

| theme | 1x mean | 1x worst | 1.6x mean | 1.6x worst |
| --- | --- | --- | --- | --- |
| Office2007 | **99.6%** | **95.3%** | **98.6%** | **90.8%** |
| Aztec | **99.6%** | **95.2%** | **98.6%** | **90.6%** |
| Candy | **99.6%** | **97.3%** | **98.9%** | **93.2%** |
| UltimateMate | **99.6%** | **94.9%** | **98.7%** | **89.6%** |
| Pluto | **99.8%** | **96.2%** | **98.4%** | **89.0%** |
| Luna | **99.6%** | **94.4%** | **98.8%** | **89.8%** |
| Luna (Cinnamon 22) | **99.5%** | **94.4%** | **98.8%** | **89.8%** |
| Ambiance | **99.2%** | **79.6%** | **97.9%** | **85.3%** |
| Adwaita | **99.5%** | **96.5%** | **98.9%** | **93.4%** |

The same themes before the bounds fix and the per-element mode choice, for
scale: Office 2007 **92.7% / 71.2%**. Every theme's mean is now above 99% (Ambiance 99.2%), and
the worst object in the six hand-picked themes is 95.3% (Office 2007's
tooltip); every spin button in them is now above 95%. Ambiance's 79.6% tooltip is
the shadow-rim exception described above. For comparison, exporting whole widgets
without any slicing scores 83.0% mean / 36.4% worst.

Per object (normal state), all six themes:

| object | Office2007 | Aztec | Candy | UltimateMate | Pluto | Luna |
| --- | --- | --- | --- | --- | --- | --- |
| `button-normal` | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% |
| `lineedit-normal` | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% |
| `combo-normal` | 99.9% | 99.9% | 100.0% | 100.0% | 100.0% | 99.9% |
| `spin-normal` | 96.9% | 95.4% | 98.3% | 97.1% | 96.2% | 96.5% |
| `progress-normal` | 100.0% | 100.0% | 100.0% | 100.0% | 99.9% | 100.0% |
| `checkbox-normal` | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% |
| `radio-normal` | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% |
| `scrollbarslider-normal` | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% |
| `groove-normal` | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% |
| `scarrow-up-normal` | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% |
| `slider-normal` | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% |
| `slidercursor-normal` | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% |
| `tooltip-normal` | 95.3% | 97.7% | 97.7% | 97.7% | 97.7% | 97.7% |
| `menu-normal` | 100.0% | 98.8% | 99.8% | 100.0% | 99.4% | 99.6% |
| `tabframe-normal` | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% |
| `menubaritem-focused` | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% |
| `menubaritem-toggled` | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% |
| `slider-toggled` | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% |
| `tab-normal` | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% |
| `menuitem-focused` | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% |
| `menuitem-toggled` | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% |

The four rows above that 2.15 added or filled in - the lit menubar title, the
slider's filled half and the tab - are at 100% in all eight themes checked
(office, Aztec, Candy, UltimateMate, Pluto, Luna, Ambiance and Adwaita), and
so is every `slidercursor` state. 2.16 cut the menu row into nine pieces as
well, so its lit states are scored now instead of being passed over: they are
at 100% at their own size in those six themes, and 94.4-100% at 160%, which is
exactly the stretch a whole-row object used to get.

A progress bar whose fill repeats is now tiled (`interior.x.patternsize`) and
scored against GTK's own bar as well, and the pitch is GTK's: 34px in
DevilClearlooks, DevilHuman and the five Yaru themes, 20px in DevilJaguar,
DevilLeopard and STK, at 96.0-99.7% fidelity. The other 27 themes paint a
smooth fill, are still shipped as one object, and stay unscored - a smooth
gradient tiled would seam every few pixels, so it is left to stretch.

Same-run rows that are blank on purpose, or were unfilled before 2.15
(Office2007 | Aztec | Candy | UltimateMate | Pluto | Luna):

| object | Office2007 | Aztec | Candy | UltimateMate | Pluto | Luna |
| --- | --- | --- | --- | --- | --- | --- |
| `menuitem-normal` | – | – | – | – | – | – |
| `menubaritem-normal` | – | – | – | – | – | – |
| `menubaritem-normal` | – | – | – | – | – | – |
| `menubar-normal` | 100.0% | 100.0% | 100.0% | – | 100.0% | 100.0% |
| `toolbar-normal` | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% |
| `tab-normal` | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% |
| `itemview-normal` | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% |
| `common-normal` | 98.4% | 98.1% | 97.3% | 98.1% | 99.3% | 97.8% |

The scroll bar rows were all `–` before 2.14: nothing was scored because nothing
was exported. They are 100% at their own size now, and the stretch column is
where the bar shows its seams - `scrollbarslider-normal` at 160% scores 89-96%,
because a 2px radius on a 14px pill is not the shape GTK drew when it is
stretched lengthways. That is why the art is nine-sliced rather than stretched.

What the numbers say:

- **Exact-size art is now exact.** Check boxes, radio buttons and menu bars are
  shipped as one image of precisely their box, because Qt's
  `boundsOnElement()` ignores clip paths and GTK sometimes paints beyond the
  widget - both inflated the measured bounds and made Kvantum scale the art
  wrong. Radios went from 94-95% to 100%, check boxes to 100%, and the two
  themes whose menu bar scored 93.6-93.9% (a 20% oversized gradient rect) now
  score 100%.
- **Sample the plain background, not what sits on top.** The gradient sampler
  used the widget's middle column, which on a spin button lands on the arrow
  buttons. It now reads the left third and keeps transparency, so an empty
  progress trough stays empty instead of turning into a black bar.
- **Plain frames are exact once they are the pixels.** Buttons, entries and
  combo boxes reach 100% (one combo 99.9%) after the frame band stopped being a
  reconstruction: no seam is left between the border and the body, and no
  shadow line is drawn where the theme painted none.
- **Intricate art is best sliced.** Menus reach 98.8-100% because slicing keeps
  a soft rim in the frame, where a stretched interior would squash its corners.
- **Panels with a diagonal fill need a grid, not a gradient.** The stretched
  middle is a real gradient where the field shades in one direction only, and a
  coarse grid of sampled pixels where it shades in both - otherwise Aztec's
  menu panel flattened into horizontal bands as soon as it was stretched.
- **The spin button is the last weak spot**, at 94.9-98.4%: its two arrow
  buttons are child widgets that light up on hover, and they live in the
  interior, which Kvantum stretches. It is also the one element where the comparison is
  harsher than reality - Kvantum draws the arrows itself, so what ships is the
  frame, not the whole control.

## Findings that shaped the design

1. **Nine-slice by clipping is impossible; by synthesis or per-piece surfaces
   it works.** See above: `boundsOnElement()` ignores clip paths, so pieces have
   to be drawn — either synthesised from measured geometry, or rendered into
   their own surfaces.
2. **Qt stretches art that does not fill its box.** `boundsOnElement()` returns
   the *painted* extent, and `render(painter, id, rect)` maps that extent onto
   `rect`. A check indicator sitting inside a larger widget allocation therefore
   arrives 1.4× too big. One invisible full-size rect per object pins the bounds
   and made the difference between 71% and 96–100% on every indicator. This was
   the single largest accuracy bug in the prototype.
3. **Duplicate element names silently collide.** The generic frame and the tab
   body were both exported as element `common`, producing two
   `<g id="common-normal">` in one SVG; Qt resolved the frame to the tab body's
   art and the light-theme frame scored 35%. One object id per element, always:
   the tab body is `tabframe`, and the frame went to 97.4%.
4. **A popup needs a real size and a shadow-aware frame.** Label-less menu items
   collapse, so the menu allocated 220×8 — an eighth of the object was shadow.
   Requesting 170×26 per item fixed the geometry; measuring where the render's
   opaque core starts (`capture.opaque_insets`) widened the frame to the
   translucent rim, so Kvantum keeps the shadow's corners at 1:1 while
   stretching only the straight edges.
5. **GTK rasterises blurred box-shadows.** Fills, gradients, borders and rounded
   corners stay vector; a blurred shadow arrives as an embedded base64 PNG plus
   a `<mask>`. That is why plain renders scored 83% on the light theme, and why
   shadow-bearing objects need the rim inside the frame rather than a stretched
   interior.
6. **Read colours from pixels, not from CSS.** GTK3 themes paint most surfaces
   with `background-image` gradients, so `get_background_color()` returns
   transparent black; sampling the rendered widget gives the real colours.
7. **Suppress glyphs Kvantum draws itself.** A small app-priority CSS provider
   hides the combo arrow and spin button arrows, so they are not baked into the
   object and then drawn a second time by Kvantum.
8. **Some widgets paint into their own `GdkWindow`** (`GtkTextView`, the entry
   inside a spin button). `gtk_widget_draw()` misses that part; `itemview` is
   replaced by a styled box, the spin button keeps a plain interior.
9. **`--name` is unusable as a flag.** GLib's option parser strips it while
   `gi.repository.Gtk` is imported, hence `--output-name`.
10. **GTK will not paint a state on request.** `set_state_flags()` handles
   `disabled` and `checked`, but GtkButton recomputes hover/active while drawing,
   so `focused` and `pressed` came out identical to `normal` - five states of the
   same pale blue gradient. The exporter now reads the theme's CSS, repeats every
   `:hover` / `:active` rule without the pseudo-class, and installs that above the
   theme *before* the widget is constructed (a provider added afterwards never
   reaches an existing widget). Office 2007 then exports its real hover
   (#FFFAD1) and pressed (#FABB6B) gradients instead of three copies of normal.

11. **Themes style CSS nodes, not just classes.** Aztec's tooltip rule is
    `tooltip.background`, and a `Gtk.Box` with the `tooltip` class matches
    nothing, so the exporter painted a plain sand rectangle. Rewriting the node
    name to a class (`.g2k-tooltip`) with the same CSS lets an ordinary box wear
    the node's art. Every theme exported before this was silently missing its
    tooltip object.
12. **A blank capture is sometimes the truth.** Menu items are transparent until
    hovered, in all four themes. The blank guard now distinguishes "GTK never
    drew this" (skip the element) from "the theme paints nothing here" (export
    the transparency, leave it unscored).

13. **Small fixed-size art has to be an image.** A vector copy of a radio
    button carries clip paths whose geometry sits outside the widget; Qt's
    bounds measurement ignores the clip, so Kvantum scaled a 22x22 ring as if
    it were 18x18 and the circle came out squashed. Menu bars had the mirror
    problem: GTK painted a 20% oversized gradient rect, so the object measured
    285 units wide instead of 238. Emitting one `<image>` of exactly the box
    gives bounds that cannot be wrong: 94-97% became 100%.
14. **Transparency is a colour.** The geometry sampler mapped unpainted pixels
    to a dark grey, which painted Adwaita's progress trough - a bar that is
    empty except for a bottom highlight - as a solid black strip. Stops and
    borders now carry their alpha, and an empty trough exports empty.

15. **A check box is only checked if it is switched on before it is shown.**
    GTK resolves both the tick and the checked background when the widget is
    realised. Capturing it with the `CHECKED` state flag, or switching it on
    after `show_all()`, produced a box that looked empty in every theme - which
    is exactly what Kvantum then drew.
16. **A tab crop has to be pixels, not a vector fragment.** A notebook paints
    its page through its own window, which ignores a cairo clip, so a fragment
    of a notebook carried the page and the notebook frame into the tab object
    and Qt measured it far too big. Cutting an exact-size image instead is
    immune, and the tab states that matter are just three: `normal`,
    `focused` and `toggled` (the selected tab, which is a different shape).
17. **GTK3 does not paint a scroll bar headless at all.** The bar draws through
    its scrolled container, and redrawing after a scroll changes nothing, so no
    trough or thumb can be photographed here. Both are drawn instead from the
    theme's own scroll-bar CSS rules (findings 22 and 25) - the trough keeps a
    1px border so it cannot read as a flat block, and a theme with no trough
    (Adwaita) stays blank.

One more thing worth knowing: tick marks and other symbolic icons are SVG
assets, so gdk-pixbuf needs its SVG loader registered. Without it GTK silently
draws check boxes with no tick at all, which looks exactly like an export bug.

18. **A notebook frame has to be drawn without a notebook.** Kvantum cuts the
    TabFrame under the active tab, and a frame caught from a notebook with tabs
    carried a strip of the selected tab into every notebook frame. The frame is
    now drawn from a plain frame widget, which has no tabs to leak into it.
19. **A toolbar is a toolbar, not a header bar.** The export renders a real
    toolbar, using the theme's `.primary-toolbar` art when it has any and the
    plain `.toolbar` node otherwise. A header bar is a different widget with
    different art, so it never stands in for one.
20. **Small indicators need their margins removed.** Qt measures an object at
    its painted bounds, so the empty space around a 16px check mark made it read
    as too small. Check boxes and radio buttons are trimmed to their painted
    pixels and rendered at twice the size, which also keeps the tick crisp.
21. **A menu item is a row inside a posted menu.** Photographing one in
    isolation is the most fragile step in the export, and the colour-only
    version that replaced it lost the hover art. A row of a real posted menu is
    captured now (finding 28): transparent at rest, the theme's own highlight
    on hover.
22. **Scroll bars are drawn, not photographed.** GTK never paints a bar
    headless, so the trough is a box tree wearing the theme's own
    `scrollbar trough` rules and the slider is a real button wearing its slider
    rules - a button brings the theme's frame, radius and hover/pressed art with
    it instead of a flat block.

23. **The SVG is laid out as a sheet of exploded nine-slices.** Every object
    group is translated to its own spot, and inside a state's cell its nine
    pieces are drawn in their nine-slice arrangement - interior in the middle,
    `top` above it, `bottom` below it, a corner in each corner - pulled apart by
    a gap as wide as the frame is thick. The file therefore opens in Inkscape as
    a grid of nine-slice diagrams, one state per cell, in the same order as
    `preview.png`, in the same arrangement the hand-drawn themes are written in
    (finding 53). The pieces are one shape when the gap closes, which is why
    they need the gap to stay separately visible and editable. Kvantum reads
    only object ids and bounds, so the arrangement is invisible to it and the
    fidelity numbers are unchanged. The preview and render sheets use a light
    grey backdrop, while fidelity is still measured over the same fixed
    backdrop as earlier releases, so the two sets of numbers stay comparable.

24. **A button is not a menu item.** For a while the item was dressed as a
    button so GTK would paint it. That smuggled the button's rounded panel and
    drop shadow into every menu row, so the trick was dropped in favour of
    posting a real menu and taking a row from it (finding 28).
25. **A slider's groove and its handle are two elements.** Kvantum's `[Slider]`
    is the groove and `[SliderCursor]` is the handle. The exporter used to point
    `[Slider]` at the handle, so Kvantum painted the whole groove with handle
    art and then took the handle itself from the default theme. The handle is
    now `slidercursor`, the groove uses the same `slider` element as a
    scrollbar's trough (as Kvantum's own themes do), and both carry the theme's
    art.
26. **An inset box-shadow has to be the pixels, not a guess.** Almost every theme
    here draws its 1px highlight and shade with `box-shadow: inset 0 1px ...`.
    Measuring a border width and painting it back, then hunting for the
    one-pixel step and redrawing it separately, put the line a row or two off in
    several themes and left a hard dark edge where the theme had a light one.
    The frame pieces are the theme's own pixels now (finding 32), so a shadow is
    where it was painted.

27. **A menu bar title is its own element.** Kvantum has `[MenuBarItem]`,
    separate from `[MenuBar]` and `[MenuItem]`, and the exporter now fills it
    from the title's own node inside a real menu bar. Taking the bar's whole
    rectangle instead pulled in the bar's full-width border and background, and
    Qt then scaled the title art down to fit those oversized bounds. Most
    themes paint nothing in the title at rest, so the normal state ships
    transparent and the bar shows through - which is what GTK does.
28. **Menu items are photographed inside a posted popup.** The rows come from a
    small real menu: the art is the row's own paint (paths and gradients), the
    resting state is usually empty, and hovering keeps the theme's highlight.
    The row is left unscored because GTK's render of it includes the menu panel
    behind, while the object only carries the row's own paint, which Kvantum
    lays over that panel.
29. **A shadow plate is wider than the widget it shadows.** Qt measures an
    object from every shape it can find and ignores clip paths, so GTK's
    nine-slice shadow tiles parked outside the box made a 150x34 menu item
    measure 180x48 - and Qt then shrank the art to fit. Shadow tiles, and any
    clip path that reaches outside the box, are now dropped: items and menu
    bars measure exactly their box again. The menu panel is also trimmed to its
    opaque core, so the blurred rim around GTK's popup can no longer ship as a
    strange shadow around every menu.
30. **Kvantum looks objects up by state, so a missing state is missing art.**
    Its `getState()` asks for `normal`, `focused` (hover), `pressed` (clicked)
    and `toggled` (checked, or a menu row whose submenu is open), and anything
    the theme does not define silently falls back to Kvantum's default theme.
    That is how a dragged scrollbar thumb turned beige and a checked menu row
    lost its highlight. The scrollbar slider, the scale handle and menu rows
    now ship `pressed` and `toggled` as well, alongside `normal`, `focused` and
    `disabled`.
31. **A menu row's highlight is wider than the row.** GTK paints a row's whole
    background as one rect that runs into the menu's padding and is clipped by
    the popup - Adwaita draws a 240x31 rect for a 200x26 row. The shadow-plate
    rule dropped everything that reached outside the box, which left every
    menu item an empty object with no hover highlight at all. Rects are
    trimmed to the row now, which is exactly the part GTK shows.
32. **A seam of page colour around every control.** A synthesised frame is a
    reconstruction: a measured border width, a measured radius, an arc drawn
    back. Wherever a theme insets a highlight between its border and its fill,
    the two disagree by a pixel or three and the widget's own background shows
    through - which on a button reads as a gap between the border and the body,
    in one to three columns or rows, beside every corner. Encoding the frame
    band from the render removes the reconstruction: the button diff fell from
    1-3% to under 1%, and the frame is still plain `<rect>`s, so nothing falls
    back to a bitmap.
33. **One group per state, and no text in the document.** The pieces of a state
    used to be siblings scattered around the interior, which made a button hard
    to select or move as a unit in Inkscape. Every state now sits in its own
    container (`g2k-button-normal` holds `button-normal` and its eight border
    pieces), and the printed labels are gone: names are ids now, nothing else.
    Kvantum asks only for the ids inside a container, so neither the nesting nor
    the missing text changes anything for it.
34. **A border that scales is not a border.** The menu panel, the menu bar item
    and the tab frame were each shipped as *one* object with `frame=false`, so
    Kvantum stretched the whole thing: a 1px border arrived thicker on a big
    menu than on a small one, and a rounded corner smeared into an oval. All
    three are nine-sliced from their own pixels now (frame pieces at real size,
    only the middle stretches), with `frame=true` and the frame widths in the
    kvconfig. The tab frame is a single painted pixel of border, which is
    exactly what a stretched object was scaling.
35. **A slider handle is not a button.** Both handles were photographed from a
    stand-in `Gtk.Button` because their real widgets have no widget of their
    own. The button brought its own art: Adwaita's scale handle shipped as a
    36x34 push button with a thick frame, drawn at a fixed 16x16, and the scroll
    bar thumb as a 36x40 button squashed into a 12px bar. The scale handle is
    now cut out of a real scale render, and the thumb from a plain box in the
    theme's slider rules (or GTK's own thumb where the bar paints). The
    kvconfig's `slider_handle_width/length`, `slider_width` and `scroll_width`
    are the measured art sizes instead of constants.
36. **GTK draws the scale's value on top of the handle.** The "0.5" label sits
    just above it, and the handle is found by shape, so the number came along in
    the cut and made the exported handle 38px tall instead of 21. The capture
    scale now switches its value label off.
37. **A transparent border is not part of the thumb.** Adwaita declares its
    scroll bar thumb as a thin pill inside a 4px *transparent* border; keeping
    the widget box made the art 15px wide where the theme paints 6, and the
    thumb then sat too fat and too far off-centre in the bar. Handles are
    trimmed to the pixels they actually painted before they are exported.

38. **A stretched bitmap is what made bars look blurry.** The trough used to be
    a 14x160 embedded PNG of the theme's scrollbar box, and the thumb a flat
    rect or a 40x48 button-sized PNG. Kvantum stretches whatever it is given,
    so an 800px bar got a smeared 14px picture: soft edges, the gradient
    running lengthways, and a thumb thicker than the bar it sat in. Both are
    now vector fragments of a box tree wearing the theme's own rules, and the
    thumb is built at the measured bar width (14-16px depending on the theme)
    instead of the scrollbar widget's allocation (40px). The `.kvconfig`'s
    `scroll_width` and `slider_width` are those two art widths, so nothing is
    rescaled on the way in.

39. **The dots on the thumb were Kvantum's, not the theme's.** A scrollbar
    slider picked up a decorative "grip" indicator from Kvantum's default
    config: three dark dots, drawn dead centre on a thumb whose own rules never
    put them there. GTK's scrollbar has plain slider plates and dark triangular
    steppers at both ends. The kvconfig now sets `indicator.size=0` there, and
    writes a `[Scrollbar]` group so the arrows Kvantum draws use the theme's
    text colour instead of the default theme's pale one.

40. **The scroll bar's plates, and why the trough had the wrong art.** Two
    things from a hand-corrected Office2007 theme were adopted: the steppers
    draw on the theme's button plate (`[Scrollbar]
    inherits=PanelButtonCommand`, `indicator.element=arrow`), and the trough
    finally has its own element name. Kvantum calls a scrollbar's trough
    `groove` and a scale's groove `slider`; the exporter had been pointing both
    sections at one capture, so the bar's trough and the scale's groove were
    the same object by construction - a 16x130 slab with a grey border, whatever
    the bar actually looked like.

41. **A border-image theme states its own nine-slice.** Ambiance paints
    buttons with `border-image-width: 10px 12px 10px 12px` and
    `border-image-slice: 10 12 10 12`. Those are the pixels the theme itself
    never scales, which is exactly what Kvantum's frame widths mean, so they
    are read from the CSS instead of guessed from the corner radius. The guess
    (radius plus two pixels of slack) gave 8px; the theme says 10 and 12.
    Parsing it took three care points, all now in `states.frame_slice`: a
    section comment above a rule becomes part of the selector text, a `/` in a
    `url()` is not the slice/width separator, and `"10px"[:-3]` is `"1"`.
42. **Padding is not the text margin.** Kvantum draws a label at
    `frame + text.margin`, GTK at `border + padding`. Using the frame insets
    as the margin counted the frame twice, so every Ambiance button label sat
    20px from the edge where GTK puts it at 6. The margin is the difference
    between the two, floored at zero - which is also why the hand-made
    KvAmbiance pairs frame 3 with margin 2.
43. **Named colours first, pixels second.** Old themes declare
    `@define-color base_color`, `button_bg_color`, `tooltip_bg_color` and
    friends; reading those is exact, while sampling guesses the colour of
    whatever art lies on top. Ambiance's tooltip is black-on-white by
    definition but sampled as the window's beige, and its `base.color` came
    back as the entry gradient's `#FAFAFA` instead of white. Sampling stays as
    the fallback, now composited over the window colour (cairo stores
    premultiplied ARGB, so un-premultiplying near-transparent border pixels
    produced a black `dark.color`).
44. **A theme can turn the scroll bar's steppers off.** Ambiance sets
    `-GtkScrollbar-has-backward-stepper: 0` and asks for a 31px minimum
    slider; Kvantum's default drew two arrows the theme never paints. The
    kvconfig now reads `scroll_arrows` and `scroll_min_extent` from the
    theme's own declarations, and the exported thumb is trimmed to the pixels
    the theme painted (a 3px pill inside a 10px slider), so `slider_width`
    matches the art instead of the bar's full thickness.
45. **Backdrop is CSS, not a state flag.** `-normal-inactive` art is what
    Kvantum asks for in an unfocused window, and GtkButton recomputes its own
    state while drawing, so setting `Gtk.StateFlags.BACKDROP` did nothing.
    The theme's `:backdrop` rules are repeated without the pseudo-class, the
    same trick that already reached hover and pressed art - now the export has
    real inactive buttons, entries, combos and frames.
46. **An unpainted disabled indicator still needs a footprint.** Ambiance
    draws no disabled check box at all; falling back to the whole twice-scaled
    allocation produced a blank 56x44 object where the art is 28x28, and
    Kvantum stretched that over the control. The last size the indicator did
    paint is the right footprint for an invisible object, and a disabled
    scroll bar thumb reuses the normal art.
47. **Tristate is a property, not a flag.** Kvantum asks for
    `-tristate-normal`/`-tristate-focused`; GTK only draws the indeterminate
    mark when the check button's `inconsistent` property is set before it is
    realised. The flag alone produced a box that looked unchecked, the same
    trap as the checked state (finding 15).

48. **A scale's trough is not the scroll bar's trough.** Kvantum has one
    element for each and one `slider_width`, and the two are drawn very
    differently: Adwaita's scale trough is a 4px band, its scroll bar a 15px
    bar. Feeding both from one capture (and taking `slider_width` from the
    scroll bar thumb) drew every `GtkScale` 15px thick. KvLibadwaita, the hand
    theme, has always had a separate `slider` element. A capture of each is
    the only honest answer; `slider_width` is now the band's measured height.

49. **Overlay scroll bars are invisible headless, and can be asked to show.**
    GNOME's scroll bars are painted while hovered, so a scrolled window
    captured without a pointer paints none of its bar and the exporter
    invented a trough from the theme's CSS: a rounded, bordered 15px bar where
    Adwaita paints a flat `#CECECE` one. `set_overlay_scrolling(False)` on the
    same container paints the bar the theme declares, and both the trough and
    the thumb are then cut from GTK's own pixels. Tweaking scroll positions
    instead fails: the bar fades out again at the second position.

50. **A section's existence is itself fidelity.** KvLibadwaita's 44 sections
    against the export's 38 showed two that need no new art at all: a toolbar
    entry is the ordinary entry on the toolbar's plate (`[ToolbarLineEdit]`
    can point at `lineedit`, exactly as the hand theme does), and a drop-down
    button is the button plate plus an arrow (`[DropDownButton]` can inherit
    `PanelButtonCommand`). Without them Kvantum draws its *default* theme's
    entry and button in those places, which is the one thing a section that
    points at existing art never does.

51. **A theme's scroll steppers are not part of its trough or thumb.** Luna
    enables both steppers, and the two-position diff that finds the thumb also
    saw the arrow buttons change sensitivity between the positions: the
    measured "thumb" was the entire 14×158 bar, arrows and trough included,
    and Kvantum painted that as the slider. Turning the steppers off in the
    capture stylesheet (`-GtkScrollbar-has-backward-stepper: 0`) leaves the
    bar Kvantum actually composes - it draws its own arrows - and the thumb
    shrinks to GTK's real 14×40 pill. A theme's `scroll_arrows` flag comes from
    the theme's own CSS, not from the capture, so the information is not lost.

52. **`scroll_min_extent` outlived its style property.** It was read from
    `-GtkScrollbar-min-slider-length`; modern GTK3 themes express the same
    minimum as `scrollbar.vertical slider { min-height: 40px }` and the export
    silently wrote nothing, leaving Kvantum's own default. Reading the
    orientation rule (`vertical`, not the generic 12px cross-section rule and
    not the `fine-tune` one) gives Luna 40px and Ambiance its unchanged 31px.

53. **A board of exploded slices is free; a board of loose strips is not.**
    Kvantum asks for one object at a time by id and maps its bounding box into
    the slot it is painting, so where an object sits on the canvas is nobody's
    business but the person opening the file. Drawing each state as its nine
    slices, pulled apart by a gap, therefore costs nothing and buys the one
    thing the file is for: you can see that a widget *is* nine pieces, and each
    piece can be selected on its own. Putting them back together is the wrong
    choice - a seam that tiles perfectly merges nine objects into one shape and
    the slicing becomes invisible. The gap is the frame's own thickness, kept
    between 6 and 12px so a 1px hairline still separates.

    The arrangement was checked the way the claim deserves, and the weaker
    version of it did not survive: with the pieces assembled, one object per
    theme rendered 1/255 differently after being moved, because Qt rasterises
    gradients in device space. With the exploded gap, all 412 objects of all
    three themes render bit-identical to the previous document through
    `QSvgRenderer` at the size their section declares, and their markup is
    identical apart from the placement. All translations are integers for the
    same reason; a half-pixel offset softened every edge of the object it
    touched.

54. **Kvantum's scroll bar is not nine pieces, and its arrow plate is not a
    frame.** Reading `Kvantum.cpp` settled both: the groove is drawn only when
    the bar is exactly `scroll_width` wide (`if (r.width() <= scroll_width)`),
    so a trough art narrower than the bar leaves a blank strip; and the two
    steppers are drawn with `default_frame_spec()`, i.e. an *interior* and no
    frame, so `inherits=PanelButtonCommand` can never give them GTK's plate.
    The plate has to be part of the indicator art: the theme's own stepper
    button is exported as `scarrow-up`/`scarrow-down` and `indicator.size` set
    to its thickness, since Kvantum stretches the art to
    `min(indicator.size, extent)` and leaves the rest of the bar as trough.

55. **`interior=false` draws nothing, not "the frame only".** `[ScrollbarGroove]`
    was emitted with both `frame=false` and `interior=false` because only the
    sliced elements set `interior`: the trough of every theme was invisible and
    the bar showed the window behind it. Every section now always names an
    interior element.

56. **A bar is not one bitmap.** The thumb, the trough and the scale's trough
    are 1px borders around a flat or graded middle: shipped as a single object
    and stretched, a 1px border became a 3px smear and a 2px radius became an
    ellipse. Each is nine-sliced with insets measured from the pixels
    (`capture.art_insets`), so every band that is a line in GTK stays a line in
    Kvantum.

57. **`slider_handle_width` is the thickness, `length` is the span.** They were
    swapped. Kvantum uses `PM_SliderControlThickness` (`slider_handle_width`)
    as the *height* of a horizontal slider's groove and click area, so the
    handle art's height belongs in `slider_handle_width` and its width in
    `slider_handle_length`. Swapped, Luna's 15x27 handle was drawn 27 thick on
    a 6px trough.

58. **Two silent CSS refusals, and one destroyed-window render.** Ambiance
    exported a thumb with no art at all, for three independent reasons: its
    rules are written GTK 3.18 style (`.scrollbar.slider`), and rewriting both
    node names produced `.g2k-bar..g2k-slider`, a selector GTK rejects; its
    colours are `@define-color` tokens, which the alias sheet did not carry, so
    `alpha(@selected_bg_color, 0.8)` named an unknown colour and the rule was
    dropped; and its thumb is translucent, which the "did it paint?" test
    (fully opaque pixels) reported as blank. The stand-in CSS now keeps the
    theme's own `@define-color` lines and collapses the doubled dot, and paint
    is judged by any non-transparent pixel. The vector fragment is also taken
    *before* the window is destroyed: a detached widget renders empty, which is
    why a thumb that scored 100% on the sheet could still be a transparent
    object. Ambiance gets a thumb it never had; the one thing that stays
    different is its width - GTK insets the pill with a 7px `margin`, which a
    plain box is not told about, so the exported thumb is as thick as its bar.

59. **Kvantum draws a slider's groove and handle in vertical space.** In
    `QStyle::CC_Slider`, a horizontal slider's groove rect is transposed with
    `grooveRect.setRect(y, x, height, width)` and the painter is transformed
    with `scale(1,-1); rotate(-90)`; the handle gets the same treatment. The
    art is therefore always *width across the slider, height along it*.
    Exported horizontally - the obvious thing, since GTK's scale is horizontal
    - the trough's rounded ends were squeezed along the length and the
    handle's caps landed on the wrong sides. A vertical Qt slider looked almost
    right (a squashed flat band is still a flat band); a horizontal one did
    not, which is exactly what was reported. Both pieces are transposed before
    export, so one piece of art is right for both orientations.

60. **A slider's filled part is a second state, not a colour.** Kvantum paints
    the low side of a groove from `slider-toggled` and the high side from
    `slider-normal`, and asks for both with `-inactive` in an unfocused window.
    Only `-normal` was exported, so every filled scale was drawn empty. The
    fill is the theme's `scale highlight` node - and it has to be sliced with
    the *trough's* frame widths: Kvantum slices every state with the normal
    art's frame, and a flat fill has no bands of its own to measure, so sliced
    by itself only the interior object existed and the fill came out as a one
    pixel line.

61. **A menubar title has four lit states and only hover was painted.**
    `getState()` maps `State_On` and `State_Selected` onto "toggled", and
    `CE_MenuBarItem` draws the title's panel for every status except "normal".
    `pressed` and `toggled` were captured with ACTIVE/CHECKED, and GtkMenuItem's
    highlight is a `:hover` rule, so nothing was painted: the title of the menu
    you have open - the one state a user sees most - never lit up, in any
    theme. Both are now the hover art, exactly like the menu rows.

62. **A menubar has a text colour of its own.** Ambiance and Pluto paint a dark
    bar with light text, and Kvantum takes a menubar's label colour from
    `[MenuBar]`'s and `[MenuBarItem]`'s `text.normal.color`. The export wrote
    neither, so Kvantum fell back to the window's text colour: dark on a dark
    bar. The bar's own colour, its titles' hover colour and their disabled
    colour are probed from GTK and written per section.

63. **`get_padding()` and `get_border()` take a state, and the failure was
    silent.** Called without one they raise, and `probe_text_margins()` caught
    the exception and returned zeros - so no element in any theme ever got its
    text padding. Tabs were the visible case: their labels sat flush against
    the tab's edge. With the state passed, margins become what GTK actually
    pads with (Luna's buttons: 14px), and a tab's padding is measured from the
    gap between two tabs' labels - real GTK layout instead of the guessed 9px.

64. **A menu row's label has a colour of its own, and it is not the window's.**
    On a light theme with a dark highlight (Aztec, Pluto) GTK writes white
    there; Kvantum draws a hovered row's label from `[MenuItem]`'s focus
    colour. The section had no text colours at all, so Kvantum used the window's
    text and painted black on black: the selected row read as an empty bar with
    a radio mark. The row's normal, hover and disabled colours are probed from
    a posted popup and written, with focus/press/toggle all taking the hover
    colour because all three use the hover art.

65. **A menu row is a plate, so it has to be sliced.** Shipped as one object,
    the row's art was stretched to the item's width: IceWater's 1px border came
    out as one blurry double line on a narrow menu, and as a visibly fat frame
    on a wide one. The row is now nine-sliced from its own pixels, so the border
    and the corner radius keep their size and only the middle stretches - 100%
    at its own size, 94-100% at 160%.

66. **A tab ends where the page begins.** The tab art's height was the label's
    offset plus the label plus that padding again, which reached two rows past
    the tab strip into the page - so every tab carried a strip of the page's
    colour along its bottom edge. GTK allocates the page immediately below the
    tabs, so its own y is the honest bottom.

67. **Kvantum can repeat an interior, and a repeating progress fill wants it.**
    GTK paints some progress fills with a repeating gradient (DevilHuman's
    diagonal stripes, the Yaru themes, STK) and repeats it at a fixed pitch as
    the bar grows. Kvantum draws `[ProgressbarContents]` into the fill rect and
    stretches it, so the pitch grew with the bar. `interior.x.patternsize`
    makes it tile instead: the fill is shipped as one cap, one period and one
    cap, with the frame's own border at each end and the middle repeated. The
    period is measured from the captured art (a repeat is a sharp minimum of
    the column-profile distance; a gradient has no minimum and is left to
    stretch), and all ten themes that repeat come out at GTK's own 34px or
    20px pitch.

## Next steps

- Emit the remaining indicator glyphs (spin arrows, tree expanders, radio
  marks) cropped from the captured widgets, the way the scroll bar's steppers
  now are, so they stop falling back to Kvantum's default theme.
- Find a repeating fill's period as a fraction rather than a whole pixel: a
  theme whose pitch is 33.3px tiles at 33 and drifts a third of a pixel per
  repeat. None of the 37 exported themes does, but a hand-written one could.
- Emit the expanded-frame art (`frame.expandedElement` + `frame.expansion`) from
  a wide capture, so long buttons keep their corner art at full width the way
  the hand theme does.
- Add the sections that still need art Kvantum draws itself: `[Focus]`,
  `[Splitter]`, `[SizeGrip]`, `[TreeExpander]`, `[IndicatorArrow]` and
  `[DockTitle]` (KvLibadwaita's remaining six).
- Tighten the remaining 90–95% objects: radio rings (edge-dominated, so
  placement-sensitive), Office 2007's shadowed menu bar, and item views.
- Choose the mode per element by measurement instead of by hand: capture both,
  score both against GTK's render, keep the winner. The table above shows the
  winner is not the same for every element, or even every theme.
- Share the capture code with a small GTK module, like `gtk-vector-screenshot`
  does, to export a *running* application's theme rather than a specimen app's.

## Layout

```
g2k/specs.py     element table: which GTK widget renders which Kvantum element
g2k/capture.py   cairo SVG-surface rendering, geometry probing, helpers
g2k/geom.py      nine-slice synthesis: pieces encoded from the render,
                 interior as a gradient or a coarse pixel grid
g2k/main.py      CLI: theme selection, palette probing, capture loop
g2k/emit.py      Name.svg / Name.kvconfig / Name.colors writers
g2k/states.py    reach hovered/pressed art by rewriting the theme's own CSS
g2k/verify.py    Qt-based verification and preview rendering
cmp_layout.py    checks that a re-layout of the sheet is invisible to Kvantum
                 (same markup modulo placement, same pixels per object)
g2k/compare.py   debugging: GTK render vs rebuilt object vs difference
```
