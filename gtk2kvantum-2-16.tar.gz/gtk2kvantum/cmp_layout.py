#!/usr/bin/env python3
"""Check that a re-layout of the sheet changed nothing Kvantum can see.

For every object in the manifest, render it through Qt's SVG renderer - the
one Kvantum uses - once from the old document and once from the new one, at the
size the nine-slice declares. If the pixels and the reported bounds match for
every object, the new layout is invisible to Kvantum.

    python3 cmp_layout.py OLD.svg NEW.svg OUTDIR
"""
import json
import os
import re
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import QRectF
from PySide6.QtGui import QImage, QPainter
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtWidgets import QApplication


def render(renderer, oid, w, h):
    img = QImage(max(1, w), max(1, h), QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(0)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    renderer.render(p, oid, QRectF(0, 0, w, h))
    p.end()
    return img


def main():
    old_svg, new_svg, outdir = sys.argv[1:4]
    QApplication.instance() or QApplication([])
    old = QSvgRenderer(old_svg)
    new = QSvgRenderer(new_svg)
    print("valid: old=%s new=%s" % (old.isValid(), new.isValid()))
    print("canvas: old=%s new=%s" % (old.defaultSize(), new.defaultSize()))

    old_lines = open(old_svg).read().splitlines()
    new_lines = open(new_svg).read().splitlines()

    def markup(lines, oid):
        """One object's markup, with its placement stripped."""
        for line in lines:
            if line.startswith('<g id="%s" ' % oid):
                return re.sub(r'transform="translate\([^)]*\)"', "", line)
        return None

    manifest = json.load(open(os.path.join(outdir, "manifest.json")))
    same = 0
    same_markup = 0
    bad = []
    for cap in manifest["captures"]:
        for part in cap.get("parts", [""]):
            w, h = [int(round(v)) for v in cap["rects"][part][2:4]]
            if w <= 0 or h <= 0:
                continue
            oid = "%s-%s%s" % (cap["element"], cap["state"],
                               "-" + part if part else "")
            if not old.elementExists(oid) or not new.elementExists(oid):
                bad.append((oid, "missing"))
                continue
            bo = old.boundsOnElement(oid)
            bn = new.boundsOnElement(oid)
            if (abs(bo.width() - bn.width()) > 1e-6 or
                    abs(bo.height() - bn.height()) > 1e-6):
                bad.append((oid, "bounds %.2fx%.2f -> %.2fx%.2f" % (
                    bo.width(), bo.height(), bn.width(), bn.height())))
                continue
            if markup(old_lines, oid) == markup(new_lines, oid):
                same_markup += 1
            else:
                bad.append((oid, "markup changed"))
                continue
            a = render(old, oid, w, h)
            b = render(new, oid, w, h)
            if a.constBits().tobytes() != b.constBits().tobytes():
                # Placement-only difference: Qt rasterises gradients in device
                # space, so a moved object can differ by a least significant
                # bit. Report how loud it is rather than pretending it is not
                # there.
                da, db = a.constBits().tobytes(), b.constBits().tobytes()
                worst = max(abs(da[i] - db[i]) for i in range(len(da)))
                npx = sum(1 for i in range(0, len(da), 4)
                          if da[i:i + 4] != db[i:i + 4])
                bad.append((oid, "pixels differ: %d px, worst %d/255"
                            % (npx, worst)))
                continue
            same += 1
    print("objects with identical markup: %d" % same_markup)
    print("objects bit-identical when rendered: %d, problems: %d"
          % (same, len(bad)))
    for oid, why in bad[:40]:
        print("  %-40s %s" % (oid, why))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
