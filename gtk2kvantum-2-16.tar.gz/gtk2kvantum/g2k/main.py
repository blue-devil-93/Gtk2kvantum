#!/usr/bin/env python3
"""Export the running GTK3 theme to a Kvantum SVG theme.

    gtk2kvantum OUTDIR --name MyTheme [--theme Adwaita] [--only button,...]

Requires GTK3 + PyGObject. Runs headless on the broadway backend if no
display is available (see run.sh in the repo for how this was tested).
"""

import argparse
import json
import os
import re
import sys

import cairo
import gi

gi.require_foreign("cairo")
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gdk, Gtk

from . import capture, emit, geom, specs, states

ALL_FLAGS = (Gtk.StateFlags.PRELIGHT | Gtk.StateFlags.ACTIVE |
             Gtk.StateFlags.CHECKED | Gtk.StateFlags.FOCUSED |
             Gtk.StateFlags.INSENSITIVE | Gtk.StateFlags.INCONSISTENT |
             Gtk.StateFlags.BACKDROP)


def log(msg):
    print(msg, file=sys.stderr)


def apply_state(widget, flags):
    combined = Gtk.StateFlags.NORMAL
    for f in flags:
        combined |= f
    widget.set_state_flags(combined, True)


def _rgba_hex(c):
    return "#%02X%02X%02X" % (int(round(c.red * 255)),
                              int(round(c.green * 255)),
                              int(round(c.blue * 255)))


def _rgba_hex8(c):
    """#RRGGBB, or #RRGGBBAA when the colour is translucent (Kvantum accepts
    both, and a backdrop text colour is usually a dimmed version of the
    normal one)."""
    base = _rgba_hex(c)
    a = int(round(c.alpha * 255))
    return base if a >= 255 else "%s%02X" % (base, a)


def _rgba_tuple(c):
    return (int(round(c.red * 255)), int(round(c.green * 255)),
            int(round(c.blue * 255)))


def _shade(c, factor):
    def ch(v):
        return max(0.0, min(1.0, v * factor))
    import gi.repository.Gdk as _G
    return _G.RGBA(ch(c.red), ch(c.green), ch(c.blue), 1.0)


def probe_palette():
    """Read the theme's real colours out of GTK's own style contexts."""
    win = Gtk.Window()
    box = Gtk.Box()
    box.get_style_context().add_class("background")
    btn = Gtk.Button()
    entry = Gtk.Entry()
    lbl = Gtk.Label(label="")
    tb = Gtk.Box()
    tb.get_style_context().add_class("tooltip")
    for w in (btn, entry, lbl, tb):
        box.pack_start(w, False, False, 0)
    win.add(box)
    win.show_all()
    capture.pump()

    def bg(w, state=Gtk.StateFlags.NORMAL):
        return w.get_style_context().get_background_color(state)

    def fg(w, state=Gtk.StateFlags.NORMAL):
        return w.get_style_context().get_color(state)

    def _rgba(r, g, b):
        return Gdk.RGBA(r / 255.0, g / 255.0, b / 255.0, 1.0)

    def sample(mk, pts, size=(140, 36), over=(255, 255, 255)):
        """Render a widget and read real pixels: GTK3 themes paint many
        surfaces with background-image gradients, so the CSS colour is often
        transparent and only the rendered result tells the truth."""
        widget = mk()
        w2 = capture.show(widget, *size)
        capture.pump(30)
        sw, sh = capture.allocation(widget)
        sw, sh = max(sw, 1), max(sh, 1)
        img = capture.render_image(widget, sw, sh)
        data = img.get_data()
        stride = img.get_stride()
        out = []
        for fx, fy in pts:
            x = min(sw - 1, max(0, int(fx * sw)))
            y = min(sh - 1, max(0, int(fy * sh)))
            o = y * stride + x * 4
            b_, g_, r_, a_ = data[o], data[o + 1], data[o + 2], data[o + 3]
            # Cairo stores premultiplied ARGB. Un-premultiplying a pixel with
            # almost no alpha multiplies rounding noise into black; compositing
            # over the window colour gives what the user actually sees.
            if over is not None:
                r_ = min(255, r_ + over[0] * (255 - a_) // 255)
                g_ = min(255, g_ + over[1] * (255 - a_) // 255)
                b_ = min(255, b_ + over[2] * (255 - a_) // 255)
            elif a_:
                r_ = min(255, r_ * 255 // a_)
                g_ = min(255, g_ * 255 // a_)
                b_ = min(255, b_ * 255 // a_)
            out.append(_rgba(r_, g_, b_))
        w2.destroy()
        return out

    def _bg_box():
        b = Gtk.Box()
        b.get_style_context().add_class("background")
        return b

    def _ttip_box():
        b = Gtk.Box()
        b.get_style_context().add_class("tooltip")
        return b

    def named(*names):
        """The first named colour the theme defines.

        Old themes state their palette as @define-color aliases
        (button_bg_color, base_color, tooltip_bg_color, ...). Reading those is
        exact; sampling a render guesses the colour under whatever art happens
        to be on top. The guesses stay as fallbacks for themes that only
        declare images.
        """
        ctx = win.get_style_context()
        for name in names:
            ok, col = ctx.lookup_color(name)
            if ok:
                return col
        return None

    # Window first: every other sample is composited over it, so a translucent
    # shadow or a border-image edge no longer arrives as black.
    window = named("theme_bg_color", "bg_color")
    win_rgb = ((int(round(window.red * 255)), int(round(window.green * 255)),
                int(round(window.blue * 255))) if window is not None
               else (255, 255, 255))
    if window is None:
        window = sample(_bg_box, [(0.5, 0.5)], size=(120, 80),
                        over=win_rgb)[0]
        win_rgb = (int(window.red * 255), int(window.green * 255),
                   int(window.blue * 255))

    base = named("theme_base_color", "base_color") or sample(
        Gtk.Entry, [(0.5, 0.5)], over=win_rgb)[0]
    # Sample the button's own gradient *inside* its frame: at 2% and 98% the
    # sample landed on the border image, where Ambiance is transparent, so
    # light.color came out as its border grey and dark.color as black.
    btn_cols = sample(Gtk.Button, [(0.5, 0.10), (0.5, 0.5), (0.5, 0.90)],
                      over=win_rgb)
    text = named("theme_fg_color", "fg_color") or fg(lbl)
    highlight = named("theme_selected_bg_color", "selected_bg_color") or _rgba(53, 132, 228)
    highlight_text = (named("theme_selected_fg_color", "selected_fg_color")
                      or fg(entry, Gtk.StateFlags.SELECTED))
    disabled = (named("disabled_fg_color", "insensitive_fg_color")
                or fg(lbl, Gtk.StateFlags.INSENSITIVE))
    link = named("theme_link_color", "link_color") or highlight
    visited = named("theme_visited_link_color", "link_visited_color") or highlight
    tooltip_bg = (named("theme_tooltip_bg_color", "tooltip_bg_color")
                  or sample(_ttip_box, [(0.5, 0.5)], size=(120, 40),
                            over=win_rgb)[0])
    tooltip_fg = (named("theme_tooltip_fg_color", "tooltip_fg_color")
                  or fg(tb))
    # A menu bar is a colour scheme of its own: Ambiance and Pluto (and most
    # dark-bar light-window themes) paint a dark bar with light text, so the
    # window's text colour must not be used for it. Kvantum takes a menubar
    # title's resting colour from [MenuBar]'s text.normal.color and the lit
    # states from [MenuBarItem]'s focus/press/toggle colours.
    menubar_text = menubar_active_text = menubar_disabled = None
    mb = Gtk.MenuBar()
    mb.set_size_request(160, 24)
    mb_item = Gtk.MenuItem(label="")
    mb.append(mb_item)
    box.pack_start(mb, False, False, 0)
    win.show_all()
    capture.pump(30)
    try:
        menubar_text = mb.get_style_context().get_color(Gtk.StateFlags.NORMAL)
        menubar_active_text = mb_item.get_style_context().get_color(
            Gtk.StateFlags.PRELIGHT)
        menubar_disabled = mb_item.get_style_context().get_color(
            Gtk.StateFlags.INSENSITIVE)
    except Exception as exc:
        log("  (could not read menu bar colours: %s)" % exc)
    box.remove(mb)
    mb.destroy()
    capture.pump(10)

    # A popup row's label has a colour of its own, and it is not the window's:
    # a light theme whose hover plate is dark (Aztec, Pluto) writes white
    # there. Kvantum draws a hovered row's label from [MenuItem]'s focus
    # colour; with none, it fell back to the window's text and painted black
    # text on the black highlight, so a selected row read as an empty bar.
    menuitem_text = menuitem_active_text = menuitem_disabled = None
    menu = Gtk.Menu()
    menu.set_size_request(160, 90)
    menu_row = Gtk.MenuItem(label="")
    menu.append(menu_row)
    menu.show_all()
    capture.pump(10)
    try:
        menu.popup(None, None, None, None, 0, Gtk.get_current_event_time())
        capture.pump(30)
        row_ctx = menu_row.get_style_context()
        menuitem_text = row_ctx.get_color(Gtk.StateFlags.NORMAL)
        menuitem_active_text = row_ctx.get_color(Gtk.StateFlags.PRELIGHT)
        menuitem_disabled = row_ctx.get_color(Gtk.StateFlags.INSENSITIVE)
    except Exception as exc:
        log("  (could not read menu row colours: %s)" % exc)
    finally:
        try:
            menu.popdown()
        except Exception:
            pass
        menu.destroy()
        capture.pump(10)

    # A window that is not focused draws its own, usually dimmer, text.
    inactive_text = (named("theme_unfocused_fg_color", "backdrop_fg_color")
                     or text)
    inactive_base = (named("theme_unfocused_base_color", "inactive_base_color")
                     or base)

    # Adwaita dark is *dark*: decide via relative luminance of the window colour.
    lum = 0.2126 * window.red + 0.7152 * window.green + 0.0722 * window.blue

    light = btn_cols[0]
    button = named("button_bg_color") or btn_cols[1]
    dark = btn_cols[2]
    mid = _shade(button, 0.94)
    midlight = _shade(button, 1.06)

    def hx(c):
        return _rgba_hex(c)

    kvcolors = [
        ("window.color", hx(window)),
        ("base.color", hx(base)),
        ("inactive.base.color", hx(inactive_base)),
        ("alt.base.color", hx(_shade(base, 1.12 if lum < 0.5 else 0.96))),
        ("inactive.alt.base.color",
         hx(_shade(inactive_base, 1.12 if lum < 0.5 else 0.96))),
        ("button.color", hx(button)),
        ("light.color", hx(light)),
        ("mid.light.color", hx(midlight)),
        ("dark.color", hx(dark)),
        ("mid.color", hx(mid)),
        ("highlight.color", hx(highlight)),
        ("inactive.highlight.color", hx(_shade(highlight, 0.8))),
        ("tooltip.base.color", hx(tooltip_bg)),
        ("tooltip.text.color", hx(tooltip_fg)),
        ("text.color", hx(text)),
        ("inactive.text.color", _rgba_hex8(inactive_text)),
        ("window.text.color", hx(text)),
        ("inactive.window.text.color", _rgba_hex8(inactive_text)),
        ("button.text.color", hx(text)),
        ("inactive.button.text.color", _rgba_hex8(inactive_text)),
        ("disabled.text.color", hx(disabled)),
        ("highlight.text.color", hx(highlight_text)),
        ("link.color", hx(link)),
        ("link.visited.color", hx(visited)),
    ]


    scroll_width = 12
    slider_width = 8
    try:
        sb = Gtk.Scrollbar(orientation=Gtk.Orientation.VERTICAL)
        st = sb.get_style_context()
        b = st.get_border()
        scroll_width = max(8, b.left + b.right + 8)
    except Exception:
        pass

    # Scroll bar behaviour the theme declares for itself. Ambiance turns both
    # steppers off (-GtkScrollbar-has-*-stepper: 0) and asks for a 31px
    # minimum slider; Kvantum's default draws two arrows the theme never
    # paints, and KvAmbiance sets scroll_arrows=false for the same reason.
    css = states.theme_css()
    scroll_arrows = "-GtkScrollbar-has-backward-stepper: 0" not in css
    m = re.search(r"-GtkScrollbar-min-slider-length:\s*(\d+)", css)
    scroll_min_extent = int(m.group(1)) if m else 0
    if not scroll_min_extent:
        # Newer GTK3 themes state the same minimum as a CSS length on the
        # slider node (Luna: `scrollbar.vertical slider { min-height: 40px }`),
        # because the style property was deprecated. Without it Kvantum falls
        # back to its own thumb length and the bar's grip stops matching.
        best = None
        for selectors, body in states.RULE.findall(css):
            sel = " ".join(selectors.split())
            if "slider" not in sel or "scrollbar" not in sel:
                continue
            if any(p in sel for p in (":hover", ":active", ":disabled",
                                      "fine-tune", "overlay-indicator")):
                continue
            mm = re.search(r"min-height:\s*(\d+)px", body)
            if not mm:
                continue
            # The generic `scrollbar slider` rule gives the cross-section
            # (12px); the orientation rule that follows raises the *length*
            # (`scrollbar.vertical slider { min-height: 40px }`), which is the
            # value Kvantum wants. Prefer the orientation-specific rule.
            best = (int(mm.group(1)), best[1] if best else 0)
            if "vertical" in sel:
                scroll_min_extent = int(mm.group(1))
                break
        if not scroll_min_extent and best:
            scroll_min_extent = best[0]

    win.destroy()
    return {
        "kv_window": _rgba_hex(window),
        "kv_base": _rgba_hex(base),
        "window": _rgba_tuple(window),
        "base": _rgba_tuple(base),
        "button": _rgba_tuple(button),
        "text": _rgba_tuple(text),
        "highlight": _rgba_tuple(highlight),
        "highlight_text": _rgba_tuple(highlight_text),
        "disabled": _rgba_tuple(disabled),
        "link": _rgba_tuple(link),
        "visited": _rgba_tuple(visited),
        "tooltip_bg": _rgba_tuple(tooltip_bg),
        "tooltip_fg": _rgba_tuple(tooltip_fg),
        "kvcolors": kvcolors,
        "dark": lum < 0.5,
        "scroll_width": scroll_width,
        "slider_width": slider_width,
        "scroll_arrows": scroll_arrows,
        "scroll_min_extent": scroll_min_extent,
        # Menubar label colours: the bar and its titles have their own colour,
        # which is not the window's (Ambiance and Pluto: dark bar, light text).
        "menubar_text": hx(menubar_text) if menubar_text is not None else None,
        "menubar_active_text": (hx(menubar_active_text)
                                if menubar_active_text is not None else None),
        "menubar_disabled_text": (hx(menubar_disabled)
                                  if menubar_disabled is not None else None),
        # Popup row colours: a hovered row's label is the theme's own, not the
        # window's.
        "menuitem_text": hx(menuitem_text) if menuitem_text is not None else None,
        "menuitem_active_text": (hx(menuitem_active_text)
                                 if menuitem_active_text is not None else None),
        "menuitem_disabled_text": (hx(menuitem_disabled)
                                   if menuitem_disabled is not None else None),
    }


def _build(spec):
    obj = spec.build()
    if isinstance(obj, dict):
        return obj
    return {"main": obj}


def _frame_for(widget, spec, flags):
    """Frame geometry for an element: the theme's declared border-image
    slice when it has one, otherwise its border and corner radius.

    Reading the slice matters on themes that paint with `border-image`, where
    the CSS border is a transparent 1px line and the visible frame is the
    image's own 10-12px edge (Ambiance). Guessing from the radius there cut
    the corners too small, and the frame widths in the kvconfig disagreed
    with the art the theme itself slices.
    """
    raw = capture.probe_frame(widget, flags)
    sl = states.frame_slice(getattr(spec, "css", ()) or ())
    if sl:
        raw = (max(raw[0], sl[0]), max(raw[1], sl[1]),
               max(raw[2], sl[2]), max(raw[3], sl[3]),
               raw[4], raw[5], raw[6], raw[7])
    return raw


def _frame_insets(widget, spec, flags):
    return geom.insets(geom.normalise(_frame_for(widget, spec, flags),
                                      *capture.allocation(widget)))


def _geom_capture(widget, spec, state, w, h):
    """Build the nine frame pieces from the theme's own pixels.

    The frame is no longer repainted from measured border widths and corner
    radii: that guessed the shape back and was off by a pixel or two wherever
    a theme neighbours its border with an inset highlight or shade, which left
    a seam of page colour around every button and put shadow lines in the
    wrong rows. Eight pieces are now run-length encoded from the real render,
    so a border, a corner and an inset shadow are the pixels GTK painted.
    """
    fr = geom.normalise(_frame_for(widget, spec, Gtk.StateFlags.NORMAL), w, h)
    px = geom.reader(capture.render_image(widget, w, h), w, h)
    slices = geom.build(spec.element, state, w, h, fr, px)
    return slices, geom.rects(fr, w, h), geom.insets(fr)


def _period_insets(img, w, h):
    """Where a repeating fill's own edge bands end.

    One pixel of border (and any transparent margin above it) has to stay at
    its real size while the middle repeats, so the caps are the painted edge
    plus a pixel of that edge itself.
    """
    bbox = capture.alpha_bbox(img, 8)
    if bbox is None:
        return (1, 1, 1, 1)
    x, y, bw, bh = bbox
    return capture.clamp_insets((y + 1, w - x - bw + 1, h - y - bh + 1, x + 1),
                                w, h)


def _geom_from_image(img, w, h, element, state, ins):
    """Nine-slice objects built from an already rendered surface.

    The menu, the menu bar item and the tab frame were shipped as one object
    each, so Kvantum stretched them whole: a 1px border came out thicker on a
    big menu than on a small one and a rounded corner turned into a smear. The
    pixels are still the theme's; only now the edges are cut out of them at
    their real size and the middle is the only part that stretches.
    """
    ins = [max(0, int(v)) for v in ins]
    fr = geom.normalise((ins[0], ins[1], ins[2], ins[3],
                         ins[0], ins[1], ins[2], ins[3]), w, h)
    px = geom.reader(img, w, h)
    return (geom.build(element, state, w, h, fr, px),
            geom.rects(fr, w, h), geom.insets(fr))


def _slice_capture(widget, spec, state, w, h):
    """Nine real slices of GTK's own render.

    Each piece is drawn into its own surface, at its natural size, with the
    origin moved to that piece. No clip path reaches the document - the piece
    *is* the surface - so Qt's bounds measurement is exact and Kvantum can keep
    corners at 1:1 while stretching only the flat edges.
    """
    fr = geom.normalise(capture.probe_frame(widget, Gtk.StateFlags.NORMAL), w, h)
    ins = list(geom.insets(fr))
    if spec.shadow:
        # A soft rim (menu/tooltip shadow) belongs inside the frame, otherwise
        # its corners are squashed into an interior that gets stretched.
        sh = capture.opaque_insets(capture.render_image(widget, w, h), w, h)
        ins = [max(ins[i], sh[i]) for i in range(4)]
    ins = capture.clamp_insets(ins, w, h)
    rects_map = capture.slices_for(ins, w, h)
    slices = {part: capture.render_fragment(widget, *rect)
              for part, rect in rects_map.items()}
    return slices, rects_map, ins


PSEUDO_FOR_FLAG = (
    (Gtk.StateFlags.ACTIVE, ":active"),
    (Gtk.StateFlags.PRELIGHT, ":hover"),
    # A window that lost focus paints :backdrop art, and GtkButton recomputes
    # its own state while drawing, so the flag alone does not stick - the
    # theme's :backdrop rules are repeated without the pseudo-class instead,
    # exactly like hover and pressed.
    (Gtk.StateFlags.BACKDROP, ":backdrop"),
)


def _pseudo_for(flags):
    for flag, pseudo in PSEUDO_FOR_FLAG:
        if flag in flags:
            return pseudo
    return None


# Art that depends only on the widget, not on its state. A disabled thumb or
# check box is often not painted at all by the theme; reusing the size (or the
# art) of the last state that did paint keeps Kvantum from stretching a stray
# empty box.
_last_size = {}
_last_art = {}
# Nine-slice bands of the first (normal) capture of a bar-like element.
_BAR_INSETS = {}


def capture_variant(spec, state, flags, debug_dir):
    # The fake state has to be in place before the widget exists (see
    # states.begin): GTK resolves style at construction time, and adding a CSS
    # class resolves it right away too.
    states.begin(_pseudo_for(flags), getattr(spec, "tokens", None))
    obj = _build(spec)
    main = obj["main"]
    win = None
    ref_widget = None
    ref_img = None
    margins = None
    # Set only for a fill that repeats: the interior's tile width and the size
    # of the composed (cap + period + cap) art.
    cap_pattern = 0
    art_size = None

    if spec.kind == "menuitem":
        # Menu items are only painted inside a posted popup, so a small menu is
        # posted and its middle row captured. The row's own node is the menu
        # item's art itself - vector, with no button panel and no drop shadow
        # borrowed from another widget.
        main.set_size_request(180, 120)
        main.show_all()
        capture.pump()
        main.popup(None, None, None, None, 0, Gtk.get_current_event_time())
        capture.pump(40)
        item = obj["items"][1]
        apply_state(item, flags)
        capture.pump(20)
        iw, ih = item.get_allocated_width(), item.get_allocated_height()
        iw, ih = max(iw, 8), max(ih, 8)
        # The row is nine-sliced from its own pixels. Shipped whole, Kvantum
        # stretched the theme's 1px border with the row: on a menu narrower
        # than the capture it turned into one blurry double line (IceWater),
        # and on a wider one into a visibly fatter frame. Cut, the border and
        # the corner radius stay their own size and only the middle stretches.
        img = capture.render_image(item, iw, ih)
        ins = capture.clamp_insets(
            capture.probe_insets(item, _combined(flags)), iw, ih)
        slices, rects, insets = _geom_from_image(
            img, iw, ih, spec.element, state, ins)
        ref_img = img
        ref_widget = None
        widget = None
        w, h = iw, ih
    elif spec.kind == "menubaritem":
        # A menu bar title usually paints nothing of its own: the bar shows
        # through. Capture the title's own node, never the whole bar, or the
        # bar's full-width border and background leak into the object and Qt
        # scales the title art down to fit those oversized painted bounds.
        win = capture.show(main, *spec.size)
        capture.pump(40)
        item = obj["items"][1]
        apply_state(item, flags)
        capture.pump(20)
        iw, ih = item.get_allocated_width(), item.get_allocated_height()
        iw, ih = max(iw, 8), max(ih, 8)
        img = capture.render_image(item, iw, ih)
        if spec.mode == "geom":
            ins = capture.clamp_insets(
                capture.probe_insets(item, _combined(flags)), iw, ih)
            slices, rects, insets = _geom_from_image(
                img, iw, ih, spec.element, state, ins)
        else:
            body = capture.render_fragment(item, 0, 0, iw, ih)
            if len(body.strip()) < 40:
                body = ('<rect width="%d" height="%d" fill="#000000" '
                        'fill-opacity="0"/>' % (iw, ih))
            slices = {"": body}
            rects = {"": (0, 0, iw, ih)}
            insets = capture.clamp_insets(
                capture.probe_text_margins(item, _combined(flags)), iw, ih)
        margins = capture.clamp_insets(
            capture.probe_text_margins(item, _combined(flags), insets), iw, ih)
        ref_img = img
        ref_widget = None
        widget = None
        w, h = iw, ih
    elif spec.kind == "menu":
        # A popup can allocate happily and still paint nothing - and "nothing"
        # matches "nothing" when verified, which would report a perfect score
        # for an empty object. Rebuild it at a shrinking height until it draws.
        w = h = 8
        for height in (180, 140, 120, 96, 84, 60):
            cand = _build(spec)
            m2 = cand["main"]
            m2.set_size_request(180, height)
            m2.show_all()
            capture.pump()
            m2.popup(None, None, None, None, 0, Gtk.get_current_event_time())
            capture.pump(40)
            cw, ch = capture.allocation(m2)
            cw, ch = max(cw, 8), max(ch, 8)
            painted = capture.opaque_fraction(capture.render_image(m2, cw, ch))
            if painted >= 0.05:
                obj, main, w, h = cand, m2, cw, ch
                break
            log("  %s painted nothing at %dpx, shrinking" % (spec.key, height))
            m2.destroy()
            capture.pump(10)
        else:
            raise RuntimeError("%s never painted at any popup size" % spec.key)
        widget = main if spec.kind == "menu" else obj["items"][1]
        # GTK paints the popup with a blurred rim around the panel. A menu
        # object has to be the panel itself: kept as-is, Kvantum draws that
        # blur as a strange shadow around every menu.
        img = capture.render_image(widget, w, h)
        mt, mr, mb, ml = capture.opaque_insets(img, w, h)
        pw, ph = max(w - ml - mr, 8), max(h - mt - mb, 8)
        panel = capture.crop(img, ml, mt, pw, ph)
        if spec.mode == "geom":
            # The panel's own border and corner radius stay at their real size;
            # only the middle stretches, which is what a menu panel should do.
            ins = capture.clamp_insets(
                capture.probe_insets(widget, Gtk.StateFlags.NORMAL), pw, ph)
            slices, rects, insets = _geom_from_image(
                panel, pw, ph, spec.element, state, ins)
        elif spec.mode == "slice":
            slices, rects, insets = _slice_capture(widget, spec, state, pw, ph)
        else:
            slices = {"": capture.render_fragment(widget, ml, mt, pw, ph)}
            rects = {"": (0, 0, pw, ph)}
            insets = (0, 0, 0, 0)
        margins = capture.clamp_insets(
            capture.probe_text_margins(widget, Gtk.StateFlags.NORMAL, insets),
            pw, ph)
        ref_img = panel
        ref_widget = None
        w, h = pw, ph
    elif spec.kind in ("tab", "tabframe"):
        win = capture.show(main, *spec.size)
        capture.pump(40)
        nb, labels = main, obj.get("labels") or []
        nw, nh = capture.allocation(nb)
        nw, nh = max(nw, 8), max(nh, 8)
        # A notebook paints its page through its own GdkWindow, which ignores
        # the cairo clip: a vector fragment came out carrying the page and the
        # notebook frame, so Kvantum stretched that instead of a tab. Cut the
        # pixels of one surface instead - an exact-size image cannot smuggle
        # foreign art in, and Qt measures it exactly.
        img = capture.render_image(nb, nw, nh)
        if spec.kind == "tab":
            # Tab 0 is selected (Kvantum's "toggled"); tab 1 is the plain tab.
            idx = 0 if state == "toggled" else 1
            lab = labels[idx]
            lx, ly = lab.translate_coordinates(nb, 0, 0)
            lw, lh = lab.get_allocated_width(), lab.get_allocated_height()
            # How far GTK puts the label from the tab's edge: the two tabs sit
            # side by side, so the gap between their labels is two paddings
            # (Kvantum's text.margin + frame). This used to be a guess of 9px
            # with no text.margin at all, which left every tab's label flush
            # against its edge.
            pad_x, pad_y = 9, 4
            if len(labels) > 1:
                ox = labels[1 - idx].translate_coordinates(nb, 0, 0)[0]
                gap = abs(ox - lx) - lw
                if gap >= 4:
                    pad_x = max(2, int(round(gap / 2.0)))
            pad_y = max(2, ly)
            x0 = max(0, lx - pad_x)
            y0 = 0
            rw = min(nw - x0, lw + 2 * pad_x)
            # The tab strip ends where the first page starts: GTK allocates the
            # page below the tabs, so that is the last row that still belongs
            # to a tab. Adding the label's padding twice reached past it and
            # shipped a strip of the page (or of the notebook's frame) at the
            # bottom of every tab.
            bottom = ly + lh + pad_y
            pages = obj.get("pages") or []
            if pages:
                try:
                    page_y = pages[0].translate_coordinates(nb, 0, 0)[1]
                except Exception:
                    page_y = None
                if page_y and page_y > lh:
                    bottom = min(bottom, page_y)
            rh = min(nh - y0, bottom)
            margins = capture.clamp_insets((pad_y, pad_x, pad_y, pad_x), rw, rh)
        else:
            # The frame comes from a tabless notebook (see specs): no strip of
            # a tab can land in it, and Kvantum cuts TabFrame under the active
            # tab anyway.
            x0 = y0 = 0
            rw, rh = nw, nh
        x, y, rw, rh = x0, y0, max(rw, 8), max(rh, 8)
        if spec.kind == "tabframe" and spec.mode == "geom":
            # A frame paints a one pixel border and nothing else. Shipped as a
            # single stretched object that pixel was scaled with the notebook,
            # so the tab frame's border grew on larger windows.
            ins = capture.clamp_insets(
                capture.probe_insets(main, Gtk.StateFlags.NORMAL), rw, rh)
            slices, rects, insets = _geom_from_image(
                capture.crop(img, x, y, rw, rh), rw, rh,
                spec.element, state, ins)
        else:
            slices = {"": capture.image_object(img, x, y, rw, rh)}
            rects = {"": (0, 0, rw, rh)}
            insets = (capture.probe_insets(main, Gtk.StateFlags.NORMAL)
                      if spec.kind == "tabframe" else (0, 0, 0, 0))
        w, h = rw, rh
        ref_img = capture.crop(img, x, y, rw, rh)
        ref_widget = None
        widget = None
    else:
        # A GtkCheckButton resolves its tick and its checked background from
        # the *active* property when it is realised, so it has to be switched on
        # before it is shown: set_state_flags() or a later set_active() left the
        # box drawn unchecked, and Kvantum showed every box empty.
        if isinstance(main, Gtk.ToggleButton):
            want = Gtk.StateFlags.CHECKED in flags
            if main.get_active() != want:
                main.set_active(want)
        if isinstance(main, Gtk.CheckButton):
            # The third state is a property, not a state flag: GTK draws the
            # indeterminate mark only for `inconsistent`, so the flag alone
            # produced a box that looked exactly unchecked.
            want = Gtk.StateFlags.INCONSISTENT in flags
            if main.get_inconsistent() != want:
                main.set_inconsistent(want)
        win = capture.show(obj.get("host", main), *spec.size)
        capture.pump()
        apply_state(main, flags)
        capture.pump(10)
        widget = main
        w, h = capture.allocation(widget)
        w, h = max(w, 8), max(h, 8)
        insets = spec.insets or _frame_insets(widget, spec, _combined(flags))
        # A framed widget's labels sit at (border + padding), which is rarely
        # the frame width. Without this the frame insets doubled as text
        # margins, so a 10px Ambiance frame pushed every button label 20px in.
        if spec.margins:
            margins = capture.probe_text_margins(
                widget, _combined(flags), insets)

        if spec.mode == "slice":
            slices, rects, insets = _slice_capture(widget, spec, state, w, h)
        elif spec.mode == "geom":
            slices, rects, insets = _geom_capture(widget, spec, state, w, h)
        elif spec.kind == "single":
            if spec.raster:
                # Qt measures an object at its painted bounds, so empty margin
                # around a small indicator made it look too small. Trim to the
                # painted pixels and render at 2x so it stays crisp.
                img = capture.render_image(widget, w, h, scale=2)
                bbox = capture.alpha_bbox(img)
                if bbox is None:
                    # Ambiance paints no disabled check/radio indicator at
                    # all; without a size the object fell back to the whole
                    # 2x allocation (56x44) and Kvantum stretched a blank box
                    # over the control. The last painted size is the right
                    # footprint for an invisible object.
                    bw, bh = _last_size.get(spec.key, (w * 2, h * 2))
                    bbox = (0, 0, bw, bh)
                _last_size[spec.key] = (bbox[2], bbox[3])
                slices = {"": capture.image_object(img, *bbox)}
                rects = {"": (0, 0, bbox[2], bbox[3])}
                ref_img = capture.crop(img, *bbox)
                ref_widget = None
                w, h = bbox[2], bbox[3]
            else:
                slices = {"": capture.render_fragment(widget, 0, 0, w, h)}
                rects = {"": (0, 0, w, h)}
            insets = (0, 0, 0, 0)
        elif spec.kind == "scale":
            # The scale handle has no widget of its own either: a button wearing
            # the theme's scale-slider rules is photographed instead.
            win = capture.show(main, *spec.size)
            capture.pump(40)
            # The scale's own allocation, not the window it was put in: a
            # scale squeezed into a short window clips its handle, and the
            # export then carried a clipped 27x15 handle where GTK draws 33x20.
            w, h = capture.allocation(main)
            syn = _scale_handle(main, w, h)
            if syn is None:
                # Never fall back to the scroll bar's trough here: a scale
                # handle is a small block of its own, not a bar.
                syn = (_synth_bar(main, 16, 16, "scrollbar")
                       or _synth_bar(main, 16, 16, "groove"))
            if syn is not None:
                slices, rects, insets, ref_img = syn
            else:
                slices = {"": capture.render_fragment(main, 0, 0, w, h)}
                rects = {"": (0, 0, w, h)}
                insets = (0, 0, 0, 0)
                ref_img = None
            ref_widget = None
            ref_widget = None
            widget = None
            w, h = rects[""][2], rects[""][3]
        elif spec.kind == "slidertrough":
            # [Slider] is the scale's trough, and its thickness is a kvconfig
            # value: ship the trough exactly as the theme paints it, at the
            # height it was drawn, and Kvantum stretches it lengthways only.
            win = capture.show(main, *spec.size)
            capture.pump(40)
            w, h = capture.allocation(main)
            # Kvantum paints the empty part of the groove from -normal and the
            # filled part from -toggled; GTK's filled band is the theme's
            # `scale highlight` node.
            kind = "highlight" if Gtk.StateFlags.CHECKED in flags else "trough"
            syn = _scale_trough(main, w, h, kind, _BAR_INSETS.get("slider"))
            if syn is not None and kind == "trough":
                # Every state is sliced with the normal art's frame widths (see
                # _bar_slices), and the normal capture is the first one.
                _BAR_INSETS["slider"] = syn[2]
            if syn is None:
                # A blank object, but vertical like the art it stands in for:
                # its width is the trough's thickness, its height its length.
                thick = 6
                syn = ({"": ""}, {"": (0, 0, thick, max(w, 60))},
                       (0, 0, 0, 0), None)
            slices, rects, insets, ref_img = syn
            ref_widget = None
            widget = None
            # The art's own size, not its stretchable middle: a trough is as
            # thick as the whole band (that is `slider_width`).
            w = max(r[0] + r[2] for r in rects.values())
            h = max(r[1] + r[3] for r in rects.values())
        elif spec.kind == "stepper":
            # Kvantum draws a scroll bar's arrows itself, into the square at
            # each end of the bar, from [Scrollbar]'s indicator art. Ship GTK's
            # own stepper button - plate and arrow glyph - so the two agree;
            # without it Kvantum drew its default theme's bare triangles on
            # the window background, which is nothing like a GTK bar.
            apply_state(main, flags)
            capture.pump(50)
            sw, sh = capture.allocation(main)
            sw = max(sw, 8)
            img = capture.render_image(main, sw, sh)
            y = 0 if obj.get("side") == "up" else max(sh - sw, 0)
            art = capture.crop(img, 0, y, sw, sw)
            slices = {"": capture.image_object(art, 0, 0, sw, sw)}
            rects = {"": (0, 0, sw, sw)}
            insets = (0, 0, 0, 0)
            ref_img = art
            ref_widget = None
            widget = None
            w, h = sw, sw
        elif spec.kind == "sliced":
            # Kvantum sizes objects with QSvgRenderer::boundsOnElement(), which
            # ignores clip paths, so a clipped sub-render measures as the whole
            # widget. Emit the widget as one object; insets still feed the text
            # margins in the kvconfig.
            if spec.raster:
                slices = {"": capture.png_object(widget, w, h)}
            else:
                slices = {"": capture.render_fragment(widget, 0, 0, w, h)}
            rects = {"": (0, 0, w, h)}
        elif spec.kind in ("scrollbar", "groove"):
            slices, rects, insets, ref_img = _capture_scrollbar(
                widget, w, h, insets, spec.kind, obj.get("host"))
            ref_widget = None
            if (obj.get("host") is not None and
                    (slices is None or ref_img is None or
                     capture.opaque_fraction(ref_img) < 0.01)):
                # A theme can paint nothing for a bar inside a scrolled window
                # (Adwaita keeps its scroll bar hidden until hovered) and still
                # paint one shown on its own. Try that before inventing a
                # trough from the theme's CSS: the real bar is what applications
                # show, and its trough is flat, square and a different colour
                # from any stand-in the CSS suggests.
                alt = _capture_scrollbar(widget, w, h, insets, spec.kind, None)
                flat = obj.get("flat")
                if (alt[0] is None or alt[3] is None or
                        capture.opaque_fraction(alt[3]) < 0.01) and flat is not None:
                    # A theme may hide its bar behind hover (GNOME's overlay
                    # scroll bars): the same container with overlay scrolling
                    # turned off paints the bar the theme declares.
                    fb = flat.get_vscrollbar()
                    flatwin = capture.show(flat, max(w, 40) + 120, max(h, 40))
                    capture.pump(80)
                    alt = _capture_scrollbar(fb, w, h, insets, spec.kind, flat)
                    flatwin.destroy()
                    capture.pump(10)
                if (alt[0] is not None and alt[3] is not None and
                        capture.opaque_fraction(alt[3]) >= 0.01):
                    log("  scroll bar painted without overlay scrolling")
                    slices, rects, insets, ref_img = alt
            # Nothing painted by the widget itself (this is the normal case
            # headless): draw the bar from the theme's own colours.
            if slices is None or ref_img is None or capture.opaque_fraction(ref_img) < 0.01:
                # GTK never paints a bar headless. Dress widgets in the theme's
                # own scrollbar rules instead: a box tree for the trough and a
                # real button for the slider, which then carries the theme's
                # frame, radius and states like any other button.
                if spec.kind == "groove":
                    # Vector first: the box tree wearing the theme's own
                    # scrollbar rules renders as gradients and rects. The
                    # bitmap version of the same box came out as a 14x160 PNG,
                    # which Kvantum stretched lengthways into a smear.
                    syn = _painted(_virtual_scrollbar(
                        "groove", max(w, 8), max(h, 20)))
                    if syn is None:
                        syn = (_virtual_trough(max(w, 8), max(h, 20))
                               or _synth_bar(widget, max(w, 8), max(h, 20), "groove"))
                else:
                    # A thumb is exactly as thick as its bar, so measure the
                    # trough the theme's own rules produce and build the thumb
                    # at that width - the scrollbar widget's allocation is not
                    # the bar. The theme then paints the thumb with its real
                    # gradient, border and grip, and only a theme that paints
                    # none of it falls back to a plain rect in the slider
                    # colour.
                    trough_syn = _painted(_virtual_scrollbar(
                        "groove", max(w, 8), max(h, 20)))
                    bar_w = trough_syn[1][""][2] if trough_syn else max(w, 8)
                    syn = _painted(_virtual_slider(max(bar_w, 8), 44))
                    if syn is None:
                        syn = _synth_bar(widget, max(w, 8),
                                         max(min(h, 44), 20), "scrollbar")
                if syn is None and spec.kind == "scrollbar":
                    # A disabled scroll bar thumb that the theme does not paint
                    # still needs an object; the normal art is the honest
                    # stand-in (KvAmbiance ships the same art for both).
                    syn = _last_art.get(spec.key)
                if syn is None:
                    # A theme may genuinely draw no trough (Ambiance's bar is
                    # a flat track with no border), and a theme that styles
                    # nothing at all still needs the element to exist: an
                    # empty object is the honest answer, not a crash. It is
                    # sized like a bar, not like the scrollbar widget's whole
                    # allocation.
                    syn = ({"": ""},
                           {"": (0, 0, max(6, min(w, 24)), max(h, 20))},
                           (0, 0, 0, 0), None)
                else:
                    _last_art[spec.key] = syn
                slices, rects, insets, ref_img = syn
                ref_widget = None
            # The bar's own art size, not the widget's: the thumb is 14x40 in a
            # 14x160 bar, and reporting the widget size both misplaced it on
            # the sheet and left it unscored (the reference is the art).
            w = max(r[0] + r[2] for r in rects.values())
            h = max(r[1] + r[3] for r in rects.values())
            apply_state(main, flags)
            capture.pump(10)
        elif spec.kind == "fill":
            cw = max(8, int(w * 0.35))
            slices = {"": capture.render_fragment(widget, 0, 0, cw, h)}
            rects = {"": (0, 0, cw, h)}
            insets = (0, 0, 0, 0)
            # A fill GTK paints as a repeating gradient (DevilHuman's diagonal
            # stripes) was stretched with the bar, so the pitch grew with it.
            # Kvantum can repeat an interior instead (`interior.x.patternsize`),
            # so such a fill is shipped as one cap, one period and one cap: the
            # ends keep their border and the middle repeats at the theme's own
            # pitch. A fill that does not repeat is left as one object.
            img = capture.render_image(widget, w, h)
            period = capture.pattern_period(img, w, h)
            if period:
                ins = _period_insets(img, w, h)
                art = capture.compose_periodic(img, w, h, ins, period)
                aw = ins[3] + period + ins[1]
                slices, rects, insets = _geom_from_image(
                    art, aw, h, spec.element, state, ins)
                cap_pattern = period
                art_size = (aw, h)
                ref_img = img
                log("  %s repeats every %dpx, tiled" % (spec.key, period))
            else:
                ref_img = None
        else:
            raise ValueError("unknown kind %s" % spec.kind)
        if spec.kind in ("single", "sliced") and ref_img is None:
            ref_widget = widget

    # Read the reference pixels while the alias is still installed: this image
    # is what the comparison and the blank guard look at, and it has to show
    # the same art the exported object was built from.
    if ref_img is None and ref_widget is not None:
        try:
            ref_img = capture.render_image(ref_widget, w, h)
        except Exception:
            ref_img = None

    states.end()

    out = {
        "key": spec.key,
        "element": spec.element,
        "state": state,
        # A tiled fill's art is narrower than the widget it stands for.
        "pattern": cap_pattern,
        "art_size": art_size,
        # A capture that came back as several pieces is a nine-slice, whatever
        # kind it was: a bar's bands have to stay their own size too.
        "frame": spec.mode in ("geom", "slice") or len(slices) > 1,
        "size": (w, h),
        "insets": tuple(int(v) for v in insets),
        "margins": tuple(int(v) for v in margins) if margins else None,
        "slices": {},
    }
    for part in slices:
        prefix = "%s-%s-%s" % (spec.key, state, part or "i")
        out["slices"][part] = {
            "rect": rects[part],
            "prefix": prefix,
            "svg": capture.prefix_ids(slices[part], prefix),
        }

    # A widget that paints nothing cannot be scored: an empty object would
    # verify at a perfect 100% against an equally empty reference. If even the
    # normal state is blank the element is structurally broken (GTK never drew
    # it), so skip it; a blank single state is just left unscored.
    probe = ref_img if ref_img is not None else (
        capture.render_image(ref_widget, w, h) if ref_widget is not None else None)
    blank = probe is not None and capture.opaque_fraction(probe) < 0.01
    if blank:
        if state == "normal" and not getattr(spec, "allow_blank_normal", False):
            raise RuntimeError("element painted nothing in its normal state")
        log("  %s/%s painted nothing, left unscored" % (spec.key, state))

    if debug_dir and not blank:
        # Must happen before the window is destroyed: an unrealised widget draws
        # nothing, which silently produced empty reference images.
        try:
            img = ref_img
            if img is None and ref_widget is not None:
                img = capture.render_image(ref_widget, w, h)
            if img is not None:
                img.write_to_png(os.path.join(debug_dir, "%s-%s.png" % (spec.key, state)))
        except Exception as exc:
            log("  (no reference png for %s/%s: %s)" % (spec.key, state, exc))
    if win is not None:
        win.destroy()
    for fn in (obj.get("cleanup") or []):
        fn()
    return out


_CLIP_DEF = re.compile(r'<clipPath\b([^>]*)>(.*?)</clipPath>', re.S)
_SHAPE = re.compile(r'<(rect|path|image)\b[^>]*/>')
_USE = re.compile(r'<use\b[^>]*/>')


def _attr(tag, name, default=0.0):
    m = re.search(r'\b%s="(-?[\d.]+)"' % name, tag)
    return float(m.group(1)) if m else default


def _points(markup):
    """Every coordinate pair in the path data of a fragment."""
    xs, ys = [], []
    for d in re.findall(r'\bd="([^"]+)"', markup):
        nums = [float(v) for v in re.findall(r'-?\d+\.?\d*', d)]
        xs.extend(nums[0::2])
        ys.extend(nums[1::2])
    return xs, ys


def _clip_rect(tag, w, h):
    """A <rect> intersected with the widget box (empty if nothing is left).

    A theme may paint a whole row's highlight with one rectangle that reaches
    into the menu's padding and is clipped by the popup: Adwaita draws a
    240x31 rect for a 200x26 row. Qt ignores that clipping when it measures an
    object, so the rect has to be trimmed rather than shipped as-is.
    """
    x, y = _attr(tag, "x"), _attr(tag, "y")
    bw, bh = _attr(tag, "width"), _attr(tag, "height")
    x0, y0 = max(x, 0.0), max(y, 0.0)
    x1, y1 = min(x + bw, float(w)), min(y + bh, float(h))
    if x1 - x0 <= 0.5 or y1 - y0 <= 0.5:
        return ""
    rest = re.sub(r'\b(?:x|y|width|height)="[^"]*"', "", tag)
    inner = rest[len("<rect"):-2].strip()
    return ('<rect x="%g" y="%g" width="%g" height="%g" %s/>'
            % (x0, y0, x1 - x0, y1 - y0, inner))


def _fit_fragment(svg, w, h, tol=1.5, clip_rects=False):
    """Trim a fragment to the widget box.

    Qt measures an object's painted bounds from every shape it can find -
    shadow plates and clip paths included - and maps those bounds onto the
    element rect. GTK draws a drop shadow as a plate wider than the widget
    (180x48 for a 150x34 menu item), so a plain fragment of it was scaled down
    to fit. Plates and clip paths that reach outside the box are dropped; what
    remains measures exactly the widget.

    A menu row is the exception: the theme's own highlight reaches outside the
    row and is clipped by the popup. Dropping it left every menu item empty, so
    `clip_rects` trims those rects to the box instead (the part GTK shows).
    """
    out, pos = [], 0
    for m in _SHAPE.finditer(svg):
        tag = m.group(0)
        x, y = _attr(tag, "x"), _attr(tag, "y")
        bw, bh = _attr(tag, "width"), _attr(tag, "height")
        if (x < -tol or y < -tol or x + bw > w + tol or y + bh > h + tol):
            out.append(svg[pos:m.start()])
            if clip_rects and tag.startswith("<rect"):
                out.append(_clip_rect(tag, w, h))
            pos = m.end()
    out.append(svg[pos:])
    svg = "".join(out)

    # GTK paints a drop shadow as 9-slice tiles placed around the widget, each
    # one a <use> of a small texture. Those tiles are the blur, not the item,
    # so they go - a menu item is a panel, and the user asked for no stray
    # shadow. Real art is recorded as paths, gradients and images.
    svg = _USE.sub("", svg)

    dropped, out, pos = [], [], 0
    for m in _CLIP_DEF.finditer(svg):
        xs, ys = _points(m.group(2))
        if xs and (min(xs) < -tol or min(ys) < -tol or
                   max(xs) > w + tol or max(ys) > h + tol):
            cid = re.search(r'\bid="([^"]+)"', m.group(1))
            if cid:
                dropped.append(cid.group(1))
            out.append(svg[pos:m.start()])
            pos = m.end()
    out.append(svg[pos:])
    svg = "".join(out)
    for cid in dropped:
        svg = svg.replace(' clip-path="url(#%s)"' % cid, "")
    return svg


def _vector_or_image(widget, w, h):
    """A real vector fragment, falling back to pixels if GTK draws nothing."""
    img = capture.render_image(widget, w, h)
    if capture.opaque_fraction(img) < 0.02:
        return ({"": capture.png_object(widget, w, h)},
                {"": (0, 0, w, h)}, (0, 0, 0, 0), None)
    body = capture.render_fragment(widget, 0, 0, w, h)
    if len(body.strip()) < 40:
        return ({"": capture.png_object(widget, w, h)},
                {"": (0, 0, w, h)}, (0, 0, 0, 0), None)
    insets = capture.clamp_insets(
        capture.probe_text_margins(widget, Gtk.StateFlags.NORMAL), w, h)
    return ({"": _fit_fragment(body, w, h)}, {"": (0, 0, w, h)}, insets, img)


def _shade_hex(hexstr, factor):
    r = int(hexstr[1:3], 16)
    g = int(hexstr[3:5], 16)
    b = int(hexstr[5:7], 16)
    return "#%02X%02X%02X" % tuple(
        max(0, min(255, int(round(v * factor)))) for v in (r, g, b))


def _css_slider_colour():
    """The colour the theme's own scroll bar slider rule declares.

    GTK's painted scroll bar is not available headless for every theme, and a
    stand-in widget only ever reproduced the theme's *button* art, so the
    fallback thumb takes its colour from the theme's slider rule itself.
    """
    for selectors, body in states.RULE.findall(states.theme_css()):
        sel = " ".join(selectors.split())
        if "slider" not in sel or "scrollbar" not in sel:
            continue
        if any(p in sel for p in (":hover", ":active", ":disabled",
                                  ":backdrop", "overlay-indicator")):
            continue
        m = re.search(r"background-color:\s*(#[0-9a-fA-F]{6})", body)
        if m:
            return m.group(1).upper()
    return None


def _painted(syn):
    """A capture result, or None when the shape it drew is empty."""
    if syn is None:
        return None
    svg = syn[0].get("")
    if not svg or not svg.strip():
        return None
    return syn


def _synth_bar(widget, w, h, kind):
    """A trough/thumb from the theme's own scroll bar colours.

    No GTK3 draw path hands us scroll bar art headless: the bar paints itself
    through its container, and a redraw after scrolling changes nothing. The
    colours are still the theme's - read from its style context - so the shape
    is honest theme colour, and a 1px border keeps the trough from reading as a
    flat block. A theme with no trough at all (Adwaita) stays blank.
    """
    ctx = widget.get_style_context()
    bg = ctx.get_background_color(Gtk.StateFlags.NORMAL)
    if bg.alpha < 0.05:
        return None
    try:
        edge = ctx.get_border_color(Gtk.StateFlags.NORMAL)
    except Exception:
        edge = None
    fill = _rgba_hex(bg)
    if kind == "scrollbar":
        fill = _css_slider_colour() or _shade_hex(fill, 0.93)
    line = _rgba_hex(edge) if edge is not None and edge.alpha > 0.05 else _shade_hex(fill, 0.62)
    body = ('<rect width="%g" height="%g" fill="#000000" fill-opacity="0"/>'
            '<rect x="0.5" y="0.5" width="%g" height="%g" rx="2" '
            'fill="%s" stroke="%s" stroke-width="1"/>'
            % (w, h, max(w - 1, 1), max(h - 1, 1), fill, line))
    return {"": body}, {"": (0, 0, w, h)}, (0, 0, 0, 0), None


def _bar_slices(img, w, h, insets=None):
    """Nine slices of a bar's own pixels.

    A trough, a thumb and a scale's trough are patterned across but flat
    along, so Kvantum may stretch the flat middle as far as it likes while the
    banded ends stay 1:1. Cutting them out is what makes a 40px thumb still
    have a 3px cap on a 200px bar.

    `insets` overrides the measured bands: Kvantum slices *every* state of an
    element with the frame widths of its normal art, so a state whose art has
    no visible bands of its own (a flat fill, such as a scale's highlight) has
    to be cut with the trough's - otherwise only the interior object existed
    and Kvantum drew the filled part as a one pixel line.
    """
    ins = tuple(int(v) for v in insets) if insets else capture.art_insets(img, w, h)
    t, r, b, l = ins
    # The stretch axis needs a middle to stretch; the cross axis may be all
    # frame (a 6px trough is 3px of rounded cap at each end and nothing else).
    if w - l - r < 1:
        ins = (t, min(r, (w - 1) // 2), b, min(l, (w - 1) // 2))
    if h - t - b < 1 and not (w - l - r >= 1 and t + b >= h):
        ins = (min(t, (h - 1) // 2), ins[1], min(b, (h - 1) // 2), ins[3])
    t, r, b, l = ins
    parts, rects = {}, {}
    for part, rect in capture.slices_for(ins, w, h).items():
        x, y, pw, ph = [int(round(v)) for v in rect]
        if pw <= 0 or ph <= 0:
            continue
        parts[part] = capture.image_object(img, x, y, pw, ph)
        rects[part] = (x, y, pw, ph)
    if len(parts) < 2:
        return ({"": capture.image_object(img, 0, 0, w, h)},
                {"": (0, 0, w, h)}, (0, 0, 0, 0))
    return parts, rects, ins


def _capture_scrollbar(widget, w, h, insets, kind, host=None):
    """Scrollbars paint as part of their scrolled container, not on their own,
    so draw the host window and crop the bar's own rectangle out of it.

    The trough is recovered from two scroll positions (see
    capture.rebuild_trough); the thumb is what differs from it. Diffing two
    positions used to hand back a slice of trough as the thumb, which is why
    grooves lost their border.
    """
    ox = oy = 0
    src = widget
    if host is not None:
        ox, oy = widget.translate_coordinates(host, 0, 0)
        src = host
    srcw, srch = capture.allocation(src)
    srcw, srch = max(srcw, w), max(srch, h)
    adj = widget.get_adjustment()
    page = adj.get_page_size()
    top = adj.get_lower()
    bottom = max(top, adj.get_upper() - page)

    def shot(value):
        adj.set_value(value)
        capture.pump(20)
        return capture.crop(capture.render_image(src, srcw, srch), ox, oy, w, h)

    img_a = shot(top)
    img_b = shot(bottom)
    adj.set_value(top)
    capture.pump(10)
    trough = capture.rebuild_trough(img_a, img_b, w, h)
    if trough is None or capture.opaque_fraction(trough) < 0.01:
        # The bar faded out at the second position (overlay scroll bars do
        # that), so there is nothing to diff against; the trough's cross
        # section is constant, so one painted row stands in for all of them.
        trough = capture.flat_trough(img_a, w, h)

    if kind == "groove":
        if trough is not None and capture.opaque_fraction(trough) >= 0.01:
            slices, rects, ins = _bar_slices(trough, w, h)
            return slices, rects, ins, trough
        syn = _synth_bar(widget, max(w, 8), max(h, 20), "groove")
        return syn if syn is not None else (None, None, None, None)

    bbox = capture.diff_bbox(img_a, trough, w, h) if trough is not None else None
    if bbox is None:
        syn = _synth_bar(widget, max(w, 8), 40, "scrollbar")
        return syn if syn is not None else (None, None, None, img_a)
    bx, by, bw, bh = bbox
    bh = max(bh, 4)
    # Keep the bar's full width, transparent margins included: Kvantum scales
    # the thumb to the bar's thickness, so a thumb trimmed to its painted pill
    # (5px inside a 12px bar) is drawn 2.4 times too fat.
    bw = w
    art = capture.crop(img_a, 0, by, bw, bh)
    slices, rects, ins = _bar_slices(art, bw, bh)
    return slices, rects, ins, art


SCROLLBAR_TOKENS = {"scrollbar": ".g2k-bar", "trough": ".g2k-trough",
                    "slider": ".g2k-slider"}


def _virtual_trough(w, h):
    """The trough as its own box tree wearing the theme's scrollbar CSS."""
    css = states.alias_tokens({"scrollbar": ".g2k-bar", "trough": ".g2k-trough"},
                              with_defines=True)
    bar = Gtk.Box()
    bar.get_style_context().add_class("g2k-bar")
    bar.get_style_context().add_class("vertical")
    trough = Gtk.Box()
    for cls in ("g2k-trough", "g2k-bar", "vertical"):
        trough.get_style_context().add_class(cls)
    bar.pack_start(trough, True, True, 0)
    handles = states.install_tree(bar, css)
    win = capture.show(bar, w, h)
    capture.pump(40)
    aw, ah = capture.allocation(trough)
    aw, ah = max(aw, 6), max(ah, 6)
    img = capture.render_image(trough, aw, ah)
    states.uninstall_tree(handles)
    win.destroy()
    if capture.opaque_fraction(img) < 0.01:
        return None
    log("  trough drawn from the theme's scrollbar CSS (%dx%d)" % (aw, ah))
    return ({"": capture.image_object(img, 0, 0, aw, ah)},
            {"": (0, 0, aw, ah)}, (0, 0, 0, 0), img)


def _scale_handle(scale, w, h):
    """The handle of a real scale, cut out of the scale's own render.

    A scale's handle has no widget of its own and most themes keep their rules
    compiled into a resource, so there is nothing to alias and a stand-in
    widget only ever produced the theme's *button* art: Adwaita's handle was
    exported as a 36x34 push button whose border read as far too thick.

    The handle is found by shape instead. A scale's trough spans the whole
    widget, so every row the trough paints is wide; the handle is the only
    thing reaching above and below that band, and its columns there are the
    handle's own. What gets cut out is exactly what GTK drew, at the size GTK
    drew it, so Kvantum can place it 1:1.
    """
    img = capture.render_image(scale, w, h)
    data, stride = img.get_data(), img.get_stride()

    def painted(x, y):
        return data[y * stride + x * 4 + 3] > 8

    span = []
    for y in range(h):
        xs = [x for x in range(w) if painted(x, y)]
        span.append((xs[0], xs[-1]) if xs else None)
    wide = [y for y, s in enumerate(span)
            if s is not None and (s[1] - s[0] + 1) >= w * 0.6]
    if not wide:
        return None
    band = (min(wide), max(wide))
    outside = [y for y in range(h)
               if span[y] is not None and not band[0] <= y <= band[1]]
    if not outside:
        return None
    x0 = min(span[y][0] for y in outside)
    x1 = max(span[y][1] for y in outside)
    y0, y1 = min(outside), max(outside)
    bw, bh = x1 - x0 + 1, y1 - y0 + 1
    if bw < 4 or bh < 4 or bw > w or bh > h:
        return None
    # The cut-out can carry a transparent row or column past the handle (the
    # scale hands back one more pixel than the handle paints); trimmed, the art
    # is exactly the handle and Kvantum's 1:1 draw has no blank edge.
    tight = capture.alpha_bbox(capture.crop(img, x0, y0, bw, bh))
    if tight is not None:
        x0, y0, bw, bh = (x0 + tight[0], y0 + tight[1], tight[2], tight[3])
    art = capture.crop(img, x0, y0, bw, bh)
    if capture.opaque_fraction(art) < 0.01:
        return None
    # Vertical art, the orientation Kvantum draws a handle in: width across the
    # slider, height along it. A horizontal GTK handle transposed is exactly
    # that, and it is what Kvantum then transposes back for a horizontal Qt
    # slider - drawn horizontally instead, every handle was squashed into the
    # wrong axis (which is why vertical sliders looked almost right and
    # horizontal ones did not).
    art = capture.transpose(art)
    bw, bh = art.get_width(), art.get_height()
    log("  scale handle cut from the scale render: %dx%d vertical" % (bw, bh))
    return ({"": capture.image_object(art, 0, 0, bw, bh)},
            {"": (0, 0, bw, bh)}, (0, 0, 0, 0), art)


def _scale_band_render(scale, w, h, kind="trough"):
    """The trough or the filled band, cut out of the scale's own render.

    Every theme paints a band across the whole scale, and the handle is the
    only thing in the way: the band left of the handle is cut as one piece and
    the band right of it as another, and the two are joined. Their caps are the
    theme's own pixels, which is what a stretched copy would smear.

    This is the answer for themes whose CSS cannot be read back - Adwaita ships
    its rules compiled into GTK - and for the old GTK 3.18 themes whose scale
    rules name nodes the aliasing does not reach. Without it those themes got a
    blank object and Kvantum drew no trough at all.
    """
    img = capture.render_image(scale, w, h)
    data, stride = img.get_data(), img.get_stride()

    def painted(x, y):
        return data[y * stride + x * 4 + 3] > 8

    span = []
    for y in range(h):
        xs = [x for x in range(w) if painted(x, y)]
        span.append((xs[0], xs[-1]) if xs else None)
    wide = [y for y, s in enumerate(span)
            if s is not None and (s[1] - s[0] + 1) >= w * 0.6]
    if not wide:
        return None
    y0, y1 = min(wide), max(wide)
    bh = y1 - y0 + 1
    # The handle reaches outside the band; its columns are what peeks out.
    outside = [y for y in range(h)
               if span[y] is not None and not y0 <= y <= y1]
    if outside:
        hx0 = min(span[y][0] for y in outside)
        hx1 = max(span[y][1] for y in outside)
    else:
        # A handle that stays inside the band: its columns are the ones whose
        # pixels differ from a column far from the middle.
        flat_x = min(w - 1, max(0, w // 8))
        flat = bytes(data[(y0 + bh // 2) * stride + flat_x * 4:
                          (y0 + bh // 2) * stride + flat_x * 4 + 4])
        diff = [x for x in range(w)
                if bytes(data[(y0 + bh // 2) * stride + x * 4:
                              (y0 + bh // 2) * stride + x * 4 + 4]) != flat]
        if not diff:
            return None
        hx0, hx1 = min(diff), max(diff)
    if kind == "highlight":
        # The filled part is what GTK paints on the low side of the handle.
        cols = [x for x in range(hx0) if any(painted(x, y)
                                             for y in range(y0, y1 + 1))]
        if not cols:
            return None
        rows = [y for y in range(h) if any(painted(x, y) for x in cols)]
        if not rows:
            return None
        return capture.crop(img, 0, min(rows), hx0,
                            max(rows) - min(rows) + 1)
    # The empty trough is only the part on the high side of the handle: the low
    # side is painted with the theme's fill, and that is the highlight's art.
    # The piece carries the trough's own right cap, so it is mirrored to give
    # the left end one too (the middle is flat and stretches anyway).
    if hx1 + 1 >= w or w - hx1 - 1 < 2:
        return None
    piece = capture.crop(img, hx1 + 1, y0, w - hx1 - 1, bh)
    pw = piece.get_width()
    out = cairo.ImageSurface(cairo.FORMAT_ARGB32, pw * 2, bh)
    cr = cairo.Context(out)
    cr.save()
    cr.translate(pw, 0)
    cr.scale(-1, 1)
    cr.set_source_surface(piece, 0, 0)
    cr.rectangle(0, 0, pw, bh)
    cr.fill()
    cr.restore()
    cr.set_source_surface(piece, pw, 0)
    cr.rectangle(pw, 0, pw, bh)
    cr.fill()
    out.flush()
    return out


def _scale_trough(scale, w, h, kind="trough", insets=None):
    """A scale's trough, cut out of the scale's own render.

    Kvantum's [Slider] is the trough a GtkScale draws, and slider_width is how
    thick that trough is. The exporter used to feed [Slider] the scroll bar's
    trough and take slider_width from the scroll bar thumb, so a theme whose
    scale trough is a 4px band (Adwaita) got a 15px bar with the wrong art.

    The band is found the same way the handle is: the trough spans the whole
    widget, so every row it paints is wide. The handle's columns are then
    skipped, because the part of the trough that ships is stretched by Kvantum
    and must not carry a handle with it.

    `kind` is "trough" or "highlight": Kvantum paints the filled part of a
    slider's groove from `<element>-toggled`, so the theme's `scale highlight`
    band is the art for that state. Without it the filled part was missing.

    The art is shipped transposed (see capture.transpose): Kvantum draws a
    groove in vertical space and transposes the painter for a horizontal
    slider, so a horizontal band of ours was stretched along the wrong axis.
    """
    img = capture.render_image(scale, w, h)
    data, stride = img.get_data(), img.get_stride()

    def painted(x, y):
        return data[y * stride + x * 4 + 3] > 8

    span = []
    for y in range(h):
        xs = [x for x in range(w) if painted(x, y)]
        span.append((xs[0], xs[-1]) if xs else None)
    wide = [y for y, s in enumerate(span)
            if s is not None and (s[1] - s[0] + 1) >= w * 0.6]
    if not wide:
        return None
    y0, y1 = min(wide), max(wide)
    bh = y1 - y0 + 1
    # The handle sits in the middle of the band, so a strip cut from the
    # scale's own render loses one of the trough's ends - and it is exactly
    # the rounded end (and its 1px border) that a stretched copy smears.
    # Rebuild the whole band from the theme's own `scale trough` rules
    # instead: at the thickness GTK gave it, so the art is the trough a scale
    # really draws, from end to end.
    art = _virtual_scale_trough(max(w, 60), bh, kind)
    explicit = None
    if art is None:
        art = _scale_band_render(scale, w, h, kind)
        if art is not None:
            # Cut straight from GTK's pixels the band has no flat middle to
            # measure (its mirror seam sits where the middle row is), so its
            # bands are read off the piece itself: the caps across and one
            # rounded end along.
            pi = capture.art_insets(art, art.get_width(), art.get_height())
            cap = max(1, pi[1])
            explicit = (pi[0], cap, pi[2], cap)
    if art is None:
        return None
    art = capture.transpose(art)
    aw, ah = art.get_width(), art.get_height()
    log("  scale %s drawn from the theme's scale CSS (%dx%d vertical)"
        % (kind, aw, ah))
    slices, rects, ins = _bar_slices(art, aw, ah,
                                     insets if insets is not None else explicit)
    return slices, rects, ins, art


def _virtual_scale_trough(w, h, kind="trough"):
    """A scale's trough (or its filled highlight) in the theme's own rules."""
    css = states.alias_tokens({"scale": ".g2k-scale", "trough": ".g2k-trough",
                               "highlight": ".g2k-highlight"},
                              with_defines=True)
    if not css.strip():
        return None
    # The scale node's own min-height describes the whole widget, handle and
    # margins included; the trough inside it is as thick as GTK allocated it.
    # Pin both so the art is the band and not the scale.
    # The theme's own min-height and padding describe the whole scale widget; a
    # *trough* is only the band GTK allocated it. Pin both boxes to the band's
    # size so the art is 6px of trough, not a 36px stripe with a band inside.
    cls_node = "g2k-" + kind
    css += ("\n.g2k-scale { min-width: 0; min-height: 0;"
            " padding: 0; margin: 0; }\n"
            ".g2k-scale .g2k-trough { min-width: 0; min-height: 0;"
            " padding: 0; margin: 0; }\n"
            ".g2k-scale .g2k-highlight { min-width: 0; min-height: 0;"
            " padding: 0; margin: 0; border: none; border-radius: 0; }\n")
    scale = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
    scale.get_style_context().add_class("g2k-scale")
    trough = Gtk.Box()
    for cls in (cls_node, "g2k-scale"):
        trough.get_style_context().add_class(cls)
    scale.set_size_request(w, h)
    trough.set_size_request(w, h)
    scale.pack_start(trough, True, True, 0)
    handles = states.install_tree(scale, css)
    win = capture.show(scale, w, h)
    capture.pump(40)
    aw, ah = capture.allocation(trough)
    img = capture.render_image(trough, aw, ah)
    states.uninstall_tree(handles)
    win.destroy()
    if capture.opaque_fraction(img) < 0.01:
        return None
    return img


def _virtual_slider(w, h):
    """A scroll bar's thumb as a plain box in the theme's own slider CSS.

    This used to be a Gtk.Button, so the theme's *button* frame came with it
    and a 36x40 button was exported as a thumb for a 12px bar. A box carries
    only the aliased slider rules. Its ancestor also needs the bar's
    orientation class, because themes scope the rule as
    `scrollbar.vertical slider`; without it the box paints nothing.

    The box is measured at its own natural size (the theme's min-width and the
    transparent border it declares) and the art is trimmed to the pixels it
    painted, so a thumb declared as a 9px pill inside a 3px transparent border
    is exported 9px wide instead of 15.
    """
    css = states.alias_tokens({"scrollbar": ".g2k-bar", "slider": ".g2k-slider"},
                              with_defines=True)
    if not css.strip():
        return None
    # A theme's scrollbar min-sizes describe a thumb in a bar whose length runs
    # one way; in a vertical bar the thumb's *width* is the bar's thickness, so
    # the box is pinned to that instead of taking the rule's min-width (40px on
    # some themes, i.e. wider than the bar it belongs to).
    css += ("\n.g2k-bar.vertical .g2k-slider "
            "{ min-width: %dpx; min-height: %dpx; }\n"
            ".g2k-bar.vertical .g2k-trough { min-width: %dpx; min-height: 0; }\n"
            % (max(w, 6), max(h, 6), max(w, 6)))
    bar = Gtk.Box()
    for cls in ("g2k-bar", "vertical"):
        bar.get_style_context().add_class(cls)
    handle = Gtk.Box()
    # `g2k-bar` too: GTK 3.18 themes put both classes on one element
    # (`.scrollbar.slider`, as Ambiance does), and the rewrite turns that into
    # `.g2k-bar.g2k-slider`, which a box without the bar class cannot match.
    for cls in ("g2k-slider", "g2k-bar", "vertical"):
        handle.get_style_context().add_class(cls)
    # The thumb is as thick as its bar and as long as a thumb is: the theme's
    # own min-width/min-height decide the rest, so its transparent border stays
    # part of the object and the paint inside it lands where the theme put it.
    # Exactly the bar's size: the trough fills the bar, so handing this the
    # measured bar width makes the thumb as thick as the groove it sits in.
    bar.set_size_request(max(w, 6), max(h, 6))
    trough = Gtk.Box()
    for cls in ("g2k-trough", "g2k-bar", "vertical"):
        trough.get_style_context().add_class(cls)
    trough.pack_start(handle, False, False, 0)
    bar.pack_start(trough, True, True, 0)
    handles = states.install_tree(bar, css)
    win = capture.show(bar, max(w, 6), max(h, 20) + 8)
    capture.pump(40)
    aw, ah = capture.allocation(handle)
    aw, ah = max(aw, 4), max(ah, 4)
    capture.pump(20)
    img = capture.render_image(handle, aw, ah)
    # Both answers have to be taken before the window goes: a widget detached
    # from its window paints nothing, so rendering it again after destroy()
    # silently produced an empty thumb.
    # Any paint counts, not just fully opaque paint: a theme may declare the
    # thumb translucent (Ambiance uses alpha(@selected_bg_color, 0.8)), and an
    # opaque-pixel test threw that away as a blank widget.
    bbox = capture.alpha_bbox(img)
    svg = ""
    if bbox is not None:
        # Trim to the pixels the theme painted: several themes declare a
        # slider wider than the paint inside it (a transparent border or a
        # margin), and an untrimmed object makes Kvantum draw dead space as
        # part of the thumb.
        bx, by, bw, bh = bbox
        bw, bh = max(bw, 3), max(bh, 6)
        svg = capture.render_fragment(handle, bx, by, bw, bh)
    states.uninstall_tree(handles)
    win.destroy()
    if bbox is None or bbox[2] < 2 or bbox[3] < 2 or not svg.strip():
        return None
    log("  scrollbar thumb: %dx%d vector, %d bytes" % (bw, bh, len(svg)))
    return ({"": svg}, {"": (0, 0, bw, bh)}, (0, 0, 0, 0), None)


def _virtual_scrollbar(kind, w=16, h=130):
    """Dress a box tree in the theme's scrollbar CSS.

    GTK does not paint a scroll bar through gtk_widget_draw() in this headless
    setup, so the trough and slider are rebuilt from the theme's own rules: node
    names are rewritten to classes and applied to a box tree with the same
    nesting (`scrollbar > trough > slider`) the rules expect. The boxes are
    pinned to the bar's real size: left to their own natural size they came out
    200x200, and that became the theme's `scroll_width`.
    """
    css = states.alias_tokens(SCROLLBAR_TOKENS, with_defines=True)
    bar = Gtk.Box()
    ctx = bar.get_style_context()
    for cls in ("g2k-bar", "vertical"):
        ctx.add_class(cls)
    trough = Gtk.Box()
    # GTK 3.18 themes style the bar itself as the track (`.scrollbar`), so the
    # trough box wears that class too; the 3.20 `trough` node keeps working
    # through plain nesting.
    for cls in ("g2k-trough", "g2k-bar", "vertical"):
        trough.get_style_context().add_class(cls)
    bar.set_size_request(w, h)
    trough.set_size_request(w, h)
    bar.pack_start(trough, True, True, 0)
    if kind == "scrollbar":
        slider = Gtk.Box()
        for cls in ("g2k-slider", "g2k-bar", "vertical"):
            slider.get_style_context().add_class(cls)
        trough.pack_start(slider, False, False, 0)
    handles = states.install_tree(bar, css)
    win = capture.show(bar, w, h)
    capture.pump(40)
    target = trough
    aw, ah = capture.allocation(target)
    aw, ah = max(aw, 4), max(ah, 6)
    svg = capture.render_fragment(target, 0, 0, aw, ah)
    img = capture.render_image(target, aw, ah)
    states.uninstall_tree(handles)
    win.destroy()
    if capture.alpha_bbox(img) is None or capture.opaque_fraction(img) < 0.01:
        return None
    log("  %s rebuilt from the theme's scrollbar CSS (%dx%d, vector)" % (kind, aw, ah))
    return {"": svg}, {"": (0, 0, aw, ah)}, (0, 0, 0, 0), None


def _combined(flags):
    c = Gtk.StateFlags.NORMAL
    for f in flags:
        c |= f
    return c


def main(argv=None):
    ap = argparse.ArgumentParser(prog="gtk2kvantum")
    ap.add_argument("outdir")
    # NB: not --name; GLib's option parser strips that while importing Gtk.
    ap.add_argument("--output-name", default=None)
    ap.add_argument("--theme", default=None, help="GTK3 theme name, e.g. Adwaita-dark")
    ap.add_argument("--only", default=None, help="comma separated element keys")
    ap.add_argument("--keep-debug", action="store_true")
    ap.add_argument("--verify", action="store_true")
    ap.add_argument("--mode", choices=("geom", "render"), default=None,
                    help="geom (default): synthesised nine-slice objects; "
                         "render: whole-widget captures stretched by Kvantum")
    ap.add_argument("--sheet", choices=("exploded", "hand"), default="exploded",
                    help="canvas layout only, never the rendering: exploded "
                         "(default) separates a state's nine pieces so each is "
                         "visible; hand leaves them touching, the way the "
                         "hand-drawn Kvantum themes are arranged")
    args = ap.parse_args(argv)
    if args.mode:
        for spec in specs.SPECS:
            spec.mode = args.mode

    ok, _ = Gtk.init_check([])
    if not ok:
        log("GTK could not open a display. Run under Xvfb or the broadway backend.")
        return 2

    settings = Gtk.Settings.get_default()
    if args.theme:
        settings.set_property("gtk-theme-name", args.theme)
    # Themes that use overlay scrollbars paint nothing until the pointer is
    # over the trough, which would export an empty slider. Ask for the classic
    # always-visible scrollbars instead.
    try:
        settings.set_property("gtk-overlay-scrolling", False)
    except Exception as exc:
        log("  (could not disable overlay scrolling: %s)" % exc)
    capture.install_neutralizer()
    capture.pump()

    theme_name = settings.get_property("gtk-theme-name")
    states.use_theme(theme_name)
    name = args.output_name or ("Gtk" + theme_name.replace(" ", ""))
    palette = probe_palette()

    os.makedirs(args.outdir, exist_ok=True)
    debug_dir = None
    if args.keep_debug or args.verify:
        debug_dir = os.path.join(args.outdir, "debug")
        os.makedirs(debug_dir, exist_ok=True)

    wanted = set(args.only.split(",")) if args.only else None
    captures = []
    for spec in specs.SPECS:
        if wanted and spec.key not in wanted:
            continue
        for state, flags in spec.variants:
            try:
                cap = capture_variant(spec, state, flags, debug_dir)
            except Exception as exc:
                log("  !! %s/%s failed: %s" % (spec.key, state, exc))
                continue
            finally:
                states.end()
            captures.append(cap)
            log("  captured %-18s %-16s %sx%s" % (cap["key"], state, cap["size"][0], cap["size"][1]))

    svg = emit.build_svg(captures, palette, args.sheet)
    kvconfig = emit.build_kvconfig(captures, palette, theme_name)
    colors = emit.build_colors(palette, name)

    svg_path = os.path.join(args.outdir, name + ".svg")
    with open(svg_path, "w") as fh:
        fh.write(svg)
    with open(os.path.join(args.outdir, name + ".kvconfig"), "w") as fh:
        fh.write(kvconfig)
    with open(os.path.join(args.outdir, name + ".colors"), "w") as fh:
        fh.write(colors)
    with open(os.path.join(args.outdir, "manifest.json"), "w") as fh:
        json.dump({"name": name, "theme": theme_name,
                   "captures": [{k: v for k, v in c.items() if k != "slices"} |
                                {"parts": sorted(c["slices"]),
                                 "rects": {p: c["slices"][p]["rect"] for p in c["slices"]}}
                                for c in captures]}, fh, indent=1)

    log("wrote %s (%d elements, %d objects)" %
        (svg_path, len(captures), sum(len(c["slices"]) for c in captures)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
