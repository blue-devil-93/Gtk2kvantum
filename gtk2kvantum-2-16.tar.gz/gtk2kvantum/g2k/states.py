"""Reach widget states GTK will not draw on request.

`gtk_widget_set_state_flags()` is not enough for every state: GtkButton
recomputes its hover/active state while drawing, so a "focused" capture comes
out pixel-identical to the plain one. The fix is to ask the theme instead of
the widget: read the theme's CSS, duplicate every rule that targets `:hover`
(or `:active`) with that pseudo-class removed, and install the copy above the
theme. The widget then paints the hovered art while being captured in its
normal state.

The same trick captures art that has no widget of its own: replacing CSS node
names with classes lets a plain box dress up as a scrollbar trough or slider.
"""

import os
import re

import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gdk, Gtk

RULE = re.compile(r"([^{}]+)\{([^{}]*)\}", re.S)
DEFINE = re.compile(r"@define-color\s+[\w-]+\s+[^;]+;", re.S)
IMPORT = re.compile(r"@import\s+url\(\s*(['\"]?)([^'\")]+)\1\s*\)\s*;")

_cache = {}
_theme_name = None


def use_theme(name):
    global _theme_name
    _theme_name = name


def _theme_path(name):
    home = os.environ.get("XDG_DATA_HOME")
    dirs = ([home] if home else []) + [
        d for d in os.environ.get("XDG_DATA_DIRS", "").split(":") if d]
    for d in dirs:
        p = os.path.join(d, "themes", name, "gtk-3.0", "gtk.css")
        if os.path.isfile(p):
            return p
    return None


def _read(path, seen=None, depth=0):
    path = os.path.realpath(path)
    seen = seen if seen is not None else set()
    if path in seen or depth > 6:
        return ""
    seen.add(path)
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            text = fh.read()
    except OSError:
        return ""

    def pull(m):
        target = m.group(2).strip()
        if target.startswith(("http:", "https:")):
            return ""
        return _read(os.path.join(os.path.dirname(path), target), seen, depth + 1)

    return IMPORT.sub(pull, text)


def theme_css():
    """The active theme's CSS with its @imports inlined (cached)."""
    if _theme_name in _cache:
        return _cache[_theme_name]
    path = _theme_path(_theme_name) if _theme_name else None
    css = _read(path) if path else ""
    _cache[_theme_name] = css
    return css


def alias_pseudo(pseudo):
    """Rules that target `pseudo`, repeated without it."""
    out = []
    for selectors, body in RULE.findall(theme_css()):
        if pseudo not in selectors:
            continue
        keep = []
        for one in selectors.split(","):
            one = one.strip()
            if pseudo in one:
                bare = one.replace(pseudo, "").strip()
                if bare and bare not in ("*",):
                    keep.append(bare)
        if keep:
            out.append("%s { %s }" % (", ".join(keep), body.strip()))
    return _validate("\n".join(out))


STATE_PSEUDOS = (":hover", ":active", ":checked", ":focus",
                 ":disabled", ":indeterminate", ":backdrop")

_DECL = re.compile(r"([a-zA-Z-]+)\s*:\s*([^;]+)")


def _px(token):
    token = token.strip()
    if token.endswith("px"):
        token = token[:-2]
    try:
        return int(round(float(token)))
    except ValueError:
        return None


def _box_values(text):
    """CSS one-to-four box values -> (top, right, bottom, left)."""
    parts = [_px(v) for v in text.replace(",", " ").split()]
    if not parts or any(p is None for p in parts):
        return None
    if len(parts) == 1:
        return (parts[0],) * 4
    if len(parts) == 2:
        return (parts[0], parts[1], parts[0], parts[1])
    if len(parts) == 3:
        return (parts[0], parts[1], parts[2], parts[1])
    return tuple(parts[:4])


def frame_slice(tokens=()):
    """The nine-slice geometry a theme declares for a widget class.

    A theme that paints with `border-image` (Ambiance, Radiance and most
    older GTK3 themes) states exactly how its art is cut up:

        border-image-width: 10px 12px 10px 12px;
        border-image-slice: 10 12 10 12;

    Those are the pixels the theme itself never scales, which is precisely
    what Kvantum's frame widths mean, so they are read instead of guessed from
    the corner radius. The plainest matching rule wins, and rules for a state
    other than :backdrop are ignored: the geometry is the same in every state.

    Returns (top, right, bottom, left) or None when the theme paints no
    border image for that class.
    """
    best, best_score = None, None
    for selectors, body in RULE.findall(theme_css()):
        decls = dict((m.group(1), m.group(2).strip())
                     for m in _DECL.finditer(body))
        # Only a real border image describes the frame: a `border-image`
        # gradient is a flat 1px line (Ambiance uses those for menu rows and
        # selected cells) and would make every frame 1px wide.
        if "url(" not in body:
            continue
        values = None
        for prop in ("border-image-width", "border-image-slice"):
            if prop not in decls:
                continue
            # A width may be a percentage or a keyword; only pixel-ish values
            # describe the art. `slice` numbers are plain pixel counts.
            values = _box_values(decls[prop])
            if values is not None:
                break
        if values is None and "border-image" in decls:
            # The shorthand, which many themes prefer:
            #   border-image: url(...) 10 12 10 12 / 10px 12px 10px 12px
            #                  stretch;
            # The widths live after the slash; the keywords after them.
            # The "/" that separates slice from width; a url() may contain
            # one too, so only a slash between numbers counts.
            tail = re.split(r"(?<=\d)\s*/\s*(?=\d)",
                            decls["border-image"], 1)
            if len(tail) == 2:
                widths = re.split(r"\b(?:stretch|repeat|round|space)\b",
                                  tail[1])[0]
                values = _box_values(widths)
        if values is None:
            continue
        for one in selectors.split(","):
            # A comment between rules belongs to the next rule's selector text
            # as far as a simple splitter is concerned; without this, every
            # rule with a section banner above it (`/*** button ***/ .button`)
            # was invisible to the matcher.
            sel = re.sub(r"/\*.*?\*/", " ", one, flags=re.S).strip()
            # State-specific art can carry a different frame (a 1px
            # `:selected` line, a linked button's 0px edge); the geometry has
            # to come from the resting rule.
            if ":" in sel.replace(":backdrop", ""):
                continue
            first = sel.split()[0]
            for token in tokens:
                if ".%s" % token not in first and first != token:
                    continue
                # Prefer the simplest rule: `.button` beats
                # `.primary-toolbar .button` for the plain widget's art.
                score = len(sel)
                # CSS cascade: at equal specificity the later rule wins.
                if best is None or score <= best_score:
                    best, best_score = values, score
    return best


def color_defines():
    """The theme's own @define-color declarations.

    A stand-in widget's CSS has to carry them: Ambiance paints its scroll bar
    slider with `alpha(@selected_bg_color, 0.8)`, and a rule naming an
    undefined colour is refused by GTK - so the slider was exported blank.
    """
    return "\n".join(m.group(0) for m in DEFINE.finditer(theme_css()))


def alias_tokens(mapping, pseudo=None, with_defines=False):
    """Rules rewritten so CSS node names become classes.

    `scrollbar.vertical trough` -> `.g2k-bar.vertical .g2k-trough`, which a
    plain box tree can satisfy. Rules for a state the capture is not in are
    dropped, and the requested one is stripped, so a plain box can carry hover
    art without ever having a pointer over it.
    """
    out = []
    for selectors, body in RULE.findall(theme_css()):
        keep = []
        for one in selectors.split(","):
            sel = re.sub(r"/\*.*?\*/", " ", one, flags=re.S).strip()
            # Both spellings count: GTK 3.20 themes style the nodes
            # (`scrollbar trough slider`), GTK 3.18 themes styled classes
            # (`.scrollbar.slider`, as Ambiance does).
            if not any(re.search(r"(?<![\w#-])\.?%s(?![\w-])" % re.escape(node), sel)
                       for node in mapping):
                continue
            # A descendant token only counts inside the primary node. `slider`
            # is also a scale's handle and `trough` a scale's groove, so
            # without this the bar wore the scale handle's art - grip dots and
            # all - and its groove picked up the scale's gradient.
            if "scrollbar" in mapping and not re.search(
                    r"(?<![\w#-])\.?scrollbar(?![\w-])", sel):
                continue
            states = [p for p in STATE_PSEUDOS if p in sel]
            if pseudo is None:
                if states:
                    continue
            elif states:
                if pseudo not in states:
                    continue
                sel = sel.replace(pseudo, "")
            for node, cls in mapping.items():
                sel = re.sub(r"(?<![\w#-])\.?%s(?![\w-])" % re.escape(node), cls, sel)
            # A rule that names two nodes in one compound selector
            # (`.scrollbar.slider`, the GTK 3.18 spelling Ambiance uses) ends
            # up as `.g2k-bar..g2k-slider`: the second node is matched after
            # the first replacement's own dot. GTK refuses that selector
            # outright, so the art it describes was silently dropped.
            sel = re.sub(r"\.{2,}", ".", sel)
            keep.append(sel)
        if keep:
            out.append("%s { %s }" % (", ".join(keep), body.strip()))
    defines = color_defines() if with_defines else ""
    body = _validate("\n".join(out), defines)
    return (defines + "\n" + body) if defines else body


def _validate(rules_text, defines=""):
    """Drop rules GTK refuses.

    One bad declaration makes load_from_data() fail for the whole sheet, which
    silently left every alias inert, so each rule is checked on its own - with
    the theme's colour definitions, or every rule that names one would look
    broken.
    """
    keep = []
    for sel, body in RULE.findall(rules_text):
        rule = "%s { %s }" % (sel.strip(), body.strip())
        prov = Gtk.CssProvider()
        try:
            prov.load_from_data((defines + "\n" + rule).encode("utf-8"))
        except Exception:
            continue
        keep.append(rule)
    return "\n".join(keep)


def provider(css_text):
    if not css_text.strip():
        return None
    prov = Gtk.CssProvider()
    try:
        prov.load_from_data(css_text.encode("utf-8"))
    except Exception:
        return None
    return prov


def install(widget, css_text):
    prov = provider(css_text)
    if prov is None:
        return None
    Gtk.StyleContext.add_provider_for_screen(
        widget.get_screen(), prov, Gtk.STYLE_PROVIDER_PRIORITY_USER)
    return prov


def uninstall(widget, prov):
    if prov is not None:
        Gtk.StyleContext.remove_provider_for_screen(widget.get_screen(), prov)


def install_tree(widget, css_text):
    """Attach a provider to one widget tree only.

    A screen-wide provider is global: installing it for the hovered capture
    also repainted every later capture. Context providers keep the fake state
    local to the widget being exported.
    """
    prov = provider(css_text)
    if prov is None:
        return []
    handles = []
    stack = [widget]
    while stack:
        w = stack.pop()
        ctx = w.get_style_context()
        Gtk.StyleContext.add_provider(
            ctx, prov, Gtk.STYLE_PROVIDER_PRIORITY_USER)
        handles.append((ctx, prov))
        if isinstance(w, Gtk.Container):
            stack.extend(w.get_children())
    return handles


def uninstall_tree(handles):
    for ctx, prov in handles:
        Gtk.StyleContext.remove_provider(ctx, prov)


_active = None


def begin(pseudo=None, tokens=None):
    """Install the alias *before* the widget is built.

    GTK resolves a widget's style when it is created: a provider added later
    never reaches it, which is why widget- and screen-level providers installed
    after the fact changed nothing. `tokens` additionally rewrites CSS node
    names to classes, for art that belongs to a node no plain widget can be.
    """
    global _active
    end()
    parts = []
    if pseudo:
        parts.append(alias_pseudo(pseudo))
    if tokens:
        # The requested fake state has to travel with the token rewrite too:
        # a rule like `menu menuitem:hover` only reaches a stand-in widget
        # once both the nodes and the pseudo-class are rewritten.
        parts.append(alias_tokens(tokens, pseudo))
    css = "\n".join(p for p in parts if p.strip())
    if not css.strip():
        return
    prov = provider(css)
    if prov is None:
        return
    Gtk.StyleContext.add_provider_for_screen(
        Gdk.Screen.get_default(), prov, Gtk.STYLE_PROVIDER_PRIORITY_USER)
    _active = prov


def end():
    global _active
    if _active is None:
        return
    screen = Gdk.Screen.get_default()
    Gtk.StyleContext.remove_provider_for_screen(screen, _active)
    Gtk.StyleContext.reset_widgets(screen)
    _active = None


def begin_css(css_text):
    """Screen-wide override for internal CSS nodes.

    A scroll bar's trough and slider are CSS nodes drawn by the range itself in
    GTK3 - not widgets - so there is no context to attach a provider to. A
    screen-level provider is the only way to hide one while capturing the other.
    """
    prov = provider(css_text)
    if prov is None:
        return None
    screen = Gdk.Screen.get_default()
    Gtk.StyleContext.add_provider_for_screen(
        screen, prov, Gtk.STYLE_PROVIDER_PRIORITY_USER)
    Gtk.StyleContext.reset_widgets(screen)
    return prov


def end_css(prov):
    if prov is None:
        return
    screen = Gdk.Screen.get_default()
    Gtk.StyleContext.remove_provider_for_screen(screen, prov)
    Gtk.StyleContext.reset_widgets(screen)
