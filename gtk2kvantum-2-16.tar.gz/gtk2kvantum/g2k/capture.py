"""Vector capture: render a live GTK3 widget into SVG fragments.

The trick is the same one gtk-vector-screenshot uses: GTK3 paints through
cairo, so pointing cairo at an *SVG surface* instead of the screen yields
scalable output. We go one step further and render each widget nine times
under a cairo clip - once per Kvantum 9-slice part - so every frame object
comes out with the right bounding box.
"""

import io
import re

import base64
import cairo
import io
import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

POSITIONS = ["topleft", "top", "topright", "left", "right",
             "bottomleft", "bottom", "bottomright"]

# Glyphs that Kvantum draws itself. Baking GTK's versions in would double them.
NEUTRALIZE_CSS = b"""
combobox arrow { -gtk-icon-source: none; min-width: 0; min-height: 0; }
spinbutton button { -gtk-icon-source: none; }
spinbutton entry { background: none; background-image: none; border: none;
                   box-shadow: none; }
scrollbar button { -gtk-icon-source: none; }
/* Kvantum draws its own scroll arrows (scroll_arrows in the kvconfig) and a
   bar without steppers is what its ScrollbarSlider/ScrollbarGroove art should
   look like. A theme that enables GTK's steppers (Luna does) otherwise bakes
   the two arrow buttons into the captured trough and thumb, and the buttons
   also change sensitivity between scroll positions, which stretches the
   measured thumb over the whole bar. */
* { -GtkScrollbar-has-backward-stepper: 0;
    -GtkScrollbar-has-forward-stepper: 0; }
"""


def pump(n=25):
    """Drain events *and* idle sources.

    Allocation and style re-resolution happen at idle priority, not as events,
    so draining only pending events left widgets with alloc_needed set and
    gtk_widget_draw() silently painted nothing (blank captures, and stale art
    right after a state change).
    """
    for _ in range(n):
        if Gtk.events_pending():
            Gtk.main_iteration()
        else:
            Gtk.main_iteration_do(False)


_neutralizer = None


def install_neutralizer():
    global _neutralizer
    prov = Gtk.CssProvider()
    prov.load_from_data(NEUTRALIZE_CSS)
    screen = Gtk.Window().get_screen()
    Gtk.StyleContext.add_provider_for_screen(
        screen, prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    _neutralizer = (screen, prov)


def suspend_neutralizer():
    """Take the capture neutraliser off the screen; returns a resume call.

    The neutraliser strips scroll bar steppers and their arrow glyphs so they
    are not baked into the trough and thumb. The stepper art itself is the
    exception: with the neutraliser gone the theme paints its own arrow again,
    exactly as an application would see it.
    """
    if _neutralizer is None:
        return lambda: None
    screen, prov = _neutralizer
    Gtk.StyleContext.remove_provider_for_screen(screen, prov)
    Gtk.StyleContext.reset_widgets(screen)

    def resume():
        Gtk.StyleContext.add_provider_for_screen(
            screen, prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        Gtk.StyleContext.reset_widgets(screen)

    return resume


def svg_inner(surface):
    s = surface.get_data().decode("utf-8") if hasattr(surface, "get_data") else None
    return s


def _svg_bytes_to_inner(raw):
    text = raw.decode("utf-8")
    start = text.index(">", text.index("<svg")) + 1
    end = text.rindex("</svg>")
    return text[start:end]


def render_fragment(widget, x, y, w, h):
    """Draw `widget` clipped to the rect (x, y, w, h) and return SVG markup
    whose coordinate origin is that rect's top-left corner."""
    buf = io.BytesIO()
    surf = cairo.SVGSurface(buf, w, h)
    cr = cairo.Context(surf)
    cr.rectangle(0, 0, w, h)
    cr.clip()
    cr.translate(-x, -y)
    widget.draw(cr)
    surf.finish()
    return _svg_bytes_to_inner(buf.getvalue())


def render_image(widget, w, h, scale=1):
    """Raster copy of a widget; `scale` renders it larger for crisp downscaling."""
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, w * scale, h * scale)
    cr = cairo.Context(surf)
    cr.scale(scale, scale)
    cr.rectangle(0, 0, w, h)
    cr.clip()
    widget.draw(cr)
    surf.flush()
    return surf


def transpose(img):
    """A surface with its axes swapped: (x, y) becomes (y, x).

    Kvantum always draws a slider's groove and handle in *vertical* space and
    transposes the painter for a horizontal slider (QStyle::CC_Slider in
    Kvantum.cpp: `grooveRect.setRect(y, x, height, width)` followed by
    `scale(1,-1); rotate(-90)`). The art therefore has to be the vertical one:
    width across the slider, height along it. GTK only gives us a horizontal
    scale render, whose transpose *is* the vertical art.
    """
    w, h = img.get_width(), img.get_height()
    out = cairo.ImageSurface(cairo.FORMAT_ARGB32, int(h), int(w))
    cr = cairo.Context(out)
    cr.transform(cairo.Matrix(0, 1, 1, 0, 0, 0))
    cr.set_source_surface(img, 0, 0)
    cr.paint()
    out.flush()
    return out


def crop(img, x, y, w, h):
    """Copy a rectangular region of a surface."""
    out = cairo.ImageSurface(cairo.FORMAT_ARGB32, int(w), int(h))
    cr = cairo.Context(out)
    cr.rectangle(0, 0, w, h)
    cr.clip()
    cr.set_source_surface(img, -x, -y)
    cr.paint()
    out.flush()
    return out


def diff_bbox(a, b, w, h):
    """Bounding box of pixels that differ between two ImageSurfaces."""
    sa, sb = a.get_data(), b.get_data()
    stride = a.get_stride()
    minx, miny, maxx, maxy = w, h, -1, -1
    for y in range(h):
        row = y * stride
        for x in range(w):
            o = row + x * 4
            if sa[o:o + 4] != sb[o:o + 4]:
                if x < minx:
                    minx = x
                if x > maxx:
                    maxx = x
                if y < miny:
                    miny = y
                if y > maxy:
                    maxy = y
    if maxx < 0:
        return None
    return (minx, miny, maxx - minx + 1, maxy - miny + 1)


def prefix_ids(fragment, prefix):
    """Namespace the ids cairo emits (clip-0, mask-0, ...) per fragment."""
    def rid(m):
        return 'id="%s--%s"' % (prefix, m.group(1))

    fragment = re.sub(r'id="([^"]+)"', rid, fragment)
    fragment = re.sub(r'url\(#([^)]+)\)', lambda m: "url(#%s--%s)" % (prefix, m.group(1)), fragment)
    fragment = re.sub(r'xlink:href="#([^"]+)"',
                      lambda m: 'xlink:href="#%s--%s"' % (prefix, m.group(1)), fragment)
    return fragment


def opaque_fraction(img):
    """Share of pixels the render actually painted; catches empty captures,
    which would otherwise verify perfectly against an equally empty reference."""
    data, stride = img.get_data(), img.get_stride()
    w, h = img.get_width(), img.get_height()
    if not w or not h:
        return 0.0
    n = 0
    for y in range(h):
        row = y * stride
        for x in range(w):
            if data[row + x * 4 + 3] > 8:
                n += 1
    return n / float(w * h)


def opaque_insets(img, w, h, alpha=248, frac=0.75):
    """Margins around the fully opaque core of a render.

    Themes paint popups with a box-shadow: the visible panel is smaller than
    the surface it is drawn on and the rim is translucent. A nine-slice of a
    menu has to include that rim in its frame, or the corners get shredded, so
    find where the opaque core starts on each side.
    """
    data, stride = img.get_data(), img.get_stride()

    def alpha_at(x, y):
        return data[y * stride + x * 4 + 3]

    def row_full(y):
        n = 0
        for x in range(w):
            if alpha_at(x, y) >= alpha:
                n += 1
        return n >= w * frac

    def col_full(x):
        n = 0
        for y in range(h):
            if alpha_at(x, y) >= alpha:
                n += 1
        return n >= h * frac

    top = next((y for y in range(h) if row_full(y)), 0)
    bottom = next((y for y in range(h - 1, -1, -1) if row_full(y)), h - 1)
    left = next((x for x in range(w) if col_full(x)), 0)
    right = next((x for x in range(w - 1, -1, -1) if col_full(x)), w - 1)
    return (top, w - 1 - right, h - 1 - bottom, left)


def probe_insets(widget, flags, pad=2):
    """9-slice insets from the widget's own CSS: border width or corner
    radius, whichever is larger, plus one pixel of slack."""
    ctx = widget.get_style_context()
    ctx.save()
    ctx.set_state(flags)
    try:
        border = ctx.get_border()
        b = (border.top, border.right, border.bottom, border.left)
    except Exception:
        b = (1, 1, 1, 1)
    r = 0
    for name in ("border-radius", "border-top-left-radius"):
        try:
            val = ctx.get_property(name, flags)
            if val is not None:
                r = max(r, int(val))
                break
        except Exception:
            pass
    ctx.restore()
    return tuple(max(b[i], r) + pad for i in range(4))


def probe_text_margins(widget, flags, frame=None):
    """How far the text sits *inside* the frame Kvantum draws.

    Kvantum puts a label at `frame + text.margin`, while GTK puts it at
    `border + padding`. The margin is therefore the difference between the
    two, not `max(frame, padding)`: that double-counted the frame and pushed
    every label about 10px too far in on a border-image theme such as
    Ambiance, whose own Kvantum theme keeps the two separate (frame 3,
    margin 2).
    """
    if frame is None:
        frame = probe_insets(widget, flags, pad=0)
    ctx = widget.get_style_context()
    ctx.save()
    ctx.set_state(flags)
    try:
        b = ctx.get_border(flags)
        bt, br, bb, bl = b.top, b.right, b.bottom, b.left
    except Exception:
        bt = br = bb = bl = 0
    try:
        # get_padding()/get_border() take the state in GTK 3.20+; called
        # without it they raise and the except above turned every margin into
        # 0, so no element in any theme ever got the theme's text padding
        # (tabs were the visible case: their labels sat flush on the frame).
        pad = ctx.get_padding(flags)
        pt, pr, pb, pl = pad.top, pad.right, pad.bottom, pad.left
    except Exception:
        pt = pr = pb = pl = 0
    ctx.restore()
    edge = (bt + pt, br + pr, bb + pb, bl + pl)
    return tuple(max(0, edge[i] - int(frame[i])) for i in range(4))


def probe_frame(widget, flags):
    """Border widths and per-corner radii from the widget's own CSS."""
    ctx = widget.get_style_context()
    ctx.save()
    ctx.set_state(flags)
    try:
        b = ctx.get_border()
        bt, br, bb, bl = b.top, b.right, b.bottom, b.left
    except Exception:
        bt = br = bb = bl = 1
    radii = []
    for name in ("border-top-left-radius", "border-top-right-radius",
                 "border-bottom-right-radius", "border-bottom-left-radius"):
        r = 0
        for prop in (name, "border-radius"):
            try:
                val = ctx.get_property(prop, flags)
                if val is not None:
                    r = int(val)
                    break
            except Exception:
                pass
        radii.append(r)
    ctx.restore()
    return (bt, br, bb, bl, radii[0], radii[1], radii[2], radii[3])


def clamp_insets(insets, w, h):
    t, r, b, l = insets
    l = min(l, max(1, (w - 4) // 2))
    r = min(r, max(1, (w - 4) // 2))
    t = min(t, max(1, (h - 4) // 2))
    b = min(b, max(1, (h - 4) // 2))
    return (int(t), int(r), int(b), int(l))


def art_insets(img, w, h):
    """The bands of a small piece of art that must not be stretched.

    A scroll bar's thumb and a scale's trough are patterned *across* and flat
    *along*: a 1px border, a 2px highlight, then the fill. Shipped as one
    object, Kvantum stretches those bands with the widget - a 40px thumb's
    3px cap became 12px on a 100px thumb, and the trough's rounded ends were
    smeared into nothing. The insets are the leading and trailing rows and
    columns that differ from the art's middle, i.e. exactly the bands that
    have to keep their own size.
    """
    data, stride = img.get_data(), img.get_stride()

    def row(y):
        o = y * stride
        return bytes(data[o:o + w * 4])

    def col(x):
        return b"".join(bytes(data[y * stride + x * 4:y * stride + x * 4 + 4])
                        for y in range(h))

    rmid, cmid = row(h // 2), col(w // 2)
    top = next((y for y in range(h) if row(y) == rmid), 0)
    bottom = next((y for y in range(h - 1, -1, -1) if row(y) == rmid), h - 1)
    left = next((x for x in range(w) if col(x) == cmid), 0)
    right = next((x for x in range(w - 1, -1, -1) if col(x) == cmid), w - 1)
    return (top, w - 1 - right, h - 1 - bottom, left)


def column_profile(img, w, h, alpha=200):
    """The mean colour of every column of opaque pixels."""
    data, stride = img.get_data(), img.get_stride()
    cols = []
    for x in range(w):
        n = r = g = b = 0
        for y in range(h):
            o = y * stride + x * 4
            if data[o + 3] > alpha:
                b += data[o]
                g += data[o + 1]
                r += data[o + 2]
                n += 1
        cols.append((r / n, g / n, b / n) if n else None)
    return cols


def pattern_period(img, w, h, lo=10):
    """The horizontal repeat of a bar's art in pixels, or None.

    GTK paints a progress bar's fill with a repeating gradient in some themes
    (DevilHuman: diagonal stripes) and GTK repeats it at a fixed pitch while
    the bar grows. Kvantum draws that art into the fill rect, so the pattern
    was stretched with the bar. It can tile an interior instead
    (`interior.x.patternsize`), but only a fill that really repeats may be
    tiled - a smooth gradient tiled would show its seam every few pixels.
    """
    cols = column_profile(img, w, h)
    if sum(1 for c in cols if c) < w - 2:
        return None
    flat = [c for c in cols if c]
    span = max(max(c) for c in flat) - min(min(c) for c in flat)
    if span < 12:
        return None
    hi = max(lo + 1, w // 3)
    dists = {}
    best = None
    for p in range(lo, hi + 1):
        if w - p < p * 2:
            break
        d = sum(abs(cols[x][i] - cols[x + p][i])
                for x in range(w - p) for i in range(3)) / ((w - p) * 3.0)
        dists[p] = d
        if best is None or d < best[1]:
            best = (p, d)
    if best is None or best[1] > 3.0:
        return None
    # A gradient matches itself better the longer the step, so its "best"
    # period is just the smallest one tried and the step either side is no
    # worse. A real repeat is a sharp minimum; without that the fill is smooth
    # and stretching it is the right thing.
    around = [dists[q] for q in (best[0] - 3, best[0] + 3) if q in dists]
    if not around or best[1] > 0.35 * min(around):
        return None
    return best[0]


def compose_periodic(img, w, h, insets, period):
    """Left cap, one period, right cap: the art a tiled interior needs.

    Kvantum repeats the interior element at `interior.x.patternsize`, so the
    element has to be exactly one period wide. Keeping a cap at each end lets
    the frame draw the fill's own border (and its rounded ends, when the theme
    has them) at their real size while only the middle repeats.
    """
    t, r, b, l = [int(v) for v in insets]
    period = max(1, min(int(period), w - l - r))
    out = cairo.ImageSurface(cairo.FORMAT_ARGB32, l + period + r, int(h))
    cr = cairo.Context(out)
    for src_x, dst_x, cw in ((0, 0, l), (l, l, period), (w - r, l + period, r)):
        if cw <= 0:
            continue
        cr.set_source_surface(crop(img, src_x, 0, cw, h), dst_x, 0)
        cr.paint()
    out.flush()
    return out


def slices_for(insets, w, h):
    """The nine rects of a 9-slice, in widget coordinates."""
    t, r, b, l = insets
    return {
        "": (l, t, w - l - r, h - t - b),
        "topleft": (0, 0, l, t),
        "top": (l, 0, w - l - r, t),
        "topright": (w - r, 0, r, t),
        "left": (0, t, l, h - t - b),
        "right": (w - r, t, r, h - t - b),
        "bottomleft": (0, h - b, l, b),
        "bottom": (l, h - b, w - l - r, b),
        "bottomright": (w - r, h - b, r, b),
    }


def show(widget, w, h, popup=False):
    """Put a widget on screen at a known size and wait for allocation."""
    win = Gtk.Window(type=Gtk.WindowType.POPUP if popup else Gtk.WindowType.TOPLEVEL)
    win.set_decorated(False)
    win.set_resizable(False)
    if popup:
        win.add(widget)
        win.set_default_size(w, h)
        win.show_all()
    else:
        win.add(widget)
        win.set_default_size(w, h)
        win.show_all()
    pump(40)
    if widget.get_allocated_width() <= 1 or widget.get_allocated_height() <= 1:
        widget.queue_resize()
        pump(40)
    return win


def allocation(widget):
    return widget.get_allocated_width(), widget.get_allocated_height()


def alpha_bbox(img, threshold=8):
    """Bounding box of the pixels that were actually painted."""
    data, stride = img.get_data(), img.get_stride()
    w, h = img.get_width(), img.get_height()
    minx, miny, maxx, maxy = w, h, -1, -1
    for y in range(h):
        row = y * stride
        for x in range(w):
            if data[row + x * 4 + 3] > threshold:
                if x < minx:
                    minx = x
                if x > maxx:
                    maxx = x
                if y < miny:
                    miny = y
                if y > maxy:
                    maxy = y
    if maxx < 0:
        return None
    return (minx, miny, maxx - minx + 1, maxy - miny + 1)


def rebuild_trough(a, b, w, h):
    """Recover a trough from two scroll positions.

    GTK draws the trough and slider as CSS nodes inside the range widget, with
    no widget of their own to attach a stylesheet to. The slider moves and the
    trough does not, so every row that is identical in both renders is trough;
    a row the slider covers is rebuilt from the nearest clean row, which is
    exact for a bar whose cross-section is constant along its length.
    """
    da, db = a.get_data(), b.get_data()
    stride = a.get_stride()
    clean = []
    for y in range(h):
        row = y * stride
        same = True
        for x in range(w):
            o = row + x * 4
            if da[o:o + 4] != db[o:o + 4]:
                same = False
                break
        clean.append(same)
    good = [y for y in range(h) if clean[y]]
    if not good:
        return None
    out = cairo.ImageSurface(cairo.FORMAT_ARGB32, w, h)
    cr = cairo.Context(out)
    for y in range(h):
        src = y if clean[y] else min(good, key=lambda g: abs(g - y))
        cr.set_source_surface(a, 0, y - src)
        cr.rectangle(0, y, w, 1)
        cr.fill()
    out.flush()
    return out


def flat_trough(img, w, h, frac=0.5):
    """A bar's trough from one render, when two scroll positions disagree.

    Overlay scroll bars fade out as soon as they are not hovered, so the second
    scroll position can come back empty and `rebuild_trough` has nothing to
    compare. A trough's cross-section is the same along the whole bar, so the
    last fully painted row stands in for every row.
    """
    data, stride = img.get_data(), img.get_stride()
    for y in range(h - 1, -1, -1):
        row = y * stride
        n = sum(1 for x in range(w) if data[row + x * 4 + 3] > 8)
        if n < w * frac:
            continue
        out = cairo.ImageSurface(cairo.FORMAT_ARGB32, int(w), int(h))
        cr = cairo.Context(out)
        for yy in range(h):
            cr.set_source_surface(img, 0, yy - y)
            cr.rectangle(0, yy, w, 1)
            cr.fill()
        out.flush()
        return out
    return None


def image_object(img, x, y, w, h):
    """One exact-size <image>, cut out of an already rendered surface.

    Widgets with their own GdkWindow (notebooks, views) ignore a cairo clip,
    so a vector fragment of them carries foreign art and measures too big.
    Cutting the pixels instead keeps the object exactly w x h.
    """
    w, h = max(int(w), 1), max(int(h), 1)
    buf = io.BytesIO()
    crop(img, x, y, w, h).write_to_png(buf)
    b64 = base64.b64encode(buf.getvalue()).decode("ascii")
    return ('<rect width="%g" height="%g" fill="#000000" fill-opacity="0"/>'
            '<image x="0" y="0" width="%g" height="%g" '
            'xlink:href="data:image/png;base64,%s"/>'
            % (w, h, w, h, b64))


def png_object(widget, w, h):
    """The widget's pixels as one exact-size object.

    For small art (check boxes, radio buttons, menu bars) the vector copy is
    sabotaged by two Qt quirks: boundsOnElement() ignores clip paths, and GTK
    sometimes paints further than the widget (oversized gradient rects). Both
    inflate the measured bounds, so Kvantum scales the art wrong. An <image> of
    exactly w x h cannot be mismeasured.
    """
    img = render_image(widget, w, h)
    buf = io.BytesIO()
    img.write_to_png(buf)
    b64 = base64.b64encode(buf.getvalue()).decode("ascii")
    return ('<rect width="%g" height="%g" fill="#000000" fill-opacity="0"/>'
            '<image x="0" y="0" width="%g" height="%g" '
            'xlink:href="data:image/png;base64,%s"/>' % (w, h, w, h, b64))
