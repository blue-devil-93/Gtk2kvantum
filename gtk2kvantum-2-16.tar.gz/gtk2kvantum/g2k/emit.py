"""Emit a Kvantum SVG theme, .kvconfig and KDE .colors from captured widgets.

Every element becomes one SVG object named `<element>-<state>`, because
Kvantum sizes objects with QSvgRenderer::boundsOnElement(), which reports
unclipped content bounds. Clipped nine-slice pieces would therefore be
measured at full widget size and drawn wrongly, so a whole-widget object
stretched by Kvantum is the correct primitive here.
"""

SVG_HEAD = (
    '<?xml version="1.0" encoding="UTF-8" standalone="no"?>\n'
    '<svg xmlns="http://www.w3.org/2000/svg"\n'
    '     xmlns:xlink="http://www.w3.org/1999/xlink"\n'
    '     version="1.1" width="{w}" height="{h}"\n'
    '     viewBox="0 0 {w} {h}">\n'
    '<!-- Exported from a GTK3 theme by gtk2kvantum (vector capture) -->\n'
)

# section -> (element key, uses text margins?)
SECTION_MAP = [
    ("PanelButtonCommand", "button", True),
    ("LineEdit", "lineedit", True),
    ("ComboBox", "combo", True),
    ("CheckBox", "checkbox", True),
    ("RadioButton", "radio", True),
    ("ScrollbarSlider", "scrollbarslider", False),
    ("ScrollbarGroove", "groove", False),
    ("Progressbar", "progress", False),
    ("ProgressbarContents", "progress-pattern", False),
    ("Menu", "menu", True),
    ("MenuItem", "menuitem", True),
    ("MenuBar", "menubar", False),
    ("MenuBarItem", "menubaritem", True),
    ("Toolbar", "toolbar", False),
    # Kvantum's element for a slider's groove is `slider`; the handle is
    # `slidercursor` in [SliderCursor]. The exporter used to point [Slider] at
    # the scroll bar's groove, so a theme whose scale trough is thinner than its
    # scroll bar (Adwaita: 4px against 15px) drew every slider far too thick.
    ("Slider", "slider", False),
    ("SliderCursor", "slidercursor", False),
    ("ToolTip", "tooltip", True),
    # Kvantum has two elements for the title area: TitleBar is the whole bar
    # (stretched), HeaderSection its nine-sliced frame. GTK3 draws both with
    # one header bar, and KvAmbiance ships both, so both are exported.
    ("TitleBar", "titlebar", False),
    ("HeaderSection", "header", True),
    ("Window", "window", False),
    ("GenericFrame", "common", False),
    ("GroupBox", "group", True),
    ("IndicatorSpinBox", "spin", False),
    ("ItemView", "itemview", False),
    ("Tab", "tab", True),
    ("TabFrame", "tabframe", False),
    ("TabBarFrame", "common", False),
]

INHERITS = [
    ("PanelButtonTool", "PanelButtonCommand"),
    ("ToolbarButton", "PanelButtonCommand"),
    ("Dock", "PanelButtonCommand"),
    ("ToolboxTab", "Tab"),
    # A drop-down button is a button with an arrow, and the arrow is the only
    # part Kvantum adds: inheriting the button plate is what KvLibadwaita does
    # instead of shipping a second plate that would have to be kept in step.
    ("DropDownButton", "PanelButtonCommand"),
]

TRANSPARENT_FALLBACK = '<rect x="0" y="0" width="2" height="2" fill="none"/>'

EXTRA_SECTIONS = [
    ("StatusBar", ["inherits=GenericFrame", "frame=false",
                   "interior=false"]),
]


def object_name(element, state, part=""):
    return "%s-%s%s" % (element, state, ("-" + part) if part else "")


# The document is laid out as a sheet so it can be opened and edited in
# Inkscape. One cell per state, and inside the cell the nine pieces are drawn as
# an exploded nine-slice diagram: interior in the middle, top above it, bottom
# below it, a corner in each corner. That is the same arrangement the hand-drawn
# Kvantum themes use, and the one that shows what the file actually is - nine
# separately editable pieces - instead of a seamless widget or a stream of loose
# strips. Cells flow five to a row in capture order and every column is as wide
# as its widest cell, so the board stays a table. Kvantum only reads object ids
# and bounds, so neither the translate nor the containers change anything for
# it - it never asks for a `g2k-` id. No text is written into the document: the
# names are only ids now.
LAYOUT_MARGIN = 30
LAYOUT_GAP = 22
LAYOUT_ROW_GAP = 34
LAYOUT_COLUMNS = 5
# The gap that explodes a state's nine pieces, so the slices stay visible
# instead of merging into one shape the moment the art is seamless.
LAYOUT_EXPLODE = (6, 12)

# Reading order inside a cell: the ring around the interior, top row first.
PIECE_ORDER = ("topleft", "top", "topright", "left", "", "right",
               "bottomleft", "bottom", "bottomright")


def explode_gap(insets):
    """How far to pull the nine pieces apart: as wide as the frame is thick,
    so a 3px border and a 6px border both read at a glance, kept between 4 and
    10px so a 1px hairline does not vanish behind its own gap."""
    t, r, b, l = [int(v) for v in insets]
    thin = min([v for v in (t, r, b, l) if v > 0] or [1])
    return max(LAYOUT_EXPLODE[0], min(LAYOUT_EXPLODE[1], thin))


def slice_offsets(insets, w, h, gap=0):
    """Where each nine-slice piece of a w x h widget sits on the sheet.

    With `gap` at 0 the pieces are their own nine-slice slots and reassemble
    into the widget. With a gap they are an exploded diagram of the same
    thing - interior in the middle, `top` above it, `bottom` below, a corner in
    each corner - which is the layout the hand-drawn themes are written in, and
    the only one in which each piece can be seen and grabbed on its own.
    """
    t, r, b, l = [int(v) for v in insets]
    iw, ih = w - l - r, h - t - b
    x1, x2 = l + gap, l + iw + 2 * gap
    y1, y2 = t + gap, t + ih + 2 * gap
    return {
        "": (x1, y1),
        "topleft": (0, 0), "top": (x1, 0), "topright": (x2, 0),
        "left": (0, y1), "right": (x2, y1),
        "bottomleft": (0, y2), "bottom": (x1, y2),
        "bottomright": (x2, y2),
    }


def build_svg(captures, palette=None, sheet="exploded"):
    """`sheet="exploded"` pulls a state's nine pieces apart so each one is
    visible; `sheet="hand"` leaves them touching, which is how the hand-drawn
    Kvantum themes are arranged and turns them back into one seamless shape.
    Either way the pieces sit in their nine-slice places, and either way Kvantum
    draws the same pixels."""
    cells = []
    for cap in captures:
        # A tiled fill's pieces live in the composed art's own box, which is
        # narrower than the widget it stands for (one cap, one period, one
        # cap). Laying them out in widget space would scatter them on the
        # sheet, so the art size is used for the diagram when there is one.
        w, h = [int(v) for v in (cap.get("art_size") or cap["size"])]
        gap = (explode_gap(cap["insets"])
               if cap.get("frame") and sheet == "exploded" else 0)
        offsets = (slice_offsets(cap["insets"], w, h, gap)
                   if cap.get("frame") else None)
        pieces = []
        for part in PIECE_ORDER:
            sl = cap["slices"].get(part)
            if sl is None:
                continue
            pw = max(int(round(sl["rect"][2])), 0)
            ph = max(int(round(sl["rect"][3])), 0)
            # A widget with no frame is one object drawn at its own origin; a
            # framed one is put back together from its own piece offsets.
            px, py = (offsets or {}).get(part, (0, 0))
            oid = object_name(cap["element"], cap["state"], part)
            pieces.append((oid, sl, px, py, pw, ph))
        if not pieces:
            continue
        cw = max([w + 2 * gap] + [px + pw for _, _, px, _, pw, _ in pieces])
        ch = max([h + 2 * gap] + [py + ph for _, _, _, py, _, ph in pieces])
        cells.append((cap, pieces, cw, ch))

    rows = [cells[i:i + LAYOUT_COLUMNS]
            for i in range(0, len(cells), LAYOUT_COLUMNS)]
    ncols = max((len(r) for r in rows), default=1)
    col_w = [0] * ncols
    for row in rows:
        for c, cell in enumerate(row):
            col_w[c] = max(col_w[c], cell[2])
    col_x, x = [], LAYOUT_MARGIN
    for cw in col_w:
        col_x.append(x)
        x += cw + LAYOUT_GAP
    canvas_w = x - LAYOUT_GAP + LAYOUT_MARGIN

    body = []
    y = LAYOUT_MARGIN
    for row in rows:
        row_h = max(cell[3] for cell in row)
        for c, (cap, pieces, cw, ch) in enumerate(row):
            # Integer translation only: a half-pixel shift would soften
            # every edge and put the sheet and Kvantum's own render a hair
            # apart, which is exactly what this layout must not do.
            cx = col_x[c] + (col_w[c] - cw) // 2
            body.append('<g id="g2k-%s-%s">\n' % (cap["element"], cap["state"]))
            for oid, sl, px, py, pw, ph in pieces:
                svg = sl["svg"].strip()
                if pw > 0 and ph > 0:
                    # Qt (and therefore Kvantum) maps an object's *painted*
                    # bounds onto the target rect. Art that does not fill its
                    # box - a check mark inset in its allocation, a menu whose
                    # rim is shadow - would be stretched to fit. An invisible
                    # rect of the exact slice size pins the bounds, so the
                    # object is drawn 1:1.
                    svg = ('<rect width="%g" height="%g" fill="#000000" '
                           'fill-opacity="0"/>%s' % (pw, ph, svg))
                if cap["element"] in ("window", "itemview") and palette:
                    # The window interior is just the theme background; a solid
                    # rect is exact, crisp and avoids capturing the window.
                    w, h = cap["size"]
                    colour = palette.get(
                        "kv_window" if cap["element"] == "window"
                        else "kv_base", "#303030")
                    svg = ('<rect x="0" y="0" width="%d" height="%d" '
                           'fill="%s"/>' % (w, h, colour))
                elif len(svg) < 24:
                    # Nothing drawn (e.g. an empty menu item): keep the id.
                    svg = TRANSPARENT_FALLBACK
                body.append('<g id="%s" transform="translate(%g,%g)">%s</g>\n'
                            % (oid, cx + px, y + py, svg))
            body.append("</g>\n")
        y += row_h + LAYOUT_ROW_GAP
    canvas_h = y - LAYOUT_ROW_GAP + LAYOUT_MARGIN

    return (SVG_HEAD.format(w=int(round(canvas_w)), h=int(round(canvas_h)))
            + "".join(body) + "</svg>\n")


def _normal(captures, key):
    """The normal-state capture of an element; its geometry sets the frame
    widths Kvantum will use for every state."""
    for want_normal in (True, False):
        for cap in captures:
            if cap["key"] == key and (cap["state"] == "normal" or not want_normal):
                return cap
    return None


def _thick(cap, fallback):
    """Cross-section of a bar-shaped capture: the short side."""
    if cap is None:
        return fallback
    w, h = cap["size"]
    return max(1, min(int(w), int(h)))


def _section_block(cap, key, margins):
    """The body of one kvconfig section, from one capture."""
    t, r, b, l = cap["insets"]
    mt, mr, mb, ml = cap.get("margins") or (0, 0, 0, 0)
    framed = bool(cap.get("frame"))
    # Always give the element an interior. A groove shipped with neither frame
    # nor interior (`interior=false` used to be hard-coded for it) is drawn as
    # nothing at all: Kvantum then left the whole scroll bar track empty and
    # only the thumb floated on the window background.
    interior = True
    out = ["frame=%s" % ("true" if framed else "false"),
           "frame.element=%s" % cap["element"],
           "frame.top=%d" % (t if framed else 0),
           "frame.bottom=%d" % (b if framed else 0),
           "frame.left=%d" % (l if framed else 0),
           "frame.right=%d" % (r if framed else 0),
           "interior=%s" % ("true" if interior else "false")]
    if interior:
        out.append("interior.element=%s" % cap["element"])
    if cap.get("pattern"):
        # Kvantum repeats an interior at this width instead of stretching it:
        # the theme's own pattern pitch survives a longer progress bar.
        out.append("interior.x.patternsize=%d" % int(cap["pattern"]))
    if key == "scrollbarslider":
        # Kvantum's own default gives a scrollbar slider a decorative
        # "grip" indicator: three dots drawn in the middle of the thumb,
        # which GTK never paints. Zero size means no indicator.
        out.append("indicator.size=0")
    if margins:
        out.append("text.margin.top=%d" % mt)
        out.append("text.margin.bottom=%d" % mb)
        out.append("text.margin.left=%d" % ml)
        out.append("text.margin.right=%d" % mr)
    return out


def build_kvconfig(captures, palette, theme_name):
    lines = []
    add = lines.append
    # Kvantum draws the scroll bar's thumb and the slider's handle into rects
    # it sizes itself, so those sizes have to be the ones the art was captured
    # at. They used to be fixed at 16/16 and 8, while the art was a padded
    # button: the handle was scaled to half its size and its border looked
    # thick, and the thumb was squashed into a bar narrower than its own art.
    handle = _normal(captures, "slidercursor")
    thumb = _normal(captures, "scrollbarslider")
    groove = _normal(captures, "groove")
    trough = _normal(captures, "slider")
    handle_w, handle_h = (handle["size"] if handle else
                          (palette.get("slider_handle_width", 16),
                           palette.get("slider_handle_length", 16)))
    # The bar is exactly as thick as the art captured for it. Taking the short
    # side of a thumb sized 16x52 gave 16, but the groove came out 14 while its
    # art was 16 - and Kvantum then squeezed one of them into the other, which
    # is a visible half-pixel of blur on a 1px theme border.
    scroll_width = int(groove["size"][0]) if groove else palette.get("scroll_width", 12)
    stepper = _normal(captures, "scarrow-up")
    # slider_width is the thickness of a GtkScale's trough, not of a scroll bar
    # thumb: a scale's trough is usually much thinner, and it is its own
    # capture now. That art is vertical (Kvantum transposes its painter for a
    # horizontal slider), so the thickness is its *width*.
    if trough:
        slider_width = int(trough["size"][0])
    elif thumb:
        slider_width = int(thumb["size"][0])
    else:
        slider_width = palette.get("slider_width", 8)
    scroll_width = max(scroll_width, 1)
    slider_width = max(slider_width, 1)
    add("[%General]")
    add("author=gtk2kvantum")
    add('comment=Exported from the GTK3 theme "%s" by vector capture' % theme_name)
    add("x11drag=true")
    add("left_tabs=false")
    add("joined_inactive_tabs=false")
    add("attach_active_tab=false")
    add("group_toolbar_buttons=false")
    add("composite=true")
    add("menu_shadow_depth=0")
    add("tooltip_shadow_depth=0")
    # A theme without steppers should not have Kvantum draw arrows on its bar.
    add("scroll_arrows=%s" % ("true" if palette.get("scroll_arrows", True)
                              else "false"))
    if palette.get("scroll_min_extent"):
        add("scroll_min_extent=%d" % palette["scroll_min_extent"])
    # A check box's art is rendered at twice its size for crispness; the size
    # the theme asks for is half the captured object (KvAmbiance uses 16).
    check = _normal(captures, "checkbox")
    if check:
        side = min(int(check["size"][0]), int(check["size"][1]))
        add("check_size=%d" % max(8, side // 2 if side > 24 else side))
    add("scroll_width=%d" % scroll_width)
    add("slider_width=%d" % slider_width)
    # Kvantum's `width` is the handle's thickness (across the slider) and
    # `length` is its size along it. The handle art is shipped vertical - the
    # orientation Kvantum draws it in - so width is the art's own width and
    # length its height.
    add("slider_handle_width=%d" % int(handle_w))
    add("slider_handle_length=%d" % int(handle_h))
    add("")
    add("[GeneralColors]")
    for key, val in palette["kvcolors"]:
        add("%s=%s" % (key, val))
    add("")
    add("[Hacks]")
    add("respect_darkness=%s" % ("true" if palette.get("dark") else "false"))
    add("")

    # Kvantum draws the scroll bar's steppers (arrows) itself, from the
    # [Scrollbar] group: without that section it fell back to its default,
    # which drew pale, undersized arrows - GTK's own steppers are dark
    # triangles in the theme's text colour. Our SVG has no arrow art to give
    # it (GTK will not paint a scroll bar headless), so at least the colour
    # and size come from the theme instead of from Kvantum's default.
    kvcolours = dict(palette["kvcolors"])
    if _normal(captures, "scrollbarslider") is not None:
        arrow_col = kvcolours.get("text.color", "#000000")
        add("[Scrollbar]")
        # Kvantum draws the steppers with `default_frame_spec`, i.e. it never
        # puts a frame behind them, so `inherits=` bought nothing: the plate
        # has to be part of the indicator art. `scarrow` is GTK's own stepper
        # button (plate + arrow) and is drawn into the extent-sized square at
        # each end of the bar.
        add("indicator.element=scarrow")
        add("indicator.size=%d" % (min(stepper["size"]) if stepper else 10))
        add("text.normal.color=%s" % arrow_col)
        add("text.focus.color=%s" % arrow_col)
        add("text.press.color=%s" % arrow_col)
        add("text.toggle.color=%s" % arrow_col)
        add("text.disabled.color=%s"
            % kvcolours.get("disabled.text.color", arrow_col))
        add("")

    # A menu bar's own colours, from the bar and its titles as GTK paints
    # them. Without these Kvantum drew a menubar's labels in the window's text
    # colour, which is dark on a dark bar for Ambiance and Pluto.
    kvcol = dict(palette["kvcolors"])
    mb_text = palette.get("menubar_text")
    mb_active = palette.get("menubar_active_text") or mb_text
    mb_disabled = (palette.get("menubar_disabled_text")
                   or kvcol.get("disabled.text.color", mb_text))
    mi_text = palette.get("menuitem_text") or kvcol.get("text.color", "#000000")
    mi_active = palette.get("menuitem_active_text") or mi_text
    mi_disabled = (palette.get("menuitem_disabled_text")
                   or kvcol.get("disabled.text.color", mi_text))

    for section, key, margins in SECTION_MAP:
        cap = _normal(captures, key)
        if cap is None:
            continue
        add("[%s]" % section)
        for line in _section_block(cap, key, margins):
            add(line)
        if key == "menubar" and mb_text:
            add("text.normal.color=%s" % mb_text)
            add("text.normal.inactive.color=%s" % mb_text)
            add("text.disabled.color=%s" % mb_disabled)
        if key == "menuitem":
            # A popup row's label is drawn from the item's own colours, and
            # the lit states are all the hover plate: without them Kvantum
            # used the window's text colour, which on a theme with a dark
            # highlight (Aztec, Pluto) was black on black.
            add("text.normal.color=%s" % mi_text)
            add("text.normal.inactive.color=%s" % mi_text)
            add("text.focus.color=%s" % mi_active)
            add("text.press.color=%s" % mi_active)
            add("text.toggle.color=%s" % mi_active)
            add("text.disabled.color=%s" % mi_disabled)
        if key == "menubaritem" and mb_text:
            add("text.normal.color=%s" % mb_text)
            add("text.normal.inactive.color=%s" % mb_text)
            add("text.focus.color=%s" % mb_active)
            add("text.press.color=%s" % mb_active)
            add("text.toggle.color=%s" % mb_active)
            add("text.disabled.color=%s" % mb_disabled)
        add("")

    # A toolbar entry is an ordinary entry on the toolbar's plate: GTK themes
    # style it with the same frame, and KvLibadwaita declares it by pointing at
    # its own `lineedit` element instead of shipping a second one. Without the
    # section Kvantum drew its default theme's entry in every toolbar search
    # field.
    lineedit = _normal(captures, "lineedit")
    if lineedit is not None:
        add("[ToolbarLineEdit]")
        for line in _section_block(lineedit, "lineedit", False):
            add(line)
        add("")

    for child, parent in INHERITS:
        add("[%s]" % child)
        add("inherits=%s" % parent)
        add("")

    # Sections with nothing of their own to draw, but whose existence stops
    # Kvantum falling back to its default theme's art: a status bar is the
    # generic frame with no frame and no interior, as KvAmbiance declares it.
    for section, body in EXTRA_SECTIONS:
        add("[%s]" % section)
        for line in body:
            add(line)
        add("")

    return "\n".join(lines)


def _c(t):
    return "%d,%d,%d" % (t[0], t[1], t[2])


def build_colors(palette, name):
    w = palette["window"]; v = palette["base"]; b = palette["button"]
    fg = palette["text"]; sel = palette["highlight"]; selfg = palette["highlight_text"]
    dis = palette["disabled"]

    def block(title, bg, fore):
        return [
            "[Colors:%s]" % title,
            "BackgroundAlternate=%s" % _c(bg),
            "BackgroundNormal=%s" % _c(bg),
            "DecorationFocus=%s" % _c(sel),
            "DecorationHover=%s" % _c(sel),
            "ForegroundActive=%s" % _c(sel),
            "ForegroundInactive=%s" % _c(dis),
            "ForegroundLink=%s" % _c(palette["link"]),
            "ForegroundNegative=218,68,83",
            "ForegroundNeutral=246,116,0",
            "ForegroundNormal=%s" % _c(fore),
            "ForegroundPositive=39,174,96",
            "ForegroundVisited=%s" % _c(palette["visited"]),
            "",
        ]

    lines = ["[General]", "Name=%s" % name, "ColorScheme=%s" % name,
             "shadeSortColumn=true", ""]
    lines += block("Window", w, fg)
    lines += block("View", v, fg)
    lines += block("Button", b, fg)
    lines += block("Selection", sel, selfg)
    lines += block("Tooltip", palette["tooltip_bg"], palette["tooltip_fg"])
    lines += block("Complementary", sel, selfg)
    return "\n".join(lines)
