"""gtk2kvantum: export a GTK3 theme to a Kvantum SVG theme."""
