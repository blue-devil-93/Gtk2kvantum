#!/usr/bin/env python3
"""Side-by-side debug sheet: GTK reference | rebuilt from export | difference."""

import os
import sys

import cairo

SCALE = 6


def load(path):
    return cairo.ImageSurface.create_from_png(path)


def upscale(img, s, bg=(0.35, 0.35, 0.38)):
    w, h = img.get_width() * s, img.get_height() * s
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, w, h)
    cr = cairo.Context(surf)
    cr.set_source_rgb(*bg)
    cr.paint()
    cr.scale(s, s)
    cr.set_source_surface(img, 0, 0)
    cr.paint()
    return surf


def diff_img(a, b, s, bg=(0.2, 0.2, 0.2)):
    w, h = a.get_width(), a.get_height()
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, w * s, h * s)
    cr = cairo.Context(surf)
    cr.set_source_rgb(*bg)
    cr.paint()
    da, db = a.get_data(), b.get_data()
    stride = a.get_stride()
    for y in range(h):
        for x in range(w):
            o = y * stride + x * 4
            d = (abs(da[o] - db[o]) + abs(da[o + 1] - db[o + 1]) +
                 abs(da[o + 2] - db[o + 2])) / (3 * 255.0)
            if d > 0.02:
                cr.set_source_rgba(1.0, 1.0 - d, 0.0, min(1.0, 0.25 + d))
                cr.rectangle(x * s, y * s, s, s)
                cr.fill()
    return surf


def main():
    outdir = sys.argv[1]
    keys = sys.argv[2:] or ["button-normal", "checkbox-normal", "common-normal",
                            "progress-normal", "menuitem-normal", "tab-normal"]
    debug = os.path.join(outdir, "debug")
    reas = os.path.join(debug, "reassembly")
    rows = []
    for key in keys:
        ref = os.path.join(debug, key + ".png")
        reb = os.path.join(reas, key + "-1x.png")
        if not (os.path.exists(ref) and os.path.exists(reb)):
            continue
        a, b = load(ref), load(reb)
        if (a.get_width(), a.get_height()) != (b.get_width(), b.get_height()):
            continue
        rows.append((key, upscale(a, SCALE), upscale(b, SCALE), diff_img(a, b, SCALE)))

    if not rows:
        print("nothing to compare")
        return 1

    cw = max(r[1].get_width() for r in rows) + 160
    ch = max(r[1].get_height() for r in rows) + 26
    sheet = cairo.ImageSurface(cairo.FORMAT_ARGB32, cw * 3, ch * len(rows))
    cr = cairo.Context(sheet)
    cr.set_source_rgb(0.10, 0.10, 0.11)
    cr.paint()
    cr.select_font_face("DejaVu Sans")
    cr.set_font_size(13)
    for i, (key, a, b, d) in enumerate(rows):
        y = i * ch
        cr.set_source_rgb(0.8, 0.8, 0.85)
        cr.move_to(6, y + 16)
        cr.show_text(key)
        for j, img in enumerate((a, b, d)):
            cr.set_source_surface(img, j * cw + 150, y + 20)
            cr.paint()
        cr.set_source_rgb(0.55, 0.55, 0.6)
        for j, lab in enumerate(("gtk render", "rebuilt from svg", "difference")):
            cr.move_to(j * cw + 150, y + 14)
            cr.show_text(lab)
    sheet.write_to_png(os.path.join(outdir, "compare.png"))
    print("wrote compare.png")
    return 0


if __name__ == "__main__":
    sys.exit(main())
