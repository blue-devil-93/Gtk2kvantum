"""Synthesise Kvantum nine-slice objects from the theme's own pixels.

Kvantum sizes every SVG object with QSvgRenderer::boundsOnElement(), and Qt
reports *unclipped* content bounds, so a sliced render can never work: each
piece would measure as the whole widget. The way out is to stop slicing the
render and start drawing the pieces.

The frame is not redrawn from guessed geometry any more. Measuring a border
width and a corner radius and then painting arcs and lines back missed by a
pixel or two wherever a theme insets a highlight or a shade, which left a
1-3px seam of page colour in every button and drew shadow lines in the wrong
place. Instead each of the eight frame pieces takes the pixels the theme
actually painted, run-length encoded into plain <rect> elements: exact by
construction, still vector, and no clip paths anywhere.

The interior - the part Kvantum stretches to the widget's size - is one
vertical gradient sampled per row, so a theme's gradient stays smooth when it
is stretched and child art (a combo's arrow, a spin button's buttons) cannot
be smeared across the field.

           sl            iw            sr
      +----------+--------------+----------+
  st  | topleft  |     top      | topright |
      +----------+--------------+----------+
  ih  |  left    |   interior   |  right   |
      +----------+--------------+----------+
  sb  |bottomleft|    bottom    |bottomright|
      +----------+--------------+----------+
"""

POSITIONS = ("topleft", "top", "topright", "left", "right",
             "bottomleft", "bottom", "bottomright")


def normalise(raw, w, h):
    """Clamp measured borders/radii so the nine pieces stay non-degenerate."""
    bt, br, bb, bl, rtl, rtr, rbr, rbl = [max(0, int(v)) for v in raw]
    st = max(bt, rtl, rtr, 1)
    sr = max(br, rtr, rbr, 1)
    sb = max(bb, rbl, rbr, 1)
    sl = max(bl, rtl, rbl, 1)

    while w - sl - sr < 2 and (sl > 1 or sr > 1):
        if sl >= sr and sl > 1:
            sl -= 1
        elif sr > 1:
            sr -= 1
        else:
            break
    while h - st - sb < 2 and (st > 1 or sb > 1):
        if st >= sb and st > 1:
            st -= 1
        elif sb > 1:
            sb -= 1
        else:
            break

    return {
        "bt": min(bt, st), "br": min(br, sr), "bb": min(bb, sb), "bl": min(bl, sl),
        "rtl": min(rtl, sl, st), "rtr": min(rtr, sr, st),
        "rbr": min(rbr, sr, sb), "rbl": min(rbl, sl, sb),
        "st": st, "sr": sr, "sb": sb, "sl": sl,
    }


def insets(fr):
    return (fr["st"], fr["sr"], fr["sb"], fr["sl"])


def sizes(fr, w, h):
    iw, ih = w - fr["sl"] - fr["sr"], h - fr["st"] - fr["sb"]
    return {
        "": (iw, ih),
        "top": (iw, fr["st"]),
        "bottom": (iw, fr["sb"]),
        "left": (fr["sl"], ih),
        "right": (fr["sr"], ih),
        "topleft": (fr["sl"], fr["st"]),
        "topright": (fr["sr"], fr["st"]),
        "bottomleft": (fr["sl"], fr["sb"]),
        "bottomright": (fr["sr"], fr["sb"]),
    }


def rects(fr, w, h):
    return {part: (0, 0, int(sz[0]), int(sz[1]))
            for part, sz in sizes(fr, w, h).items()}


def boxes(fr, w, h):
    """Where each piece sits inside the widget, in widget pixels."""
    sl, sr, st, sb = fr["sl"], fr["sr"], fr["st"], fr["sb"]
    iw, ih = w - sl - sr, h - st - sb
    return {
        "": (sl, st, iw, ih),
        "top": (sl, 0, iw, st),
        "bottom": (sl, h - sb, iw, sb),
        "left": (0, st, sl, ih),
        "right": (w - sr, st, sr, ih),
        "topleft": (0, 0, sl, st),
        "topright": (w - sr, 0, sr, st),
        "bottomleft": (0, h - sb, sl, sb),
        "bottomright": (w - sr, h - sb, sr, sb),
    }


def reader(img, w, h):
    """A pixel probe over a rendered surface, in straight (unpremultiplied)
    colours. Returns (red, green, blue, alpha) with alpha in 0..1."""
    data, stride = img.get_data(), img.get_stride()

    def px(x, y):
        x = min(max(int(x), 0), w - 1)
        y = min(max(int(y), 0), h - 1)
        o = y * stride + x * 4
        blue, green, red, alpha = data[o], data[o + 1], data[o + 2], data[o + 3]
        if alpha:
            red = min(255, red * 255 // alpha)
            green = min(255, green * 255 // alpha)
            blue = min(255, blue * 255 // alpha)
        return (red, green, blue, alpha / 255.0)

    return px


def _hex(colour):
    return "#%02X%02X%02X" % colour[:3]


def _pixels(px, box):
    """One frame piece: its real pixels, run-length encoded into rects.

    Runs are read across each row and identical runs on the next row are
    grown downwards, so a 1px border line becomes one tall rect and a flat
    fill becomes one big one instead of one rect per pixel. Translucent
    pixels keep their alpha, which is what makes a theme's antialiased corner
    and its inset shadow lines come out exactly as painted.
    """
    x0, y0, pw, ph = box
    if pw <= 0 or ph <= 0:
        return ""
    done, open_runs = [], {}
    for j in range(ph):
        y = y0 + j
        runs = []
        x = x0
        while x < x0 + pw:
            colour = px(x, y)
            x2 = x + 1
            while x2 < x0 + pw and px(x2, y) == colour:
                x2 += 1
            runs.append((x, x2 - x, colour))
            x = x2
        nxt = {}
        for rx, rw, colour in runs:
            key = (rx, rw, colour)
            if key in open_runs:
                start, length = open_runs.pop(key)
                nxt[key] = (start, length + 1)
            else:
                nxt[key] = (y, 1)
        for key, (start, length) in open_runs.items():
            done.append((key, start, length))
        open_runs = nxt
    for key, (start, length) in open_runs.items():
        done.append((key, start, length))

    out = []
    for (rx, rw, colour), start, length in done:
        if colour[3] <= 0.004:
            continue
        op = "" if colour[3] >= 0.996 else ' fill-opacity="%.3f"' % colour[3]
        out.append('<rect x="%g" y="%g" width="%g" height="%g" fill="%s"%s/>'
                   % (rx - x0, start - y0, rw, length, _hex(colour), op))
    return "".join(out)


GRID_COLS = 12
GRID_ROWS = 32


def _interior(element, state, px, box):
    """The stretched middle: a coarse grid of real pixels, run-merged.

    This was one vertical gradient, which is exact for a button but wrong for
    anything that shades in both directions: a menu panel with a diagonal
    fill (Aztec, Pluto) flattened into horizontal bands as soon as Kvantum
    stretched it, which is half of what made those frames look off. Sampling
    a grid keeps both directions; identical neighbours merge back into a
    single rect, so a flat or vertically shaded field still costs one rect per
    row and the files stay small.

    Samples sit in the middle of their cell, so a child widget's own art (a
    combo's arrow, a spin button's steppers) is not picked up from an edge and
    smeared across every control Kvantum draws with the object.
    """
    x0, y0, pw, ph = box
    if pw <= 0 or ph <= 0:
        return ""
    cols = max(2, min(GRID_COLS, int(pw)))
    rows = max(2, min(GRID_ROWS, int(ph)))
    cw, ch = pw / float(cols), ph / float(rows)
    cells = [[px(x0 + (c + 0.5) * cw, y0 + (j + 0.5) * ch)
              for c in range(cols)] for j in range(rows)]
    if all(cell[3] <= 0.004 for row in cells for cell in row):
        return ""

    def uniform(row):
        first = row[0]
        return all(abs(cell[0] - first[0]) <= 2 and abs(cell[1] - first[1]) <= 2
                   and abs(cell[2] - first[2]) <= 2
                   and abs(cell[3] - first[3]) <= 0.02 for cell in row)

    if all(uniform(row) for row in cells):
        # One direction only: a real gradient scales without seams, and cell
        # edges of a grid would leave faint lines once Kvantum stretches it.
        gid = "%s-%s-i-grad" % (element, state)
        out = ['<defs><linearGradient id="%s" gradientUnits="userSpaceOnUse" '
               'x1="0" y1="0" x2="0" y2="%g">' % (gid, ph)]
        for j, row in enumerate(cells):
            red, green, blue, alpha = row[0]
            frac = (j + 0.5) / float(rows)
            if alpha >= 0.996:
                out.append('<stop offset="%.4f" stop-color="%s"/>'
                           % (frac, _hex((red, green, blue, alpha))))
            else:
                out.append('<stop offset="%.4f" stop-color="%s" stop-opacity="%.3f"/>'
                           % (frac, _hex((red, green, blue, alpha)), alpha))
        out.append("</linearGradient></defs>")
        out.append('<rect width="%g" height="%g" fill="url(#%s)"/>' % (pw, ph, gid))
        return "".join(out)

    # Merge equal neighbours: runs across a row, then identical runs down.
    done, open_runs = [], {}
    for j, row in enumerate(cells):
        runs = []
        c = 0
        while c < cols:
            end = c + 1
            while end < cols and row[end] == row[c]:
                end += 1
            runs.append((c, end - c, row[c]))
            c = end
        nxt = {}
        for rx, rw, colour in runs:
            key = (rx, rw, colour)
            if key in open_runs:
                start, length = open_runs.pop(key)
                nxt[key] = (start, length + 1)
            else:
                nxt[key] = (j, 1)
        for key, (start, length) in open_runs.items():
            done.append((key, start, length))
        open_runs = nxt
    for key, (start, length) in open_runs.items():
        done.append((key, start, length))

    out = []
    for (rx, rw, colour), start, length in done:
        if colour[3] <= 0.004:
            continue
        op = "" if colour[3] >= 0.996 else ' fill-opacity="%.3f"' % colour[3]
        out.append('<rect x="%g" y="%g" width="%g" height="%g" fill="%s"%s/>'
                   % (rx * cw, start * ch, rw * cw, length * ch,
                      _hex(colour), op))
    return "".join(out)


def build(element, state, w, h, fr, px):
    """Return {part: svg markup} for one state of one element."""
    out = {}
    for part, box in boxes(fr, w, h).items():
        if part == "":
            out[part] = _interior(element, state, px, box)
        else:
            out[part] = _pixels(px, box)
    return out
