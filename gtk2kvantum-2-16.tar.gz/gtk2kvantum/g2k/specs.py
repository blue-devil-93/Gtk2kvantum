#!/usr/bin/env python3
"""Element table: which GTK3 widget renders which Kvantum element.

Kvantum names SVG objects as follows (see Kvantum/doc/Theme-Making.pdf):

    interior   ->  <interior.element>-<state>
    frame      ->  <frame.element>-<state>-<position>
                   position in {top,bottom,left,right,topleft,topright,
                                bottomleft,bottomright}

so we render each GTK widget once per state and cut it into those objects.
"""

import gi

gi.require_foreign("cairo")
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gtk

from . import capture

from . import states

ST = Gtk.StateFlags


def _button():
    b = Gtk.Button()
    b.set_label("")
    return b


def _entry():
    return Gtk.Entry()


def _combo():
    c = Gtk.ComboBoxText()
    c.append_text("")
    c.set_active(0)
    return c


def _check():
    return Gtk.CheckButton()


def _radio():
    return Gtk.RadioButton()


def _progress(frac):
    def make():
        p = Gtk.ProgressBar()
        p.set_fraction(frac)
        return p

    return make


def _spin():
    adj = Gtk.Adjustment(value=0, lower=0, upper=100, step_increment=1)
    s = Gtk.SpinButton(adjustment=adj)
    s.set_numeric(False)
    return s


def _textview():
    # A GtkTextView paints into its own GdkWindow, which gtk_widget_draw() does
    # not reach; a box carrying the same CSS class gives us the real surface.
    box = Gtk.Box()
    box.get_style_context().add_class("view")
    return box


def _frame():
    return Gtk.Frame()


def _scrollbar():
    """A scrollbar in its natural habitat. Inside a scrolled window it is what
    applications show, so that is what is captured first; some themes (Adwaita)
    keep that bar hidden until it is hovered, and paint a scroll bar shown on
    its own instead, so one is kept as a stand-in for that case."""
    sw = Gtk.ScrolledWindow()
    sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.ALWAYS)
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
    box.set_size_request(120, 1200)
    sw.add(box)
    # Overlay scroll bars (GNOME's default) are painted only while they are
    # hovered, so a scrolled window captured headless shows none of their art -
    # Adwaita's bar came out as nothing and the exporter invented a trough. The
    # same scrolled window with overlay scrolling switched off paints the bar
    # the theme actually declares, which is what is captured instead.
    flat = Gtk.ScrolledWindow()
    flat.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.ALWAYS)
    flat.set_overlay_scrolling(False)
    flat_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
    flat_box.set_size_request(120, 1200)
    flat.add(flat_box)
    return {"main": sw.get_vscrollbar(), "host": sw, "flat": flat}


def _menubar():
    """A menu bar with two title buttons, so one can be cropped out."""
    mb = Gtk.MenuBar()
    mb.set_size_request(240, 26)
    items = []
    for _ in range(2):
        mi = Gtk.MenuItem(label="")
        mi.set_size_request(70, 22)
        mb.append(mi)
        items.append(mi)
    return {"main": mb, "items": items}


def _menu():
    """A posted menu; capture uses the menu itself and its items."""
    m = Gtk.Menu()
    # A popup sizes itself from its children, and a label-less item collapses:
    # without a request the whole menu allocates 5px tall. Too tight (84px) and
    # GTK bakes a scroll arrow into the popup; 100px leaves clean margin.
    m.set_size_request(180, 140)
    items = []
    for _ in range(3):
        mi = Gtk.MenuItem(label="")
        # Without a size request a label-less item collapses and the whole
        # popup allocates a few pixels tall, which is useless to slice.
        mi.set_size_request(170, 26)
        m.append(mi)
        items.append(mi)
    return {"main": m, "items": items, "popup": True}


def _menuitem():
    """A small posted menu, so its rows are drawn the way GTK draws them.

    A bare GtkMenuItem outside a popup cannot be painted at all, and dressing a
    button up as one carried the button's own art - rounded panel, drop shadow
    - into the export. A real menu is posted instead and its middle row is
    captured, which is exactly the art a menu shows.
    """
    menu = Gtk.Menu()
    items = []
    for _ in range(3):
        mi = Gtk.MenuItem(label="")
        mi.set_size_request(150, 26)
        menu.append(mi)
        items.append(mi)
    return {"main": menu, "items": items}


def _scrollbar_stepper(side):
    """One stepper of a real scroll bar, at a position where both are live.

    Kvantum renders [Scrollbar]'s indicator into the square at each end of the
    bar; GTK has a button there with the theme's plate and arrow. The value is
    the middle of the range so neither end is drawn disabled.
    """
    def build():
        # GTK decides whether a scroll bar has steppers while the scroll bar is
        # being constructed, and the capture pass switches them (and their
        # glyphs) off globally so they are not baked into the trough and the
        # thumb. Take that away around this one bar and put it back afterwards.
        resume = capture.suspend_neutralizer()

        def cleanup():
            resume()

        adj = Gtk.Adjustment(value=50, lower=0, upper=100, page_size=20,
                             step_increment=1, page_increment=10)
        sb = Gtk.Scrollbar(orientation=Gtk.Orientation.VERTICAL,
                           adjustment=adj)
        return {"main": sb, "side": side, "cleanup": [cleanup]}
    return build


def _scale():
    """A scale, whose slider handle has no widget of its own.

    The value label is switched off: GTK draws "0.5" above the handle, and the
    handle is cut out of this render, so the number came along as a 10px strip
    and made the exported handle almost twice as tall as it is.
    """
    sc = Gtk.Scale(orientation=Gtk.Orientation.HORIZONTAL)
    sc.set_range(0, 1)
    sc.set_value(0.5)
    sc.set_draw_value(False)
    # Width only: a height request squeezes the scale below its natural size
    # and GTK then clips the handle (Luna's real handle is 33x20, a 20px-tall
    # scale only had room for 27x15).
    sc.set_size_request(160, -1)
    return sc


def _headerbar():
    """A header bar: the closest thing GTK3 has to a title bar.

    Ambiance (and every theme ported from 18.04-era Ubuntu) styles
    `.titlebar.header-bar`; a plain Gtk.Window has no CSS node of its own for
    the title area, so a HeaderBar is the only widget whose art is the title
    bar the theme actually paints.
    """
    hb = Gtk.HeaderBar()
    hb.set_title("")
    hb.set_size_request(240, 40)
    return hb


def _toolbar():
    """A toolbar, styled as the primary toolbar when the theme has one.

    A GtkHeaderBar is a different widget with different art, so it is never
    used: without `.primary-toolbar` rules the plain `toolbar` node is the
    honest fallback.
    """
    tb = Gtk.Toolbar()
    if "primary-toolbar" in states.theme_css():
        tb.get_style_context().add_class("primary-toolbar")
    tb.set_size_request(240, 36)
    return tb


def _tabframe():
    """The notebook frame as a plain frame widget.

    Kvantum cuts the TabFrame under the active tab, and capturing it from a
    notebook with tabs leaked a strip of the tab button into the frame. A frame
    widget has no tabs at all, so that cannot happen, and it paints in themes
    whose notebook frame needs its tabs to be shown.
    """
    fr = Gtk.Frame()
    box = Gtk.Box()
    box.set_size_request(200, 140)
    fr.add(box)
    return fr


def _tooltip():
    # Themes style either the `.tooltip` class or the `tooltip` CSS node, and a
    # plain box only has the former. The `g2k-tooltip` class is what makes the
    # node's rules apply: states.alias_tokens() rewrites `tooltip` to it.
    box = Gtk.Box()
    ctx = box.get_style_context()
    for cls in ("tooltip", "background", "g2k-tooltip"):
        ctx.add_class(cls)
    return box


def _window():
    box = Gtk.Box()
    box.get_style_context().add_class("background")
    return box


def _notebook():
    # Two pages: tab 0 is the selected one (the "toggled" art) and tab 1 stays
    # inactive, which is what Kvantum's plain tab state needs.
    nb = Gtk.Notebook()
    nb.set_tab_pos(Gtk.PositionType.TOP)
    labels = []
    pages = []
    for _ in range(2):
        page = Gtk.Box()
        label = Gtk.Label(label="")
        # Tabs without text collapse to a stub; a fixed width keeps the
        # captured tab close to the size Kvantum will stretch it to.
        label.set_size_request(90, -1)
        nb.append_page(page, label)
        labels.append(label)
        pages.append(page)
    nb.set_current_page(0)
    return {"main": nb, "labels": labels, "pages": pages}


class Spec:
    """One Kvantum element to export."""

    def __init__(self, key, element, build, size, kind,
                 variants, sections=(), margins=False, insets=None,
                 mode="render", shadow=False, tokens=None,
                 allow_blank_normal=False, raster=False, css=()):
        self.key = key            # internal id, also the id prefix
        self.element = element    # SVG element base name
        self.build = build
        self.size = size          # (w, h) request
        self.kind = kind          # sliced | single | scrollbar | groove | fill ...
        self.variants = variants  # [(state_suffix, [state flags])]
        self.sections = sections  # kvconfig sections that use this element
        self.margins = margins
        self.insets = insets      # optional manual (top, right, bottom, left)
        # "slice" = nine real slices of GTK's render (default),
        # "geom"  = synthesised nine-slice (measured radii + sampled colours),
        # anything else = one whole-widget capture, stretched by Kvantum.
        self.mode = mode
        self.shadow = shadow      # wide translucent rim: keep it in the frame
        # CSS node names to dress a plain widget as (see states.alias_tokens).
        self.tokens = tokens
        # A theme may paint an element's normal state as nothing at all: menu
        # items are transparent until hovered. That is art, not a broken
        # capture, so it is exported blank and left unscored instead of skipped.
        self.allow_blank_normal = allow_blank_normal
        # Emit as one exact-size <image>: immune to bounds inflation.
        self.raster = raster
        # CSS classes whose border-image-slice describes this element's
        # nine-slice geometry (see states.frame_slice).
        self.css = css


V_ALL = [
    ("normal", []),
    ("focused", [ST.PRELIGHT]),
    ("pressed", [ST.ACTIVE]),
    ("toggled", [ST.CHECKED]),
    ("disabled", [ST.INSENSITIVE]),
]
V_TEXT = [
    ("normal", []),
    ("focused", [ST.PRELIGHT]),
    ("disabled", [ST.INSENSITIVE]),
]
# A window that is not focused is not the same as a disabled widget, and
# Kvantum asks for both: its `-inactive` states are the backdrop art GTK
# draws in an unfocused window. Kvantum's own KvAmbiance ships
# button-normal-inactive / lineedit-normal-inactive for exactly this, and the
# exporter used to have no such state at all, so every unfocused window fell
# back to Kvantum's default theme.
V_FRAME = [
    ("normal", []),
    ("normal-inactive", [ST.BACKDROP]),
    ("focused", [ST.PRELIGHT]),
    ("pressed", [ST.ACTIVE]),
    ("toggled", [ST.CHECKED]),
    ("disabled", [ST.INSENSITIVE]),
]
V_TEXT_INACTIVE = [
    ("normal", []),
    ("normal-inactive", [ST.BACKDROP]),
    ("focused", [ST.PRELIGHT]),
    ("disabled", [ST.INSENSITIVE]),
]
# A slider handle or scrollbar slider: Kvantum's own themes ship normal,
# focused, pressed and disabled for both. Without -pressed the slider jumps
# back to the default theme's art the moment it is dragged.
V_HANDLE = [
    ("normal", []),
    # Kvantum appends "-inactive" to the state of a handle in an unfocused
    # window and draws nothing when that element is missing, so the thumb and
    # the scale handle disappeared as soon as the window lost focus.
    ("normal-inactive", [ST.BACKDROP]),
    ("focused", [ST.PRELIGHT]),
    ("pressed", [ST.ACTIVE]),
    ("disabled", [ST.INSENSITIVE]),
]
# A slider's groove: Kvantum paints the empty part from -normal and the filled
# part from -toggled, and asks for the same pair with "-inactive" in an
# unfocused window.
V_TROUGH = [
    ("normal", []),
    ("normal-inactive", [ST.BACKDROP]),
    ("toggled", [ST.CHECKED]),
    ("toggled-inactive", [ST.CHECKED, ST.BACKDROP]),
]
# A menu row. Kvantum never draws the panel for normal or disabled rows, asks
# for -focused on hover, -pressed on click and -toggled for a checked row or
# one whose submenu is open. GTK paints checked rows plain and open submenu
# rows as hover, so -toggled uses the hover art.
V_MENUITEM = [
    ("normal", []),
    ("focused", [ST.PRELIGHT]),
    # GTK has no pressed look of its own for a menu row: a click keeps the
    # hover highlight, so -pressed carries the same art.
    ("pressed", [ST.PRELIGHT]),
    ("toggled", [ST.PRELIGHT]),
    ("disabled", [ST.INSENSITIVE]),
]
V_ONE = [("normal", [])]
# check boxes / radio buttons: Kvantum wants -normal, -focused,
# -checked-normal, -checked-focused ...
V_CHECK = [
    ("normal", []),
    ("focused", [ST.PRELIGHT]),
    ("checked-normal", [ST.CHECKED]),
    ("checked-focused", [ST.CHECKED, ST.PRELIGHT]),
    # Kvantum asks for -tristate-normal/-tristate-focused for an inconsistent
    # (partially checked) box, and its own KvAmbiance ships that art. GTK has
    # the state as Gtk.StateFlags.INCONSISTENT / the `inconsistent` property.
    ("tristate-normal", [ST.INCONSISTENT]),
    ("tristate-focused", [ST.INCONSISTENT, ST.PRELIGHT]),
    ("disabled", [ST.INSENSITIVE]),
    ("checked-disabled", [ST.CHECKED, ST.INSENSITIVE]),
    ("tristate-disabled", [ST.INCONSISTENT, ST.INSENSITIVE]),
]
# Tabs: Kvantum asks for normal (inactive), focused (hovered) and toggled
# (selected). Nothing else is used, and the selected tab is a different shape.
V_TAB = [
    ("normal", []),
    ("focused", [ST.PRELIGHT]),
    ("toggled", [ST.CHECKED]),
]


SPECS = [
    # Plain frames (gradient + border + radius) are still best synthesised:
    # sliced fragments re-antialias their outer edge where they meet, which
    # shows up as a thin seam along every join.
    Spec("button", "button", _button, (150, 36), "sliced", V_FRAME,
         sections=["PanelButtonCommand"], margins=True, mode="geom",
         css=("button",)),
    Spec("lineedit", "lineedit", _entry, (170, 34), "sliced", V_TEXT_INACTIVE,
         sections=["LineEdit"], margins=True, mode="geom", css=("entry",)),
    Spec("combo", "combo", _combo, (170, 34), "sliced", V_TEXT_INACTIVE,
         sections=["ComboBox"], margins=True, mode="geom",
         css=("combobox", "button")),
    Spec("checkbox", "checkbox", _check, (22, 22), "single", V_CHECK,
         sections=["CheckBox"], margins=True, mode="render", raster=True),
    Spec("radio", "radio", _radio, (22, 22), "single", V_CHECK,
         sections=["RadioButton"], margins=True, mode="render", raster=True),
    Spec("scrollbarslider", "scrollbarslider", _scrollbar, (200, 160),
         "scrollbar", V_HANDLE, sections=["ScrollbarSlider"],
         allow_blank_normal=True),
    # A theme may genuinely paint no groove (Adwaita): blank art, not a bug.
    # The trough is exported under its own element (`groove`) rather than the
    # `slider` name Kvantum also uses for a scale's groove: one capture fed both
    # sections, so the two were guaranteed to share art even when the theme
    # draws them differently.
    Spec("groove", "groove", _scrollbar, (200, 160), "groove", V_ONE,
         sections=["ScrollbarGroove", "Slider"], allow_blank_normal=True),
    # The two stepper buttons. [Scrollbar]'s indicator is the only art Kvantum
    # ever draws at the ends of a bar (`default_frame_spec` means it never
    # frames them), so the plate has to come with the arrow.
    Spec("scarrow-up", "scarrow-up", _scrollbar_stepper("up"), (14, 120),
         "stepper", V_HANDLE, sections=["Scrollbar"]),
    Spec("scarrow-down", "scarrow-down", _scrollbar_stepper("down"),
         (14, 120), "stepper", V_HANDLE, sections=["Scrollbar"]),
    Spec("progress", "progress", _progress(0.0), (180, 20), "sliced",
         V_TEXT, sections=["Progressbar"], mode="geom"),
    Spec("progress-pattern", "progress-pattern", _progress(1.0), (180, 20),
         "fill", V_ONE, sections=["ProgressbarContents"]),
    # The menu panel is nine-sliced from its own pixels: as one stretched
    # object, the panel's 1px border and 5px radius were scaled with the popup,
    # so the border was fatter on a big menu than on a small one.
    Spec("menu", "menu", _menu, (200, 140), "menu", V_ONE,
         sections=["Menu"], margins=True, mode="geom"),
    # Menu items are photographed through a stand-in button: no popup, nothing
    # to get wrong, and the hovered art is a real screenshot.
    Spec("menuitem", "menuitem", _menuitem, (180, 120), "menuitem", V_MENUITEM,
         sections=["MenuItem"], mode="render", allow_blank_normal=True),
    # A menu bar item (File, Edit, ...) is its own Kvantum section and has its
    # own art: a button that sits on the bar, not a dropdown entry.
    # Same story as the menu: the hover art is a rounded plate, and stretching
    # it whole smeared its corners, so its edges are now cut out at real size.
    # A menubar title has four lit states, not one: Kvantum draws nothing for
    # `normal`, the hover plate for `focused`, and the *same* plate for
    # `pressed` and `toggled` - and `toggled` is what it asks for while the
    # title's menu is open (getState() in Kvantum.cpp maps State_On and
    # State_Selected onto "toggled"). Captured with ACTIVE/CHECKED instead of
    # hover, GTK painted nothing, so the selected title had no highlight at
    # all: `pressed` and `toggled` are now the hover art, exactly like the
    # menu rows above.
    Spec("menubaritem", "menubaritem", _menubar, (240, 26), "menubaritem",
         V_MENUITEM, sections=["MenuBarItem"], margins=True, mode="geom",
         allow_blank_normal=True),
    # The scale handle. Kvantum's element for a slider's handle is
    # [SliderCursor] - [Slider] is the groove. Under the old name the handle
    # art was painted as the whole groove and the handle itself was taken from
    # the default theme. Drawn from a button wearing the theme's scale-slider
    # rules: the same trick as the scroll bar slider.
    Spec("slidercursor", "slidercursor", _scale, (160, 40), "scale", V_HANDLE,
         sections=["SliderCursor"], allow_blank_normal=True),
    # The scale's trough is a different element from the scroll bar's: Adwaita
    # paints one as a 4px band and the other as a 15px bar, so sharing a
    # capture drew [Slider] with scroll bar art (and slider_width with the
    # scroll bar thumb's width).
    Spec("slider", "slider", _scale, (160, 40), "slidertrough", V_TROUGH,
         sections=["Slider"], allow_blank_normal=True),
    # One flat strip: nine-slicing buys nothing, and the theme paints an
    # oversized gradient rect that inflates the measured bounds by 20%. An
    # exact-size image cannot be mismeasured, and stretching a flat bar is safe.
    Spec("menubar", "menubar", _menubar, (240, 26), "single", V_ONE,
         sections=["MenuBar"], allow_blank_normal=True, raster=True),
    Spec("toolbar", "toolbar", _toolbar, (240, 36), "single", V_ONE,
         sections=["Toolbar"], allow_blank_normal=True, raster=True),
    Spec("tooltip", "tooltip", _tooltip, (160, 40), "sliced", V_ONE,
         sections=["ToolTip"], margins=True, mode="slice", shadow=True,
         tokens={"tooltip": ".g2k-tooltip"}),
    Spec("window", "window", _window, (200, 120), "single", V_ONE,
         sections=["Window"]),
    Spec("common", "common", _frame, (200, 120), "sliced", V_FRAME,
         sections=["GenericFrame"], mode="slice", css=("frame",)),
    # The title bar and the header section. Kvantum has two elements for what
    # GTK3 draws as one header bar: `titlebar` is the whole bar, stretched,
    # and `header` is its 1px frame, nine-sliced. KvAmbiance ships both.
    Spec("titlebar", "titlebar", _headerbar, (240, 40), "single", V_FRAME[:2],
         sections=["TitleBar"], css=("titlebar", "header-bar")),
    Spec("header", "header", _headerbar, (240, 40), "sliced", V_FRAME[:2],
         sections=["HeaderSection"], margins=True, mode="geom",
         css=("titlebar", "header-bar")),
    Spec("group", "group", _frame, (200, 120), "sliced", V_ALL,
         sections=["GroupBox"], margins=True, mode="slice"),
    Spec("spin", "spin", _spin, (110, 34), "sliced", V_TEXT,
         sections=["IndicatorSpinBox"], mode="geom"),
    Spec("itemview", "itemview", _textview, (200, 120), "sliced", V_ONE,
         sections=["ItemView"], raster=True),
    Spec("tab", "tab", _notebook, (220, 160), "tab", V_TAB,
         sections=["Tab"], margins=True),
    # A frame paints one pixel of border and nothing else; stretched as one
    # object that pixel grew with the notebook, which is why every tab frame
    # looked over-bordered. The border is cut out and stays one pixel.
    Spec("tabframe", "tabframe", _tabframe, (220, 160), "tabframe",
         V_ONE, sections=["TabFrame"], mode="geom", css=("frame",)),
]

BY_KEY = {s.key: s for s in SPECS}
