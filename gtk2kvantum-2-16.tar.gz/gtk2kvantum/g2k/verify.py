#!/usr/bin/env python3
"""Verify the export with Qt's own SVG renderer - the library Kvantum uses.

For every exported object this renders `<element>-<state>` through
QSvgRenderer into a widget-sized (and a 1.6x) rect, compares it against
GTK's own render of that widget, and writes preview.png showing exactly
what Kvantum will draw.

    python3 -m g2k.verify OUTDIR [--preview preview.png]
"""

import argparse
import json
import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import QRectF, Qt
from PySide6.QtGui import QColor, QImage, QPainter, QPixmap
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtWidgets import QApplication

# A light grey backdrop: dark art and light art both show up against it.
BG = QColor(238, 238, 241)
# Fidelity is measured over a fixed backdrop so the numbers stay comparable
# between releases; only the pictures people look at use the light one.
SCORE_BG = QColor(32, 32, 36)


def render_object(renderer, oid, w, h, bg=None):
    img = QImage(int(w), int(h), QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(bg if bg is not None else BG)
    if renderer.elementExists(oid):
        p = QPainter(img)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        renderer.render(p, oid, QRectF(0, 0, w, h))
        p.end()
    return img


POSITIONS = ("topleft", "top", "topright", "left", "right",
             "bottomleft", "bottom", "bottomright")


def render_capture(renderer, cap, w, h, bg=None):
    """Compose one element the way Kvantum does.

    Frame pieces keep the widths declared in the .kvconfig, the interior takes
    what is left. This is the thing nine-slice buys: the corners are redrawn at
    their natural size instead of being stretched with the widget.
    """
    w, h = int(w), int(h)
    img = QImage(w, h, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(bg if bg is not None else BG)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    base = "%s-%s" % (cap["element"], cap["state"])
    if cap.get("frame"):
        t, r, b, l = [int(v) for v in cap["insets"]]
        iw, ih = w - l - r, h - t - b
        boxes = {
            "": (l, t, iw, ih),
            "top": (l, 0, iw, t),
            "bottom": (l, h - b, iw, b),
            "left": (0, t, l, ih),
            "right": (w - r, t, r, ih),
            "topleft": (0, 0, l, t),
            "topright": (w - r, 0, r, t),
            "bottomleft": (0, h - b, l, b),
            "bottomright": (w - r, h - b, r, b),
        }
        # Kvantum repeats an interior that declares a pattern size instead of
        # stretching it, so the check has to repeat it the same way.
        pattern = int(cap.get("pattern") or 0)
        for part, (x, y, pw, ph) in boxes.items():
            oid = base + ("-" + part if part else "")
            if pw <= 0 or ph <= 0 or not renderer.elementExists(oid):
                continue
            if part == "" and pattern > 0:
                tile = QImage(max(1, min(pattern, pw)), int(ph),
                              QImage.Format.Format_ARGB32_Premultiplied)
                tile.fill(Qt.GlobalColor.transparent)
                tp = QPainter(tile)
                tp.setRenderHint(QPainter.RenderHint.Antialiasing, True)
                renderer.render(tp, oid, QRectF(0, 0, tile.width(), tile.height()))
                tp.end()
                p.save()
                p.setClipRect(QRectF(x, y, pw, ph))
                p.drawTiledPixmap(QRectF(x, y, pw, ph), QPixmap.fromImage(tile))
                p.restore()
            else:
                renderer.render(p, oid, QRectF(x, y, pw, ph))
    elif renderer.elementExists(base):
        renderer.render(p, base, QRectF(0, 0, w, h))
    p.end()
    return img


def load_png(path, bg=None):
    img = QImage(path)
    if img.isNull():
        return None
    out = QImage(img.width(), img.height(), QImage.Format.Format_ARGB32_Premultiplied)
    out.fill(bg if bg is not None else BG)
    p = QPainter(out)
    p.drawImage(0, 0, img)
    p.end()
    return out


def diff_score(a, b):
    if a.size() != b.size():
        return None
    w, h = a.width(), a.height()
    ba = a.constBits().tobytes()
    bb = b.constBits().tobytes()
    stride_a, stride_b = a.bytesPerLine(), b.bytesPerLine()
    total = 0
    count = 0
    for y in range(h):
        ra, rb = y * stride_a, y * stride_b
        for x in range(w):
            oa, ob = ra + x * 4, rb + x * 4
            total += (abs(ba[oa] - bb[ob]) + abs(ba[oa + 1] - bb[ob + 1]) +
                      abs(ba[oa + 2] - bb[ob + 2]))
            count += 3
    if not count:
        return None
    return 100.0 * (1.0 - (total / count) / 255.0)


def contact_sheet(cells, out_png, cols=5, pad=12):
    if not cells:
        return
    rows = [cells[i:i + cols] for i in range(0, len(cells), cols)]
    cw = max(img.width() for _, img in cells) + pad * 2
    heights = [max(img.height() for _, img in row) + pad * 2 + 20 for row in rows]
    sheet = QImage(cw * cols, sum(heights), QImage.Format.Format_ARGB32_Premultiplied)
    sheet.fill(QColor(236, 236, 238))
    p = QPainter(sheet)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    f = p.font()
    f.setPointSizeF(7.5)
    p.setFont(f)
    y = 0
    for row, row_h in zip(rows, heights):
        for idx, (label, img) in enumerate(row):
            cx = idx * cw
            p.setPen(QColor(72, 72, 80))
            p.drawText(cx + pad, y + 14, label)
            p.drawImage(cx + pad, y + 20, img)
        y += row_h
    p.end()
    sheet.save(out_png)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("outdir")
    ap.add_argument("--preview", default="preview.png")
    ap.add_argument("--scale", type=float, default=1.6)
    ap.add_argument("--raw", action="store_true",
                    help="also save the whole SVG document as Qt renders it")
    args = ap.parse_args(argv)

    QApplication.instance() or QApplication([])

    with open(os.path.join(args.outdir, "manifest.json")) as fh:
        manifest = json.load(fh)
    name = manifest["name"]
    svg_path = os.path.join(args.outdir, name + ".svg")
    with open(svg_path, "rb") as fh:
        renderer = QSvgRenderer(fh.read())
    if not renderer.isValid():
        print("Qt rejected %s" % svg_path)
        return 2

    debug = os.path.join(args.outdir, "debug")
    cells = []
    scores = []
    print("%-24s %-16s %8s %8s" % ("object", "state", "1x", "scaled"))
    print("-" * 60)
    for cap in manifest["captures"]:
        oid = "%s-%s" % (cap["element"], cap["state"])
        w, h = cap["size"]

        img1 = render_capture(renderer, cap, w, h, SCORE_BG)
        img2 = render_capture(renderer, cap, w * args.scale, h * args.scale, SCORE_BG)

        ref1 = load_png(os.path.join(debug, "%s-%s.png" % (cap["key"], cap["state"])),
                        SCORE_BG)
        # There is no GTK render at the stretched size, so compare against the
        # reference upscaled: the score shows how much stretching distorts the
        # exported object versus simply scaling GTK's output.
        ref2 = None
        if ref1 is not None:
            ref2 = ref1.scaled(int(w * args.scale), int(h * args.scale),
                               Qt.AspectRatioMode.IgnoreAspectRatio,
                               Qt.TransformationMode.SmoothTransformation)
        s1 = diff_score(img1, ref1) if ref1 is not None else None
        s2 = diff_score(img2, ref2) if ref2 is not None else None
        if s1 is not None:
            scores.append(s1)
        print("%-24s %-16s %7s %8s" % (
            oid, cap["state"],
            "-" if s1 is None else "%.1f%%" % s1,
            "-" if s2 is None else "%.1f%%" % s2))
        # The sheet is for human eyes, so it gets the light backdrop.
        cells.append(("%s %s" % (cap["element"], cap["state"]),
                      render_capture(renderer, cap, w * args.scale,
                                     h * args.scale, BG)))

    if scores:
        print("-" * 60)
        print("mean fidelity: %.1f%%  (worst %.1f%%)" % (sum(scores) / len(scores), min(scores)))

    if args.raw:
        size = renderer.defaultSize()
        raw = QImage(max(1, size.width()), max(1, size.height()),
                     QImage.Format.Format_ARGB32_Premultiplied)
        raw.fill(BG)
        p = QPainter(raw)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        renderer.render(p)
        p.end()
        raw_path = os.path.join(args.outdir, name + "-raw.png")
        raw.save(raw_path)
        print("whole SVG document: %s (%dx%d)" % (raw_path, raw.width(), raw.height()))

    out = os.path.join(args.outdir, args.preview)
    contact_sheet(cells, out)
    print("preview (what Kvantum draws): %s" % out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
