#!/bin/sh
# Export the current (or a named) GTK3 theme to a Kvantum SVG theme.
#
#   ./export.sh OUTDIR [--theme Adwaita-dark] [--output-name MyTheme]
#                     [--keep-debug] [--only button,menu]
#
# Needs python3-gi, python3-gi-cairo, python3-cairo and gir1.2-gtk-3.0.
# Headless machines: run under Xvfb, or use GTK's broadway backend with
# broadwayd and GDK_BACKEND=broadway.
cd "$(dirname "$0")" || exit 1
exec python3 -m g2k.main "$@"
